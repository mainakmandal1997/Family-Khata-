package com.example

import com.example.export.XlsxWorkbookWriter
import com.example.logic.KhataAnalytics
import com.example.logic.MonthPeriod
import com.example.logic.StringsProvider
import com.example.logic.formatCurrency
import com.example.model.EventEntry
import com.example.model.EventEntryType
import com.example.model.EventParticipant
import com.example.model.EventSplitMode
import com.example.model.FamilyEvent
import com.example.model.FamilyGroup
import com.example.model.FamilyMember
import com.example.model.MonthlyTransaction
import com.example.model.ParticipantKind
import com.example.model.SplitMode
import com.example.model.TransactionType
import com.example.security.AutoLockTimeout
import com.example.security.PinCrypto
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.util.Calendar
import java.util.zip.ZipFile

class ExampleUnitTest {

    @Test
    fun indianCurrencyFormatting_worksProperly() {
        assertEquals("₹1,25,000", formatCurrency(125000.0, "₹"))
        assertEquals("-₹500", formatCurrency(-500.0, "₹"))
        assertEquals("₹12,345.50", formatCurrency(12345.5, "₹"))
    }

    @Test
    fun cycleWindowAndMonthlySummary_computesSplitsAndPercentages() {
        val period = MonthPeriod(2026, Calendar.NOVEMBER)
        val window = KhataAnalytics.computeCycleWindow(period, cycleStartDay = 5)

        val insideCal = Calendar.getInstance().apply {
            set(2026, Calendar.NOVEMBER, 10, 12, 0, 0)
        }
        val outsideCal = Calendar.getInstance().apply {
            set(2026, Calendar.NOVEMBER, 2, 12, 0, 0)
        }

        val m1 = FamilyMember(id = "m1", name = "Aritra")
        val m2 = FamilyMember(id = "m2", name = "Riya")
        val members = listOf(m1, m2)

        val txs = listOf(
            MonthlyTransaction(
                id = "t1",
                type = TransactionType.INCOME.name,
                amount = 10000.0,
                categoryId = "c_sal",
                categoryName = "Salary",
                paidByMemberId = "m1",
                paidByName = "Aritra",
                dateMillis = insideCal.timeInMillis,
            ),
            MonthlyTransaction(
                id = "t2",
                type = TransactionType.EXPENSE.name,
                amount = 2000.0,
                categoryId = "c_groc",
                categoryName = "Groceries",
                paidByMemberId = "m1",
                paidByName = "Aritra",
                splitMode = SplitMode.FULL_FAMILY.name,
                dateMillis = insideCal.timeInMillis,
            ),
            MonthlyTransaction(
                id = "t3",
                type = TransactionType.EXPENSE.name,
                amount = 500.0,
                categoryId = "c_med",
                categoryName = "Medical",
                paidByMemberId = "m2",
                paidByName = "Riya",
                splitMode = SplitMode.INDIVIDUAL.name,
                dateMillis = insideCal.timeInMillis,
            ),
            MonthlyTransaction(
                id = "t_out",
                type = TransactionType.EXPENSE.name,
                amount = 9999.0,
                categoryId = "c_groc",
                categoryName = "Groceries",
                paidByMemberId = "m1",
                dateMillis = outsideCal.timeInMillis,
            ),
        )

        val cycleTxs = KhataAnalytics.filterForCycle(txs, window)
        assertEquals(3, cycleTxs.size)

        val summary = KhataAnalytics.computeMonthlySummary(cycleTxs, members)
        assertEquals(10000.0, summary.totalIncome, 0.01)
        assertEquals(2500.0, summary.totalExpense, 0.01)
        assertEquals(7500.0, summary.netBalance, 0.01)

        val aritra = summary.memberBreakdowns.first { it.memberId == "m1" }
        val riya = summary.memberBreakdowns.first { it.memberId == "m2" }
        assertEquals(10000.0, aritra.incomeContributed, 0.01)
        assertEquals(2000.0, aritra.expensePaid, 0.01)
        assertEquals(1000.0, aritra.fairShare, 0.01)
        assertEquals(1000.0, aritra.netSettlement, 0.01)
        assertEquals(1500.0, riya.fairShare, 0.01)
        assertEquals(-1000.0, riya.netSettlement, 0.01)

        assertEquals(80.0, summary.expenseCategories.first { it.categoryId == "c_groc" }.percentage, 0.01)
    }

    @Test
    fun eventSummary_handlesFamilyAndGuestSettlements() {
        val event = FamilyEvent(id = "ev1", title = "Durga Puja", budget = 15000.0)
        val p1 = EventParticipant(id = "p1", eventId = "ev1", name = "Aritra", participantKind = ParticipantKind.FAMILY_MEMBER.name)
        val p2 = EventParticipant(id = "p2", eventId = "ev1", name = "Sourav", participantKind = ParticipantKind.GUEST_FRIEND.name)

        val entries = listOf(
            EventEntry(
                id = "e1",
                eventId = "ev1",
                entryType = EventEntryType.CONTRIBUTION_GIFT.name,
                amount = 3000.0,
                participantId = "p2",
                participantName = "Sourav",
            ),
            EventEntry(
                id = "e2",
                eventId = "ev1",
                entryType = EventEntryType.EXPENSE.name,
                amount = 6000.0,
                categoryId = "cat_cat",
                categoryName = "Catering",
                participantId = "p1",
                participantName = "Aritra",
                splitMode = EventSplitMode.ALL_PARTICIPANTS.name,
            ),
        )

        val summary = KhataAnalytics.computeEventSummary(event, listOf(p1, p2), entries)
        assertEquals(3000.0, summary.totalContributions, 0.01)
        assertEquals(6000.0, summary.totalExpenses, 0.01)
        assertEquals(9000.0, summary.remainingBudget, 0.01)
        assertTrue(summary.participantSettlements.first { it.participantId == "p2" }.isGuest)
        assertEquals(3000.0, summary.participantSettlements.first { it.participantId == "p1" }.netSettlement, 0.01)
        assertEquals(0.0, summary.participantSettlements.first { it.participantId == "p2" }.netSettlement, 0.01)
    }

    @Test
    fun bilingualStrings_switchesBetweenEnglishAndBengali() {
        val en = StringsProvider.get(isBengali = false)
        val bn = StringsProvider.get(isBengali = true)
        assertEquals("Family Khata", en.appTitle)
        assertEquals("পারিবারিক খাতা", bn.appTitle)
    }

    @Test
    fun pinCrypto_hashesVerifiesAndChecksTimeout() {
        val salt = PinCrypto.generateSaltHex()
        val hash = PinCrypto.hashPin("4829", salt)
        assertTrue(PinCrypto.constantTimeEquals(PinCrypto.hashPin("4829", salt), hash))
        assertFalse(PinCrypto.constantTimeEquals(PinCrypto.hashPin("0000", salt), hash))

        val now = 1_700_000_000_000L
        assertTrue(
            PinCrypto.shouldLockOnResume(
                isAppLockEnabled = true,
                hasPinSet = true,
                lastBackgroundMillis = now - 1_000L,
                nowMillis = now,
                timeout = AutoLockTimeout.IMMEDIATE,
            )
        )
        assertFalse(
            PinCrypto.shouldLockOnResume(
                isAppLockEnabled = true,
                hasPinSet = true,
                lastBackgroundMillis = now - 60_000L,
                nowMillis = now,
                timeout = AutoLockTimeout.MIN_5,
            )
        )
        assertTrue(
            PinCrypto.shouldLockOnResume(
                isAppLockEnabled = true,
                hasPinSet = true,
                lastBackgroundMillis = now - 310_000L,
                nowMillis = now,
                timeout = AutoLockTimeout.MIN_5,
            )
        )
    }

    @Test
    fun yearAndCustomWindows_filterTransactionsAccurately() {
        val jan = Calendar.getInstance().apply { set(2026, Calendar.JANUARY, 15, 10, 0, 0) }.timeInMillis
        val dec = Calendar.getInstance().apply { set(2026, Calendar.DECEMBER, 20, 10, 0, 0) }.timeInMillis
        val nextYear = Calendar.getInstance().apply { set(2027, Calendar.JANUARY, 2, 10, 0, 0) }.timeInMillis

        val txs = listOf(
            MonthlyTransaction(id = "a", dateMillis = jan, amount = 100.0),
            MonthlyTransaction(id = "b", dateMillis = dec, amount = 200.0),
            MonthlyTransaction(id = "c", dateMillis = nextYear, amount = 300.0),
        )

        val yearWin = KhataAnalytics.computeYearWindow(2026)
        assertEquals(2, KhataAnalytics.filterForCycle(txs, yearWin).size)

        val customWin = KhataAnalytics.computeCustomWindow(dec, jan) // inverted order normalized
        assertEquals(listOf("b", "a"), KhataAnalytics.filterForCycle(txs, customWin).map { it.id })
    }

    @Test
    fun xlsxWorkbookWriter_generatesValidOpenXmlZipWithFormulas() {
        val tmp = File.createTempFile("khata_test_", ".xlsx")
        try {
            val group = FamilyGroup(id = "g1", name = "Sen Family", currencySymbol = "₹")
            val m1 = FamilyMember(id = "m1", name = "Aritra")
            val tx = MonthlyTransaction(
                id = "t1",
                type = TransactionType.EXPENSE.name,
                amount = 1500.0,
                categoryId = "c_groc",
                categoryName = "Groceries",
                paidByMemberId = "m1",
                paidByName = "Aritra",
                dateMillis = System.currentTimeMillis(),
            )
            val summary = KhataAnalytics.computeMonthlySummary(listOf(tx), listOf(m1))
            XlsxWorkbookWriter.writePeriodWorkbook(
                outFile = tmp,
                group = group,
                periodTitle = "Nov 2026",
                rangeLabel = "01 Nov - 30 Nov",
                summary = summary,
                transactions = listOf(tx),
            )

            assertTrue(tmp.length() > 500L)
            ZipFile(tmp).use { zip ->
                val names = zip.entries().toList().map { it.name }.toSet()
                assertTrue("[Content_Types].xml" in names)
                assertTrue("xl/workbook.xml" in names)
                assertTrue("xl/styles.xml" in names)
                assertTrue("xl/worksheets/sheet1.xml" in names)
                assertTrue("xl/worksheets/sheet2.xml" in names)
                assertTrue("xl/worksheets/sheet3.xml" in names)

                val sheet1Xml = zip.getInputStream(zip.getEntry("xl/worksheets/sheet1.xml")).bufferedReader().readText()
                assertTrue(sheet1Xml.contains("SUM("))
                assertTrue(sheet1Xml.contains("Groceries"))
            }
        } finally {
            tmp.delete()
        }
    }
}
