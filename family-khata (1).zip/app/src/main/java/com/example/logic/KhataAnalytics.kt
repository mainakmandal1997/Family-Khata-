package com.example.logic

import com.example.model.EventEntry
import com.example.model.EventEntryType
import com.example.model.EventParticipant
import com.example.model.EventSplitMode
import com.example.model.FamilyEvent
import com.example.model.FamilyMember
import com.example.model.MonthlyTransaction
import com.example.model.SplitMode
import com.example.model.TransactionType
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class DashboardTimeScope {
    MONTHLY,
    YEARLY,
    CUSTOM_RANGE,
    EVENT,
}

data class MonthPeriod(
    val year: Int,
    val monthZeroBased: Int, // 0..11
) {
    fun next(): MonthPeriod {
        return if (monthZeroBased == 11) MonthPeriod(year + 1, 0) else MonthPeriod(year, monthZeroBased + 1)
    }

    fun previous(): MonthPeriod {
        return if (monthZeroBased == 0) MonthPeriod(year - 1, 11) else MonthPeriod(year, monthZeroBased - 1)
    }

    fun titleLabel(): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, monthZeroBased)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        return SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(cal.time)
    }

    companion object {
        fun current(): MonthPeriod {
            val cal = Calendar.getInstance()
            return MonthPeriod(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH))
        }
    }
}

data class YearPeriod(val year: Int) {
    fun next(): YearPeriod = YearPeriod(year + 1)
    fun previous(): YearPeriod = YearPeriod(year - 1)
    fun titleLabel(): String = year.toString()

    companion object {
        fun current(): YearPeriod = YearPeriod(Calendar.getInstance().get(Calendar.YEAR))
    }
}

data class CycleWindow(
    val startMillis: Long,
    val endMillisExclusive: Long,
    val rangeLabel: String,
)

data class CategoryBreakdownItem(
    val categoryId: String,
    val categoryName: String,
    val colorHex: String,
    val iconKey: String,
    val totalAmount: Double,
    val percentage: Double,
    val transactionCount: Int,
)

data class MemberBreakdownItem(
    val memberId: String,
    val memberName: String,
    val avatarColorHex: String,
    val incomeContributed: Double,
    val expensePaid: Double,
    val fairShare: Double,
) {
    val netSettlement: Double get() = expensePaid - fairShare
}

data class MonthlySummary(
    val totalIncome: Double,
    val totalExpense: Double,
    val netBalance: Double,
    val expenseCategories: List<CategoryBreakdownItem>,
    val incomeCategories: List<CategoryBreakdownItem>,
    val memberBreakdowns: List<MemberBreakdownItem>,
)

data class ParticipantSettlementItem(
    val participantId: String,
    val name: String,
    val isGuest: Boolean,
    val avatarColorHex: String,
    val contributedGifts: Double,
    val expensePaid: Double,
    val fairShare: Double,
) {
    val netSettlement: Double get() = (contributedGifts + expensePaid) - fairShare
}

data class EventSummary(
    val event: FamilyEvent,
    val totalContributions: Double,
    val totalExpenses: Double,
    val remainingBudget: Double,
    val netEventPoolBalance: Double,
    val expenseCategories: List<CategoryBreakdownItem>,
    val participantSettlements: List<ParticipantSettlementItem>,
)

object KhataAnalytics {

    fun computeCycleWindow(period: MonthPeriod, cycleStartDay: Int): CycleWindow {
        val safeDay = cycleStartDay.coerceIn(1, 28)
        val startCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, period.year)
            set(Calendar.MONTH, period.monthZeroBased)
            set(Calendar.DAY_OF_MONTH, safeDay)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val endCal = (startCal.clone() as Calendar).apply {
            add(Calendar.MONTH, 1)
        }
        val displayEndCal = (endCal.clone() as Calendar).apply {
            add(Calendar.DAY_OF_MONTH, -1)
        }
        val fmt = SimpleDateFormat("d MMM", Locale.ENGLISH)
        val label = "${fmt.format(Date(startCal.timeInMillis))} – ${fmt.format(Date(displayEndCal.timeInMillis))}"
        return CycleWindow(
            startMillis = startCal.timeInMillis,
            endMillisExclusive = endCal.timeInMillis,
            rangeLabel = label,
        )
    }

    fun computeYearWindow(year: Int): CycleWindow {
        val startCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, Calendar.JANUARY)
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val endCal = (startCal.clone() as Calendar).apply {
            add(Calendar.YEAR, 1)
        }
        return CycleWindow(
            startMillis = startCal.timeInMillis,
            endMillisExclusive = endCal.timeInMillis,
            rangeLabel = "1 Jan – 31 Dec $year",
        )
    }

    fun computeCustomWindow(startMillis: Long, endMillis: Long): CycleWindow {
        val orderedStart = minOf(startMillis, endMillis)
        val orderedEnd = maxOf(startMillis, endMillis)
        val startCal = Calendar.getInstance().apply {
            timeInMillis = orderedStart
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val endCal = Calendar.getInstance().apply {
            timeInMillis = orderedEnd
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            add(Calendar.DAY_OF_MONTH, 1)
        }
        val fmt = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
        val label = "${fmt.format(Date(startCal.timeInMillis))} – ${fmt.format(Date(orderedEnd))}"
        return CycleWindow(
            startMillis = startCal.timeInMillis,
            endMillisExclusive = endCal.timeInMillis,
            rangeLabel = label,
        )
    }

    fun filterForCycle(
        transactions: List<MonthlyTransaction>,
        window: CycleWindow,
    ): List<MonthlyTransaction> {
        return transactions
            .filter { it.dateMillis in window.startMillis until window.endMillisExclusive }
            .sortedByDescending { it.dateMillis }
    }

    fun computeMonthlySummary(
        cycleTransactions: List<MonthlyTransaction>,
        members: List<FamilyMember>,
    ): MonthlySummary {
        var totalIncome = 0.0
        var totalExpense = 0.0

        val incomeByMember = mutableMapOf<String, Double>()
        val paidByMember = mutableMapOf<String, Double>()
        val shareByMember = mutableMapOf<String, Double>()
        val allMemberIds = members.map { it.id }

        cycleTransactions.forEach { tx ->
            when (tx.parsedType()) {
                TransactionType.INCOME -> {
                    totalIncome += tx.amount
                    incomeByMember[tx.paidByMemberId] = (incomeByMember[tx.paidByMemberId] ?: 0.0) + tx.amount
                }
                TransactionType.EXPENSE -> {
                    totalExpense += tx.amount
                    paidByMember[tx.paidByMemberId] = (paidByMember[tx.paidByMemberId] ?: 0.0) + tx.amount
                    val targets = when (tx.parsedSplitMode()) {
                        SplitMode.FULL_FAMILY -> allMemberIds.ifEmpty { listOf(tx.paidByMemberId) }
                        SplitMode.SELECTED_MEMBERS -> tx.splitMemberIds.ifEmpty { listOf(tx.paidByMemberId) }
                        SplitMode.INDIVIDUAL -> listOf(tx.paidByMemberId)
                    }
                    val perPerson = if (targets.isNotEmpty()) tx.amount / targets.size else 0.0
                    targets.forEach { mId ->
                        shareByMember[mId] = (shareByMember[mId] ?: 0.0) + perPerson
                    }
                }
            }
        }

        val expenseCategories = buildCategoryBreakdown(
            items = cycleTransactions.filter { it.parsedType() == TransactionType.EXPENSE },
            total = totalExpense,
            idSelector = { it.categoryId },
            nameSelector = { it.categoryName },
            colorSelector = { it.categoryColorHex },
            iconSelector = { it.categoryIconKey },
            amountSelector = { it.amount },
        )

        val incomeCategories = buildCategoryBreakdown(
            items = cycleTransactions.filter { it.parsedType() == TransactionType.INCOME },
            total = totalIncome,
            idSelector = { it.categoryId },
            nameSelector = { it.categoryName },
            colorSelector = { it.categoryColorHex },
            iconSelector = { it.categoryIconKey },
            amountSelector = { it.amount },
        )

        val memberBreakdowns = members.map { m ->
            MemberBreakdownItem(
                memberId = m.id,
                memberName = m.name,
                avatarColorHex = m.avatarColorHex,
                incomeContributed = incomeByMember[m.id] ?: 0.0,
                expensePaid = paidByMember[m.id] ?: 0.0,
                fairShare = shareByMember[m.id] ?: 0.0,
            )
        }

        return MonthlySummary(
            totalIncome = totalIncome,
            totalExpense = totalExpense,
            netBalance = totalIncome - totalExpense,
            expenseCategories = expenseCategories,
            incomeCategories = incomeCategories,
            memberBreakdowns = memberBreakdowns,
        )
    }

    fun computeEventSummary(
        event: FamilyEvent,
        participants: List<EventParticipant>,
        entries: List<EventEntry>,
    ): EventSummary {
        var totalContributions = 0.0
        var totalExpenses = 0.0

        val giftsByParticipant = mutableMapOf<String, Double>()
        val paidByParticipant = mutableMapOf<String, Double>()
        val shareByParticipant = mutableMapOf<String, Double>()
        val allParticipantIds = participants.map { it.id }

        entries.forEach { entry ->
            when (entry.parsedEntryType()) {
                EventEntryType.CONTRIBUTION_GIFT -> {
                    totalContributions += entry.amount
                    giftsByParticipant[entry.participantId] =
                        (giftsByParticipant[entry.participantId] ?: 0.0) + entry.amount
                }
                EventEntryType.EXPENSE -> {
                    totalExpenses += entry.amount
                    paidByParticipant[entry.participantId] =
                        (paidByParticipant[entry.participantId] ?: 0.0) + entry.amount
                    val targets = when (entry.parsedSplitMode()) {
                        EventSplitMode.ALL_PARTICIPANTS ->
                            allParticipantIds.ifEmpty { listOf(entry.participantId) }
                        EventSplitMode.SELECTED_PARTICIPANTS ->
                            entry.splitParticipantIds.ifEmpty { listOf(entry.participantId) }
                        EventSplitMode.INDIVIDUAL ->
                            listOf(entry.participantId)
                    }
                    val share = if (targets.isNotEmpty()) entry.amount / targets.size else 0.0
                    targets.forEach { pId ->
                        shareByParticipant[pId] = (shareByParticipant[pId] ?: 0.0) + share
                    }
                }
            }
        }

        val expenseCategories = buildCategoryBreakdown(
            items = entries.filter { it.parsedEntryType() == EventEntryType.EXPENSE },
            total = totalExpenses,
            idSelector = { it.categoryId },
            nameSelector = { it.categoryName },
            colorSelector = { it.categoryColorHex },
            iconSelector = { it.categoryIconKey },
            amountSelector = { it.amount },
        )

        val participantSettlements = participants.map { p ->
            ParticipantSettlementItem(
                participantId = p.id,
                name = p.name,
                isGuest = p.parsedKind().name == "GUEST_FRIEND",
                avatarColorHex = p.avatarColorHex,
                contributedGifts = giftsByParticipant[p.id] ?: 0.0,
                expensePaid = paidByParticipant[p.id] ?: 0.0,
                fairShare = shareByParticipant[p.id] ?: 0.0,
            )
        }

        return EventSummary(
            event = event,
            totalContributions = totalContributions,
            totalExpenses = totalExpenses,
            remainingBudget = event.budget - totalExpenses,
            netEventPoolBalance = totalContributions - totalExpenses,
            expenseCategories = expenseCategories,
            participantSettlements = participantSettlements,
        )
    }

    private fun <T> buildCategoryBreakdown(
        items: List<T>,
        total: Double,
        idSelector: (T) -> String,
        nameSelector: (T) -> String,
        colorSelector: (T) -> String,
        iconSelector: (T) -> String,
        amountSelector: (T) -> Double,
    ): List<CategoryBreakdownItem> {
        if (items.isEmpty()) return emptyList()
        return items.groupBy { idSelector(it).ifBlank { nameSelector(it) } }
            .map { (key, group) ->
                val first = group.first()
                val sum = group.sumOf(amountSelector)
                val pct = if (total > 0.0) (sum / total) * 100.0 else 0.0
                CategoryBreakdownItem(
                    categoryId = key,
                    categoryName = nameSelector(first),
                    colorHex = colorSelector(first),
                    iconKey = iconSelector(first),
                    totalAmount = sum,
                    percentage = pct,
                    transactionCount = group.size,
                )
            }
            .sortedByDescending { it.totalAmount }
    }
}
