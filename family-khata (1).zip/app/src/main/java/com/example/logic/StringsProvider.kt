package com.example.logic

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppStrings(
    val isBengali: Boolean,
    val appTitle: String,
    val appSubtitle: String,
    val navKhata: String,
    val navEvents: String,
    val navCategories: String,
    val navReports: String,
    val totalIncome: String,
    val totalExpense: String,
    val netBalance: String,
    val addTransaction: String,
    val editTransaction: String,
    val memberBreakdown: String,
    val categoryBreakdown: String,
    val recentTransactions: String,
    val searchPlaceholder: String,
    val all: String,
    val income: String,
    val expense: String,
    val noTransactionsYet: String,
    val familyEventsTitle: String,
    val createEvent: String,
    val eventBudget: String,
    val contributionsGifts: String,
    val eventExpenses: String,
    val participants: String,
    val addFamilyMember: String,
    val addGuestFriend: String,
    val categoriesTitle: String,
    val addCustomCategory: String,
    val reportsAndSyncTitle: String,
    val exportPdf: String,
    val exportCsv: String,
    val googleBackupSync: String,
    val backupJson: String,
    val restoreJson: String,
    val familyGroupSettings: String,
    val inviteMember: String,
    val scopeMonthly: String,
    val scopeYearly: String,
    val scopeCustomRange: String,
    val scopeEvents: String,
    val exportExcel: String,
    val appearanceAndSecurity: String,
    val appPrivacyLock: String,
    val themeModeTitle: String,
)

object StringsProvider {
    fun get(isBengali: Boolean): AppStrings = if (isBengali) {
        AppStrings(
            isBengali = true,
            appTitle = "পারিবারিক খাতা",
            appSubtitle = "মাসিক খাতা ও অনুষ্ঠান হিসাব",
            navKhata = "ড্যাশবোর্ড",
            navEvents = "অনুষ্ঠান",
            navCategories = "বিভাগ",
            navReports = "রিপোর্ট",
            totalIncome = "মোট জমা / আয়",
            totalExpense = "মোট খরচ",
            netBalance = "অবশিষ্ট ব্যালেন্স",
            addTransaction = "নতুন এন্ট্রি",
            editTransaction = "এন্ট্রি সম্পাদনা",
            memberBreakdown = "সদস্যদের হিসাব (জমা বনাম খরচ)",
            categoryBreakdown = "বিভাগ অনুযায়ী খরচ ও শতাংশ (%)",
            recentTransactions = "লেনদেনের তালিকা",
            searchPlaceholder = "বিভাগ, সদস্য বা নোট খুঁজুন...",
            all = "সব",
            income = "জমা / আয়",
            expense = "খরচ",
            noTransactionsYet = "এই সময়কালে কোনো লেনদেন নেই। '+' বোতামে চাপ দিয়ে শুরু করুন।",
            familyEventsTitle = "পারিবারিক অনুষ্ঠান ও উৎসব",
            createEvent = "নতুন অনুষ্ঠান",
            eventBudget = "বাজেট",
            contributionsGifts = "চাঁদা ও উপহার",
            eventExpenses = "অনুষ্ঠানের খরচ",
            participants = "অংশগ্রহণকারী ও অতিথি",
            addFamilyMember = "সদস্য যোগ করুন",
            addGuestFriend = "বন্ধু / অতিথি যোগ",
            categoriesTitle = "খরচ ও আয়ের বিভাগ",
            addCustomCategory = "নতুন বিভাগ তৈরি",
            reportsAndSyncTitle = "রিপোর্ট, সিকিউরিটি ও ব্যাকআপ",
            exportPdf = "PDF, Excel ও CSV রিপোর্ট",
            exportCsv = "CSV এক্সপোর্ট",
            googleBackupSync = "গুগল ক্লাউড সিঙ্ক ও ব্যাকআপ",
            backupJson = "ব্যাকআপ সেভ (Drive / JSON)",
            restoreJson = "ব্যাকআপ রিস্টোর",
            familyGroupSettings = "পরিবার গ্রুপ ও সদস্য",
            inviteMember = "ইমেইল / ফোনে আমন্ত্রণ",
            scopeMonthly = "মাসিক",
            scopeYearly = "বার্ষিক",
            scopeCustomRange = "কাস্টম তারিখ",
            scopeEvents = "অনুষ্ঠান",
            exportExcel = "Excel (.xlsx)",
            appearanceAndSecurity = "থিম ও অ্যাপ সিকিউরিটি লক",
            appPrivacyLock = "পিন ও বায়োমেট্রিক লক",
            themeModeTitle = "অ্যাপ থিম",
        )
    } else {
        AppStrings(
            isBengali = false,
            appTitle = "Family Khata",
            appSubtitle = "Monthly Ledger & Event Manager",
            navKhata = "Dashboard",
            navEvents = "Events",
            navCategories = "Categories",
            navReports = "Reports",
            totalIncome = "Total Income",
            totalExpense = "Total Spent",
            netBalance = "Net Balance",
            addTransaction = "Add Entry",
            editTransaction = "Edit Entry",
            memberBreakdown = "Member Contribution vs. Spend",
            categoryBreakdown = "Category Breakdown & Share (%)",
            recentTransactions = "Transaction Ledger",
            searchPlaceholder = "Search category, member, notes...",
            all = "All",
            income = "Income",
            expense = "Expense",
            noTransactionsYet = "No transactions in this period yet. Tap + to add your first entry.",
            familyEventsTitle = "Family Events & Occasions",
            createEvent = "New Event",
            eventBudget = "Budget",
            contributionsGifts = "Gifts & Pool",
            eventExpenses = "Event Spent",
            participants = "Participants & Guests",
            addFamilyMember = "Add Family Member",
            addGuestFriend = "Add Guest / Friend",
            categoriesTitle = "Khata Categories",
            addCustomCategory = "Create Category",
            reportsAndSyncTitle = "Reports, Security & Backup",
            exportPdf = "PDF, Excel & CSV Reports",
            exportCsv = "Export CSV",
            googleBackupSync = "Google Cloud Sync & Backup",
            backupJson = "Backup to Drive / JSON",
            restoreJson = "Restore Backup",
            familyGroupSettings = "Family Group & Members",
            inviteMember = "Invite by Email / Phone",
            scopeMonthly = "Monthly",
            scopeYearly = "Yearly",
            scopeCustomRange = "Custom Range",
            scopeEvents = "Events",
            exportExcel = "Excel (.xlsx)",
            appearanceAndSecurity = "Theme & App Privacy Lock",
            appPrivacyLock = "Security PIN & Biometric Lock",
            themeModeTitle = "Theme Mode",
        )
    }
}

fun formatCurrency(amount: Double, symbol: String = "₹"): String {
    val absVal = kotlin.math.abs(amount)
    val sign = if (amount < -0.005) "-" else ""
    val formatted = formatIndianNumber(absVal)
    return "$sign$symbol$formatted"
}

fun formatIndianNumber(value: Double): String {
    val hasDecimals = kotlin.math.abs(value - value.toLong()) > 0.005
    // Use Indian grouping 3,2,2 via manual formatter for precision
    val rounded = if (hasDecimals) String.format(Locale.US, "%.2f", value) else value.toLong().toString()
    val parts = rounded.split(".")
    val intPart = parts[0]
    val decPart = if (parts.size > 1) ".${parts[1]}" else ""
    val grouped = if (intPart.length <= 3) {
        intPart
    } else {
        val lastThree = intPart.takeLast(3)
        val rest = intPart.dropLast(3)
        val restGrouped = rest.reversed().chunked(2).joinToString(",").reversed()
        "$restGrouped,$lastThree"
    }
    return "$grouped$decPart"
}

fun formatDateShort(millis: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
    return sdf.format(Date(millis))
}

fun formatDateTime(millis: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH)
    return sdf.format(Date(millis))
}
