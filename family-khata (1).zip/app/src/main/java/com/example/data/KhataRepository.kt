package com.example.data

import android.content.Context
import com.example.R
import com.example.model.BuiltInDefaults
import com.example.model.CategoryIconCatalog
import com.example.model.CategoryScope
import com.example.model.CategoryType
import com.example.model.EventEntry
import com.example.model.EventEntryType
import com.example.model.EventParticipant
import com.example.model.EventSplitMode
import com.example.model.EventStatus
import com.example.model.EventType
import com.example.model.FamilyEvent
import com.example.model.FamilyGroup
import com.example.model.FamilyMember
import com.example.model.KhataCategory
import com.example.model.MemberRole
import com.example.model.MonthlyTransaction
import com.example.model.ParticipantKind
import com.example.model.PaymentMode
import com.example.model.SplitMode
import com.example.model.TransactionType
import com.example.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class KhataRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun currentVerifiedEmailLower(): String {
        val user = auth.currentUser ?: return ""
        return if (user.isEmailVerified) (user.email ?: "").trim().lowercase() else ""
    }

    private fun <T> Flow<T>.guardAuthStream(path: String, op: OperationType, uid: String): Flow<T> {
        return this.catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val ex = firestoreError ?: (error as? Exception)
            if (ex != null && auth.currentUser?.uid == uid) {
                handleFirestoreError(ex, op, path)
            }
            throw error
        }
    }

    // --- USER PROFILE ---

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "users/$userId"
        db.collection("users").document(userId)
            .snapshots()
            .map { it.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .guardAuthStream(path, OperationType.GET, userId)
            .collect { emit(it) }
    }

    suspend fun ensureUserProfile(
        displayName: String,
        email: String,
        phoneNumber: String = "",
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "users/$uid"
        return try {
            val docRef = db.collection("users").document(uid)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val cleanName = displayName.trim().ifBlank { "Family Member" }.take(80)
                val cleanEmail = email.trim().take(120)
                val cleanPhone = phoneNumber.trim().take(30)
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "displayName" to cleanName,
                        "email" to cleanEmail,
                        "phoneNumber" to cleanPhone,
                        "preferredLanguage" to "en",
                        "activeGroupId" to "",
                        "lastBackupAtMillis" to 0L,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun updateUserProfile(
        displayName: String? = null,
        phoneNumber: String? = null,
        preferredLanguage: String? = null,
        activeGroupId: String? = null,
        lastBackupAtMillis: Long? = null,
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "users/$uid"
        return try {
            val updates = mutableMapOf<String, Any>(
                "updatedAt" to FieldValue.serverTimestamp()
            )
            displayName?.let { updates["displayName"] = it.trim().ifBlank { "Family Member" }.take(80) }
            phoneNumber?.let { updates["phoneNumber"] = it.trim().take(30) }
            preferredLanguage?.let {
                require(it == "en" || it == "bn")
                updates["preferredLanguage"] = it
            }
            activeGroupId?.let { updates["activeGroupId"] = it.trim().take(128) }
            lastBackupAtMillis?.let { updates["lastBackupAtMillis"] = it.coerceAtLeast(0L) }
            db.collection("users").document(uid).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- FAMILY GROUPS & INVITES ---

    fun observeMyGroups(userId: String): Flow<List<FamilyGroup>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "familyGroups"
        db.collection(path)
            .whereArrayContains("memberUids", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(FamilyGroup::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.name.lowercase() }
            }
            .guardAuthStream(path, OperationType.LIST, userId)
            .collect { emit(it) }
    }

    fun observePendingInvites(userId: String): Flow<List<FamilyGroup>> {
        val emailLower = currentVerifiedEmailLower()
        if (emailLower.isBlank()) return flowOf(emptyList())
        val path = "familyGroups"
        return db.collection(path)
            .whereArrayContains("invitedEmails", emailLower)
            .snapshots()
            .map { snap ->
                snap.toObjects(FamilyGroup::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .filter { userId !in it.memberUids }
            }
            .guardAuthStream(path, OperationType.LIST, userId)
    }

    suspend fun createFamilyGroup(
        name: String,
        currencySymbol: String,
        cycleStartDay: Int,
        ownerDisplayName: String,
        ownerEmail: String,
        ownerPhone: String,
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanName = name.trim().take(80)
        require(cleanName.isNotBlank()) { "Family group name is required" }
        val cleanCurrency = currencySymbol.trim().ifBlank { "₹" }.take(6)
        val safeDay = cycleStartDay.coerceIn(1, 28).toLong()
        val groupRef = db.collection("familyGroups").document()
        val groupId = groupRef.id
        val cleanEmailLower = ownerEmail.trim().lowercase().take(120)

        return try {
            // Step 1: Create parent FamilyGroup document first so subcollection security rules can verify parent existence
            groupRef.set(
                mapOf(
                    "name" to cleanName,
                    "currencySymbol" to cleanCurrency,
                    "cycleStartDay" to safeDay,
                    "ownerId" to uid,
                    "memberUids" to listOf(uid),
                    "adminUids" to listOf(uid),
                    "invitedEmails" to emptyList<String>(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()

            // Step 2: Create owner member record + built-in bilingual categories in a WriteBatch
            val batch = db.batch()
            val memberRef = groupRef.collection("members").document()
            batch.set(
                memberRef,
                mapOf(
                    "groupId" to groupId,
                    "memberUids" to listOf(uid),
                    "invitedEmails" to emptyList<String>(),
                    "name" to ownerDisplayName.trim().ifBlank { "Admin" }.take(60),
                    "email" to cleanEmailLower,
                    "phone" to ownerPhone.trim().take(30),
                    "role" to MemberRole.ADMIN.name,
                    "linkedUid" to uid,
                    "avatarColorHex" to CategoryIconCatalog.avatarColors.first(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            )

            BuiltInDefaults.categories.forEach { seed ->
                val catRef = groupRef.collection("categories").document(seed.id)
                batch.set(
                    catRef,
                    mapOf(
                        "groupId" to groupId,
                        "memberUids" to listOf(uid),
                        "invitedEmails" to emptyList<String>(),
                        "name" to seed.name,
                        "nameBn" to seed.nameBn,
                        "scope" to seed.scope.name,
                        "type" to seed.type.name,
                        "iconKey" to seed.iconKey,
                        "colorHex" to seed.colorHex,
                        "builtIn" to true,
                        "createdBy" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }
            batch.commit().await()

            // Set activeGroupId on user profile
            updateUserProfile(activeGroupId = groupId)
            Result.success(groupId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "familyGroups/$groupId")
            Result.failure(e)
        }
    }

    suspend fun updateFamilyGroupSettings(
        groupId: String,
        name: String,
        currencySymbol: String,
        cycleStartDay: Int,
    ): Result<Unit> {
        val path = "familyGroups/$groupId"
        return try {
            requireUserId()
            val cleanName = name.trim().take(80)
            require(cleanName.isNotBlank()) { "Group name cannot be empty" }
            db.collection("familyGroups").document(groupId).update(
                mapOf(
                    "name" to cleanName,
                    "currencySymbol" to currencySymbol.trim().ifBlank { "₹" }.take(6),
                    "cycleStartDay" to cycleStartDay.coerceIn(1, 28).toLong(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun acceptGroupInvite(group: FamilyGroup): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val emailLower = currentVerifiedEmailLower()
        if (emailLower.isBlank()) {
            return Result.failure(IllegalStateException("Verified Google email is required to join."))
        }
        val groupRef = db.collection("familyGroups").document(group.id)
        return try {
            val updatedMemberUids = (group.memberUids + uid).distinct().take(25)
            groupRef.update(
                mapOf(
                    "memberUids" to updatedMemberUids,
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()

            // Sync UID into existing subcollection documents accessible via invitedEmails
            val subCollections = listOf("members", "categories", "transactions", "events", "eventParticipants", "eventEntries")
            val pendingUpdates = mutableListOf<Pair<DocumentReference, Map<String, Any>>>()
            for (sub in subCollections) {
                val snap = groupRef.collection(sub)
                    .whereArrayContains("invitedEmails", emailLower)
                    .get()
                    .await()
                snap.documents.forEach { doc ->
                    val existingUids = (doc.get("memberUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                    if (uid !in existingUids) {
                        val nextUids = (existingUids + uid).distinct().take(25)
                        val payload = mutableMapOf<String, Any>(
                            "memberUids" to nextUids,
                            "updatedAt" to FieldValue.serverTimestamp(),
                        )
                        if (sub == "members") {
                            val memberEmail = (doc.getString("email") ?: "").trim().lowercase()
                            if (memberEmail == emailLower) {
                                payload["linkedUid"] = uid
                            }
                        }
                        pendingUpdates.add(doc.reference to payload)
                    }
                }
            }
            commitUpdatesInChunks(pendingUpdates)
            updateUserProfile(activeGroupId = group.id)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, groupRef.path)
            Result.failure(e)
        }
    }

    // --- MEMBERS ---

    fun observeMembers(groupId: String, userId: String): Flow<List<FamilyMember>> = flow {
        val path = "familyGroups/$groupId/members"
        db.collection("familyGroups").document(groupId).collection("members")
            .whereArrayContains("memberUids", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(FamilyMember::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.name.lowercase() }
            }
            .guardAuthStream(path, OperationType.LIST, userId)
            .collect { emit(it) }
    }

    suspend fun addOrInviteMember(
        group: FamilyGroup,
        name: String,
        email: String,
        phone: String,
        role: MemberRole,
        avatarColorHex: String,
    ): Result<Unit> {
        val groupRef = db.collection("familyGroups").document(group.id)
        return try {
            requireUserId()
            val cleanName = name.trim().take(60)
            require(cleanName.isNotBlank()) { "Member name is required" }
            val cleanEmail = email.trim().lowercase().take(120)
            val cleanPhone = phone.trim().take(30)
            require(cleanEmail.isNotBlank() || cleanPhone.isNotBlank()) {
                "Enter an email address or mobile number"
            }

            val nextInvitedEmails = if (cleanEmail.isNotBlank() && cleanEmail !in group.invitedEmails) {
                (group.invitedEmails + cleanEmail).distinct().take(25)
            } else {
                group.invitedEmails
            }

            if (nextInvitedEmails != group.invitedEmails) {
                groupRef.update(
                    mapOf(
                        "invitedEmails" to nextInvitedEmails,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
                propagateGroupAuthFields(group.id, group.memberUids, nextInvitedEmails)
            }

            groupRef.collection("members").document().set(
                mapOf(
                    "groupId" to group.id,
                    "memberUids" to group.memberUids,
                    "invitedEmails" to nextInvitedEmails,
                    "name" to cleanName,
                    "email" to cleanEmail,
                    "phone" to cleanPhone,
                    "role" to role.name,
                    "linkedUid" to "",
                    "avatarColorHex" to avatarColorHex,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "familyGroups/${group.id}/members")
            Result.failure(e)
        }
    }

    suspend fun updateMemberRole(group: FamilyGroup, member: FamilyMember, newRole: MemberRole): Result<Unit> {
        val path = "familyGroups/${group.id}/members/${member.id}"
        return try {
            requireUserId()
            val groupRef = db.collection("familyGroups").document(group.id)
            groupRef.collection("members").document(member.id).update(
                mapOf(
                    "role" to newRole.name,
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
            if (member.linkedUid.isNotBlank() && member.linkedUid != group.ownerId) {
                val nextAdmins = if (newRole == MemberRole.ADMIN) {
                    (group.adminUids + member.linkedUid).distinct().take(10)
                } else {
                    group.adminUids.filter { it != member.linkedUid || it == group.ownerId }
                }
                groupRef.update(
                    mapOf(
                        "adminUids" to nextAdmins,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun removeMember(group: FamilyGroup, member: FamilyMember): Result<Unit> {
        val path = "familyGroups/${group.id}/members/${member.id}"
        return try {
            requireUserId()
            require(member.linkedUid != group.ownerId) { "Group owner cannot be removed" }
            db.collection("familyGroups").document(group.id)
                .collection("members").document(member.id).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- CATEGORIES ---

    fun observeCategories(groupId: String, userId: String): Flow<List<KhataCategory>> = flow {
        val path = "familyGroups/$groupId/categories"
        db.collection("familyGroups").document(groupId).collection("categories")
            .whereArrayContains("memberUids", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(KhataCategory::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedWith(compareBy<KhataCategory> { !it.builtIn }.thenBy { it.name.lowercase() })
            }
            .guardAuthStream(path, OperationType.LIST, userId)
            .collect { emit(it) }
    }

    suspend fun saveCustomCategory(
        group: FamilyGroup,
        categoryId: String?,
        name: String,
        nameBn: String,
        scope: CategoryScope,
        type: CategoryType,
        iconKey: String,
        colorHex: String,
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanName = name.trim().take(50)
        require(cleanName.isNotBlank()) { "Category name is required" }
        val cleanNameBn = nameBn.trim().take(60)
        val col = db.collection("familyGroups").document(group.id).collection("categories")
        return try {
            if (categoryId.isNullOrBlank()) {
                col.document().set(
                    mapOf(
                        "groupId" to group.id,
                        "memberUids" to group.memberUids,
                        "invitedEmails" to group.invitedEmails,
                        "name" to cleanName,
                        "nameBn" to cleanNameBn,
                        "scope" to scope.name,
                        "type" to type.name,
                        "iconKey" to iconKey,
                        "colorHex" to colorHex,
                        "builtIn" to false,
                        "createdBy" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            } else {
                col.document(categoryId).update(
                    mapOf(
                        "name" to cleanName,
                        "nameBn" to cleanNameBn,
                        "scope" to scope.name,
                        "type" to type.name,
                        "iconKey" to iconKey,
                        "colorHex" to colorHex,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, col.path)
            Result.failure(e)
        }
    }

    suspend fun deleteCategory(groupId: String, categoryId: String): Result<Unit> {
        val path = "familyGroups/$groupId/categories/$categoryId"
        return try {
            requireUserId()
            db.collection("familyGroups").document(groupId)
                .collection("categories").document(categoryId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- MONTHLY TRANSACTIONS ---

    fun observeTransactions(groupId: String, userId: String): Flow<List<MonthlyTransaction>> = flow {
        val path = "familyGroups/$groupId/transactions"
        db.collection("familyGroups").document(groupId).collection("transactions")
            .whereArrayContains("memberUids", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(MonthlyTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.dateMillis }
            }
            .guardAuthStream(path, OperationType.LIST, userId)
            .collect { emit(it) }
    }

    suspend fun saveTransaction(
        group: FamilyGroup,
        txId: String?,
        type: TransactionType,
        amount: Double,
        category: KhataCategory,
        paidBy: FamilyMember,
        splitMode: SplitMode,
        splitMemberIds: List<String>,
        paymentMode: PaymentMode,
        dateMillis: Long,
        notes: String,
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        require(amount > 0.0 && amount <= 1_000_000_000.0) { "Amount must be greater than zero" }
        val col = db.collection("familyGroups").document(group.id).collection("transactions")
        val cleanNotes = notes.trim().take(300)
        val cleanSplits = splitMemberIds.distinct().take(25)

        return try {
            if (txId.isNullOrBlank()) {
                col.document().set(
                    mapOf(
                        "groupId" to group.id,
                        "memberUids" to group.memberUids,
                        "invitedEmails" to group.invitedEmails,
                        "type" to type.name,
                        "amount" to amount,
                        "categoryId" to category.id.ifBlank { category.name },
                        "categoryName" to category.name.take(50),
                        "categoryColorHex" to category.colorHex,
                        "categoryIconKey" to category.iconKey,
                        "paidByMemberId" to paidBy.id,
                        "paidByName" to paidBy.name.take(60),
                        "splitMode" to splitMode.name,
                        "splitMemberIds" to cleanSplits,
                        "paymentMode" to paymentMode.name,
                        "dateMillis" to dateMillis.coerceAtLeast(1L),
                        "notes" to cleanNotes,
                        "createdBy" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            } else {
                col.document(txId).update(
                    mapOf(
                        "type" to type.name,
                        "amount" to amount,
                        "categoryId" to category.id.ifBlank { category.name },
                        "categoryName" to category.name.take(50),
                        "categoryColorHex" to category.colorHex,
                        "categoryIconKey" to category.iconKey,
                        "paidByMemberId" to paidBy.id,
                        "paidByName" to paidBy.name.take(60),
                        "splitMode" to splitMode.name,
                        "splitMemberIds" to cleanSplits,
                        "paymentMode" to paymentMode.name,
                        "dateMillis" to dateMillis.coerceAtLeast(1L),
                        "notes" to cleanNotes,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, col.path)
            Result.failure(e)
        }
    }

    suspend fun deleteTransaction(groupId: String, txId: String): Result<Unit> {
        val path = "familyGroups/$groupId/transactions/$txId"
        return try {
            requireUserId()
            db.collection("familyGroups").document(groupId)
                .collection("transactions").document(txId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- FAMILY EVENTS & PARTICIPANTS & ENTRIES ---

    fun observeEvents(groupId: String, userId: String): Flow<List<FamilyEvent>> = flow {
        val path = "familyGroups/$groupId/events"
        db.collection("familyGroups").document(groupId).collection("events")
            .whereArrayContains("memberUids", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(FamilyEvent::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.startDateMillis }
            }
            .guardAuthStream(path, OperationType.LIST, userId)
            .collect { emit(it) }
    }

    fun observeEventParticipants(groupId: String, userId: String): Flow<List<EventParticipant>> = flow {
        val path = "familyGroups/$groupId/eventParticipants"
        db.collection("familyGroups").document(groupId).collection("eventParticipants")
            .whereArrayContains("memberUids", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(EventParticipant::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.name.lowercase() }
            }
            .guardAuthStream(path, OperationType.LIST, userId)
            .collect { emit(it) }
    }

    fun observeEventEntries(groupId: String, userId: String): Flow<List<EventEntry>> = flow {
        val path = "familyGroups/$groupId/eventEntries"
        db.collection("familyGroups").document(groupId).collection("eventEntries")
            .whereArrayContains("memberUids", userId)
            .snapshots()
            .map { snap ->
                snap.toObjects(EventEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.dateMillis }
            }
            .guardAuthStream(path, OperationType.LIST, userId)
            .collect { emit(it) }
    }

    suspend fun saveEvent(
        group: FamilyGroup,
        eventId: String?,
        title: String,
        eventType: EventType,
        budget: Double,
        startDateMillis: Long,
        endDateMillis: Long,
        venue: String,
        notes: String,
        accentColorHex: String,
        status: EventStatus,
        initialFamilyParticipants: List<FamilyMember> = emptyList(),
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanTitle = title.trim().take(80)
        require(cleanTitle.isNotBlank()) { "Event title is required" }
        val groupRef = db.collection("familyGroups").document(group.id)
        val eventsCol = groupRef.collection("events")
        return try {
            if (eventId.isNullOrBlank()) {
                val docRef = eventsCol.document()
                val newEventId = docRef.id
                docRef.set(
                    mapOf(
                        "groupId" to group.id,
                        "memberUids" to group.memberUids,
                        "invitedEmails" to group.invitedEmails,
                        "title" to cleanTitle,
                        "eventType" to eventType.name,
                        "budget" to budget.coerceAtLeast(0.0),
                        "startDateMillis" to startDateMillis.coerceAtLeast(1L),
                        "endDateMillis" to endDateMillis.coerceAtLeast(0L),
                        "venue" to venue.trim().take(120),
                        "notes" to notes.trim().take(400),
                        "accentColorHex" to accentColorHex,
                        "status" to status.name,
                        "createdBy" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()

                if (initialFamilyParticipants.isNotEmpty()) {
                    val batch = db.batch()
                    initialFamilyParticipants.forEach { member ->
                        val pRef = groupRef.collection("eventParticipants").document()
                        batch.set(
                            pRef,
                            mapOf(
                                "groupId" to group.id,
                                "eventId" to newEventId,
                                "memberUids" to group.memberUids,
                                "invitedEmails" to group.invitedEmails,
                                "name" to member.name.take(60),
                                "contact" to (member.email.ifBlank { member.phone }).take(120),
                                "participantKind" to ParticipantKind.FAMILY_MEMBER.name,
                                "familyMemberId" to member.id,
                                "avatarColorHex" to member.avatarColorHex,
                                "createdBy" to uid,
                                "createdAt" to FieldValue.serverTimestamp(),
                                "updatedAt" to FieldValue.serverTimestamp(),
                            )
                        )
                    }
                    batch.commit().await()
                }
                Result.success(newEventId)
            } else {
                eventsCol.document(eventId).update(
                    mapOf(
                        "title" to cleanTitle,
                        "eventType" to eventType.name,
                        "budget" to budget.coerceAtLeast(0.0),
                        "startDateMillis" to startDateMillis.coerceAtLeast(1L),
                        "endDateMillis" to endDateMillis.coerceAtLeast(0L),
                        "venue" to venue.trim().take(120),
                        "notes" to notes.trim().take(400),
                        "accentColorHex" to accentColorHex,
                        "status" to status.name,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
                Result.success(eventId)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, eventsCol.path)
            Result.failure(e)
        }
    }

    suspend fun deleteEvent(groupId: String, eventId: String, uid: String): Result<Unit> {
        val groupRef = db.collection("familyGroups").document(groupId)
        return try {
            requireUserId()
            val participantsSnap = groupRef.collection("eventParticipants")
                .whereArrayContains("memberUids", uid)
                .whereEqualTo("eventId", eventId)
                .get().await()
            val entriesSnap = groupRef.collection("eventEntries")
                .whereArrayContains("memberUids", uid)
                .whereEqualTo("eventId", eventId)
                .get().await()

            val toDelete = mutableListOf<DocumentReference>()
            participantsSnap.documents.forEach { toDelete.add(it.reference) }
            entriesSnap.documents.forEach { toDelete.add(it.reference) }
            toDelete.add(groupRef.collection("events").document(eventId))
            commitDeletesInChunks(toDelete)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "familyGroups/$groupId/events/$eventId")
            Result.failure(e)
        }
    }

    suspend fun addEventParticipant(
        group: FamilyGroup,
        eventId: String,
        name: String,
        contact: String,
        kind: ParticipantKind,
        familyMemberId: String,
        avatarColorHex: String,
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanName = name.trim().take(60)
        require(cleanName.isNotBlank()) { "Participant name is required" }
        val col = db.collection("familyGroups").document(group.id).collection("eventParticipants")
        return try {
            col.document().set(
                mapOf(
                    "groupId" to group.id,
                    "eventId" to eventId,
                    "memberUids" to group.memberUids,
                    "invitedEmails" to group.invitedEmails,
                    "name" to cleanName,
                    "contact" to contact.trim().take(120),
                    "participantKind" to kind.name,
                    "familyMemberId" to familyMemberId.take(128),
                    "avatarColorHex" to avatarColorHex,
                    "createdBy" to uid,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, col.path)
            Result.failure(e)
        }
    }

    suspend fun deleteEventParticipant(groupId: String, participantId: String): Result<Unit> {
        val path = "familyGroups/$groupId/eventParticipants/$participantId"
        return try {
            requireUserId()
            db.collection("familyGroups").document(groupId)
                .collection("eventParticipants").document(participantId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun saveEventEntry(
        group: FamilyGroup,
        eventId: String,
        entryId: String?,
        entryType: EventEntryType,
        amount: Double,
        category: KhataCategory,
        participant: EventParticipant,
        splitMode: EventSplitMode,
        splitParticipantIds: List<String>,
        paymentMode: PaymentMode,
        dateMillis: Long,
        notes: String,
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        require(amount > 0.0 && amount <= 1_000_000_000.0) { "Amount must be greater than zero" }
        val col = db.collection("familyGroups").document(group.id).collection("eventEntries")
        val cleanNotes = notes.trim().take(300)
        val cleanSplits = splitParticipantIds.distinct().take(40)

        return try {
            if (entryId.isNullOrBlank()) {
                col.document().set(
                    mapOf(
                        "groupId" to group.id,
                        "eventId" to eventId,
                        "memberUids" to group.memberUids,
                        "invitedEmails" to group.invitedEmails,
                        "entryType" to entryType.name,
                        "amount" to amount,
                        "categoryId" to category.id.ifBlank { category.name },
                        "categoryName" to category.name.take(50),
                        "categoryColorHex" to category.colorHex,
                        "categoryIconKey" to category.iconKey,
                        "participantId" to participant.id,
                        "participantName" to participant.name.take(60),
                        "splitMode" to splitMode.name,
                        "splitParticipantIds" to cleanSplits,
                        "paymentMode" to paymentMode.name,
                        "dateMillis" to dateMillis.coerceAtLeast(1L),
                        "notes" to cleanNotes,
                        "createdBy" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            } else {
                col.document(entryId).update(
                    mapOf(
                        "entryType" to entryType.name,
                        "amount" to amount,
                        "categoryId" to category.id.ifBlank { category.name },
                        "categoryName" to category.name.take(50),
                        "categoryColorHex" to category.colorHex,
                        "categoryIconKey" to category.iconKey,
                        "participantId" to participant.id,
                        "participantName" to participant.name.take(60),
                        "splitMode" to splitMode.name,
                        "splitParticipantIds" to cleanSplits,
                        "paymentMode" to paymentMode.name,
                        "dateMillis" to dateMillis.coerceAtLeast(1L),
                        "notes" to cleanNotes,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, col.path)
            Result.failure(e)
        }
    }

    suspend fun deleteEventEntry(groupId: String, entryId: String): Result<Unit> {
        val path = "familyGroups/$groupId/eventEntries/$entryId"
        return try {
            requireUserId()
            db.collection("familyGroups").document(groupId)
                .collection("eventEntries").document(entryId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- GOOGLE BACKUP & RESTORE (JSON) ---

    fun buildBackupJson(
        group: FamilyGroup,
        members: List<FamilyMember>,
        categories: List<KhataCategory>,
        transactions: List<MonthlyTransaction>,
        events: List<FamilyEvent>,
        participants: List<EventParticipant>,
        entries: List<EventEntry>,
    ): String {
        val root = JSONObject().apply {
            put("schemaVersion", 1)
            put("exportedAtMillis", System.currentTimeMillis())
            put("group", JSONObject().apply {
                put("name", group.name)
                put("currencySymbol", group.currencySymbol)
                put("cycleStartDay", group.cycleStartDay)
            })
            put("members", JSONArray().apply {
                members.forEach { m ->
                    put(JSONObject().apply {
                        put("id", m.id)
                        put("name", m.name)
                        put("email", m.email)
                        put("phone", m.phone)
                        put("role", m.role)
                        put("avatarColorHex", m.avatarColorHex)
                    })
                }
            })
            put("categories", JSONArray().apply {
                categories.forEach { c ->
                    put(JSONObject().apply {
                        put("id", c.id)
                        put("name", c.name)
                        put("nameBn", c.nameBn)
                        put("scope", c.scope)
                        put("type", c.type)
                        put("iconKey", c.iconKey)
                        put("colorHex", c.colorHex)
                        put("builtIn", c.builtIn)
                    })
                }
            })
            put("transactions", JSONArray().apply {
                transactions.forEach { t ->
                    put(JSONObject().apply {
                        put("id", t.id)
                        put("type", t.type)
                        put("amount", t.amount)
                        put("categoryId", t.categoryId)
                        put("categoryName", t.categoryName)
                        put("categoryColorHex", t.categoryColorHex)
                        put("categoryIconKey", t.categoryIconKey)
                        put("paidByMemberId", t.paidByMemberId)
                        put("paidByName", t.paidByName)
                        put("splitMode", t.splitMode)
                        put("splitMemberIds", JSONArray(t.splitMemberIds))
                        put("paymentMode", t.paymentMode)
                        put("dateMillis", t.dateMillis)
                        put("notes", t.notes)
                    })
                }
            })
            put("events", JSONArray().apply {
                events.forEach { ev ->
                    put(JSONObject().apply {
                        put("id", ev.id)
                        put("title", ev.title)
                        put("eventType", ev.eventType)
                        put("budget", ev.budget)
                        put("startDateMillis", ev.startDateMillis)
                        put("endDateMillis", ev.endDateMillis)
                        put("venue", ev.venue)
                        put("notes", ev.notes)
                        put("accentColorHex", ev.accentColorHex)
                        put("status", ev.status)
                    })
                }
            })
            put("eventParticipants", JSONArray().apply {
                participants.forEach { p ->
                    put(JSONObject().apply {
                        put("id", p.id)
                        put("eventId", p.eventId)
                        put("name", p.name)
                        put("contact", p.contact)
                        put("participantKind", p.participantKind)
                        put("familyMemberId", p.familyMemberId)
                        put("avatarColorHex", p.avatarColorHex)
                    })
                }
            })
            put("eventEntries", JSONArray().apply {
                entries.forEach { ee ->
                    put(JSONObject().apply {
                        put("id", ee.id)
                        put("eventId", ee.eventId)
                        put("entryType", ee.entryType)
                        put("amount", ee.amount)
                        put("categoryId", ee.categoryId)
                        put("categoryName", ee.categoryName)
                        put("categoryColorHex", ee.categoryColorHex)
                        put("categoryIconKey", ee.categoryIconKey)
                        put("participantId", ee.participantId)
                        put("participantName", ee.participantName)
                        put("splitMode", ee.splitMode)
                        put("splitParticipantIds", JSONArray(ee.splitParticipantIds))
                        put("paymentMode", ee.paymentMode)
                        put("dateMillis", ee.dateMillis)
                        put("notes", ee.notes)
                    })
                }
            })
        }
        return root.toString(2)
    }

    suspend fun restoreFromBackupJson(group: FamilyGroup, rawJson: String): Result<Int> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        return try {
            val root = JSONObject(rawJson)
            val groupRef = db.collection("familyGroups").document(group.id)
            var restoredCount = 0

            val memberIdMap = mutableMapOf<String, String>()
            val eventIdMap = mutableMapOf<String, String>()
            val participantIdMap = mutableMapOf<String, String>()

            // 1. Categories (only restore missing custom categories)
            val cats = root.optJSONArray("categories") ?: JSONArray()
            val catOps = mutableListOf<Pair<DocumentReference, Map<String, Any>>>()
            for (i in 0 until cats.length()) {
                val obj = cats.getJSONObject(i)
                val origId = obj.optString("id").ifBlank { "cat_${UUID.randomUUID()}" }
                val safeId = origId.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(100)
                val catRef = groupRef.collection("categories").document(safeId)
                val existing = catRef.get().await()
                if (!existing.exists()) {
                    val catName = obj.optString("name").trim().ifBlank { "Restored Category" }.take(50)
                    val catScope = com.example.model.safeEnum(obj.optString("scope"), CategoryScope.MONTHLY).name
                    val catType = com.example.model.safeEnum(obj.optString("type"), CategoryType.EXPENSE).name
                    val catIcon = obj.optString("iconKey").trim().ifBlank { "custom_star" }.take(40)
                    val catColor = obj.optString("colorHex").trim().let { if (it.length >= 4) it else "#0F766E" }.take(10)
                    catOps.add(
                        catRef to mapOf(
                            "groupId" to group.id,
                            "memberUids" to group.memberUids,
                            "invitedEmails" to group.invitedEmails,
                            "name" to catName,
                            "nameBn" to obj.optString("nameBn").trim().take(60),
                            "scope" to catScope,
                            "type" to catType,
                            "iconKey" to catIcon,
                            "colorHex" to catColor,
                            "builtIn" to obj.optBoolean("builtIn", false),
                            "createdBy" to uid,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp(),
                        )
                    )
                    restoredCount++
                }
            }
            commitSetsInChunks(catOps)

            // 2. Members
            val mems = root.optJSONArray("members") ?: JSONArray()
            val memOps = mutableListOf<Pair<DocumentReference, Map<String, Any>>>()
            for (i in 0 until mems.length()) {
                val obj = mems.getJSONObject(i)
                val oldId = obj.optString("id")
                val newRef = groupRef.collection("members").document()
                if (oldId.isNotBlank()) memberIdMap[oldId] = newRef.id
                val memName = obj.optString("name").trim().ifBlank { "Member" }.take(60)
                val memRole = com.example.model.safeEnum(obj.optString("role"), MemberRole.MEMBER).name
                val memColor = obj.optString("avatarColorHex").trim().let { if (it.length >= 4) it else "#0F766E" }.take(10)
                memOps.add(
                    newRef to mapOf(
                        "groupId" to group.id,
                        "memberUids" to group.memberUids,
                        "invitedEmails" to group.invitedEmails,
                        "name" to memName,
                        "email" to obj.optString("email").trim().take(120),
                        "phone" to obj.optString("phone").trim().take(30),
                        "role" to memRole,
                        "linkedUid" to "",
                        "avatarColorHex" to memColor,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
                restoredCount++
            }
            commitSetsInChunks(memOps)

            // 3. Transactions
            val txs = root.optJSONArray("transactions") ?: JSONArray()
            val txOps = mutableListOf<Pair<DocumentReference, Map<String, Any>>>()
            for (i in 0 until txs.length()) {
                val obj = txs.getJSONObject(i)
                val oldPaidBy = obj.optString("paidByMemberId")
                val mappedPaidBy = (memberIdMap[oldPaidBy] ?: oldPaidBy).ifBlank { "restored_member" }
                val rawSplits = obj.optJSONArray("splitMemberIds") ?: JSONArray()
                val mappedSplits = (0 until rawSplits.length()).map { idx ->
                    val old = rawSplits.optString(idx)
                    memberIdMap[old] ?: old
                }.filter { it.isNotBlank() }.take(25)

                val txType = com.example.model.safeEnum(obj.optString("type"), TransactionType.EXPENSE).name
                val txSplit = com.example.model.safeEnum(obj.optString("splitMode"), SplitMode.FULL_FAMILY).name
                val txPay = com.example.model.safeEnum(obj.optString("paymentMode"), PaymentMode.UPI).name
                val txAmount = obj.optDouble("amount", 1.0).let { if (it.isNaN() || it <= 0.0) 1.0 else it.coerceAtMost(1_000_000_000.0) }
                val txCatId = obj.optString("categoryId").trim().ifBlank { "cat_groceries" }.take(128)
                val txCatName = obj.optString("categoryName").trim().ifBlank { "General" }.take(50)
                val txCatColor = obj.optString("categoryColorHex").trim().let { if (it.length >= 4) it else "#0F766E" }.take(10)
                val txCatIcon = obj.optString("categoryIconKey").trim().ifBlank { "custom_star" }.take(40)
                val txPaidByName = obj.optString("paidByName").trim().ifBlank { "Member" }.take(60)

                val txRef = groupRef.collection("transactions").document()
                txOps.add(
                    txRef to mapOf(
                        "groupId" to group.id,
                        "memberUids" to group.memberUids,
                        "invitedEmails" to group.invitedEmails,
                        "type" to txType,
                        "amount" to txAmount,
                        "categoryId" to txCatId,
                        "categoryName" to txCatName,
                        "categoryColorHex" to txCatColor,
                        "categoryIconKey" to txCatIcon,
                        "paidByMemberId" to mappedPaidBy.take(128),
                        "paidByName" to txPaidByName,
                        "splitMode" to txSplit,
                        "splitMemberIds" to mappedSplits,
                        "paymentMode" to txPay,
                        "dateMillis" to obj.optLong("dateMillis", System.currentTimeMillis()).coerceAtLeast(1L),
                        "notes" to obj.optString("notes").trim().take(300),
                        "createdBy" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
                restoredCount++
            }
            commitSetsInChunks(txOps)

            // 4. Events (commit first so security rules verify parent event existence for participants/entries)
            val evs = root.optJSONArray("events") ?: JSONArray()
            val evOps = mutableListOf<Pair<DocumentReference, Map<String, Any>>>()
            for (i in 0 until evs.length()) {
                val obj = evs.getJSONObject(i)
                val oldEvId = obj.optString("id")
                val evRef = groupRef.collection("events").document()
                if (oldEvId.isNotBlank()) eventIdMap[oldEvId] = evRef.id
                val evTitle = obj.optString("title").trim().ifBlank { "Restored Event" }.take(80)
                val evType = com.example.model.safeEnum(obj.optString("eventType"), EventType.OTHER).name
                val evStatus = com.example.model.safeEnum(obj.optString("status"), EventStatus.ACTIVE).name
                val evColor = obj.optString("accentColorHex").trim().let { if (it.length >= 4) it else "#D97706" }.take(10)
                val evBudget = obj.optDouble("budget", 0.0).let { if (it.isNaN() || it < 0.0) 0.0 else it.coerceAtMost(1_000_000_000.0) }
                evOps.add(
                    evRef to mapOf(
                        "groupId" to group.id,
                        "memberUids" to group.memberUids,
                        "invitedEmails" to group.invitedEmails,
                        "title" to evTitle,
                        "eventType" to evType,
                        "budget" to evBudget,
                        "startDateMillis" to obj.optLong("startDateMillis", System.currentTimeMillis()).coerceAtLeast(1L),
                        "endDateMillis" to obj.optLong("endDateMillis", 0L).coerceAtLeast(0L),
                        "venue" to obj.optString("venue").trim().take(120),
                        "notes" to obj.optString("notes").trim().take(400),
                        "accentColorHex" to evColor,
                        "status" to evStatus,
                        "createdBy" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
                restoredCount++
            }
            commitSetsInChunks(evOps)

            // 5. Event Participants
            val parts = root.optJSONArray("eventParticipants") ?: JSONArray()
            val partOps = mutableListOf<Pair<DocumentReference, Map<String, Any>>>()
            for (i in 0 until parts.length()) {
                val obj = parts.getJSONObject(i)
                val mappedEventId = eventIdMap[obj.optString("eventId")] ?: continue
                val oldPartId = obj.optString("id")
                val pRef = groupRef.collection("eventParticipants").document()
                if (oldPartId.isNotBlank()) participantIdMap[oldPartId] = pRef.id
                val oldFamId = obj.optString("familyMemberId")
                val pName = obj.optString("name").trim().ifBlank { "Participant" }.take(60)
                val pKind = com.example.model.safeEnum(obj.optString("participantKind"), ParticipantKind.GUEST_FRIEND).name
                val pColor = obj.optString("avatarColorHex").trim().let { if (it.length >= 4) it else "#E05D38" }.take(10)
                partOps.add(
                    pRef to mapOf(
                        "groupId" to group.id,
                        "eventId" to mappedEventId,
                        "memberUids" to group.memberUids,
                        "invitedEmails" to group.invitedEmails,
                        "name" to pName,
                        "contact" to obj.optString("contact").trim().take(120),
                        "participantKind" to pKind,
                        "familyMemberId" to (memberIdMap[oldFamId] ?: oldFamId).take(128),
                        "avatarColorHex" to pColor,
                        "createdBy" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
                restoredCount++
            }
            commitSetsInChunks(partOps)

            // 6. Event Entries
            val entries = root.optJSONArray("eventEntries") ?: JSONArray()
            val entryOps = mutableListOf<Pair<DocumentReference, Map<String, Any>>>()
            for (i in 0 until entries.length()) {
                val obj = entries.getJSONObject(i)
                val mappedEventId = eventIdMap[obj.optString("eventId")] ?: continue
                val oldPid = obj.optString("participantId")
                val mappedPid = (participantIdMap[oldPid] ?: oldPid).ifBlank { "restored_participant" }
                val rawSplits = obj.optJSONArray("splitParticipantIds") ?: JSONArray()
                val mappedSplits = (0 until rawSplits.length()).map { idx ->
                    val old = rawSplits.optString(idx)
                    participantIdMap[old] ?: old
                }.filter { it.isNotBlank() }.take(40)

                val eeType = com.example.model.safeEnum(obj.optString("entryType"), EventEntryType.EXPENSE).name
                val eeSplit = com.example.model.safeEnum(obj.optString("splitMode"), EventSplitMode.ALL_PARTICIPANTS).name
                val eePay = com.example.model.safeEnum(obj.optString("paymentMode"), PaymentMode.UPI).name
                val eeAmount = obj.optDouble("amount", 1.0).let { if (it.isNaN() || it <= 0.0) 1.0 else it.coerceAtMost(1_000_000_000.0) }
                val eeCatId = obj.optString("categoryId").trim().ifBlank { "cat_catering" }.take(128)
                val eeCatName = obj.optString("categoryName").trim().ifBlank { "Event Expense" }.take(50)
                val eeCatColor = obj.optString("categoryColorHex").trim().let { if (it.length >= 4) it else "#D97706" }.take(10)
                val eeCatIcon = obj.optString("categoryIconKey").trim().ifBlank { "party" }.take(40)
                val eePartName = obj.optString("participantName").trim().ifBlank { "Participant" }.take(60)

                val eeRef = groupRef.collection("eventEntries").document()
                entryOps.add(
                    eeRef to mapOf(
                        "groupId" to group.id,
                        "eventId" to mappedEventId,
                        "memberUids" to group.memberUids,
                        "invitedEmails" to group.invitedEmails,
                        "entryType" to eeType,
                        "amount" to eeAmount,
                        "categoryId" to eeCatId,
                        "categoryName" to eeCatName,
                        "categoryColorHex" to eeCatColor,
                        "categoryIconKey" to eeCatIcon,
                        "participantId" to mappedPid.take(128),
                        "participantName" to eePartName,
                        "splitMode" to eeSplit,
                        "splitParticipantIds" to mappedSplits,
                        "paymentMode" to eePay,
                        "dateMillis" to obj.optLong("dateMillis", System.currentTimeMillis()).coerceAtLeast(1L),
                        "notes" to obj.optString("notes").trim().take(300),
                        "createdBy" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
                restoredCount++
            }
            commitSetsInChunks(entryOps)

            updateUserProfile(lastBackupAtMillis = System.currentTimeMillis())
            Result.success(restoredCount)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "familyGroups/${group.id}/restore")
            Result.failure(e)
        }
    }

    // --- HELPERS ---

    private suspend fun propagateGroupAuthFields(
        groupId: String,
        memberUids: List<String>,
        invitedEmails: List<String>,
    ) {
        val uid = auth.currentUser?.uid ?: return
        val groupRef = db.collection("familyGroups").document(groupId)
        val subCollections = listOf("members", "categories", "transactions", "events", "eventParticipants", "eventEntries")
        val updates = mutableListOf<Pair<DocumentReference, Map<String, Any>>>()
        for (sub in subCollections) {
            val snap = groupRef.collection(sub).whereArrayContains("memberUids", uid).get().await()
            snap.documents.forEach { doc ->
                updates.add(
                    doc.reference to mapOf(
                        "memberUids" to memberUids,
                        "invitedEmails" to invitedEmails,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }
        }
        commitUpdatesInChunks(updates)
    }

    private suspend fun commitUpdatesInChunks(ops: List<Pair<DocumentReference, Map<String, Any>>>) {
        ops.chunked(400).forEach { chunk ->
            val batch = db.batch()
            chunk.forEach { (ref, map) -> batch.update(ref, map) }
            batch.commit().await()
        }
    }

    private suspend fun commitSetsInChunks(ops: List<Pair<DocumentReference, Map<String, Any>>>) {
        ops.chunked(400).forEach { chunk ->
            val batch = db.batch()
            chunk.forEach { (ref, map) -> batch.set(ref, map) }
            batch.commit().await()
        }
    }

    private suspend fun commitDeletesInChunks(refs: List<DocumentReference>) {
        refs.chunked(400).forEach { chunk ->
            val batch = db.batch()
            chunk.forEach { ref -> batch.delete(ref) }
            batch.commit().await()
        }
    }
}
