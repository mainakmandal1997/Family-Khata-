package com.example.security

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.MessageDigest
import java.security.SecureRandom

private val Context.khataPrefsDataStore: DataStore<Preferences> by preferencesDataStore(name = "family_khata_prefs")

enum class ThemeMode(val labelEn: String, val labelBn: String) {
    SYSTEM("System Default", "সিস্টেম ডিফল্ট"),
    LIGHT("Light Mode", "লাইট মোড"),
    DARK("Dark Mode", "ডার্ক মোড"),
}

enum class AutoLockTimeout(val seconds: Int, val labelEn: String, val labelBn: String) {
    IMMEDIATE(0, "Immediately", "তাৎক্ষণিক"),
    SEC_30(30, "30 seconds", "৩০ সেকেন্ড"),
    MIN_1(60, "1 minute", "১ মিনিট"),
    MIN_5(300, "5 minutes", "৫ মিনিট"),
    MIN_15(900, "15 minutes", "১৫ মিনিট");

    companion object {
        fun fromSeconds(sec: Int): AutoLockTimeout {
            return entries.firstOrNull { it.seconds == sec } ?: IMMEDIATE
        }
    }
}

data class AppPreferencesState(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val isAppLockEnabled: Boolean = false,
    val pinLength: Int = 4,
    val hasPinSet: Boolean = false,
    val isBiometricEnabled: Boolean = false,
    val autoLockTimeout: AutoLockTimeout = AutoLockTimeout.IMMEDIATE,
)

object PinCrypto {
    private val random = SecureRandom()

    fun generateSaltHex(): String {
        val bytes = ByteArray(16)
        random.nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun hashPin(pin: String, saltHex: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest("$saltHex:$pin".toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var diff = 0
        for (i in a.indices) {
            diff = diff or (a[i].code xor b[i].code)
        }
        return diff == 0
    }

    fun shouldLockOnResume(
        isAppLockEnabled: Boolean,
        hasPinSet: Boolean,
        lastBackgroundMillis: Long,
        nowMillis: Long,
        timeout: AutoLockTimeout,
    ): Boolean {
        if (!isAppLockEnabled || !hasPinSet) return false
        if (lastBackgroundMillis <= 0L) return false
        val elapsedMillis = (nowMillis - lastBackgroundMillis).coerceAtLeast(0L)
        return elapsedMillis >= timeout.seconds * 1000L
    }
}

class AppPreferencesStore(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val APP_LOCK_ENABLED = booleanPreferencesKey("app_lock_enabled")
        val PIN_LENGTH = intPreferencesKey("pin_length")
        val PIN_SALT = stringPreferencesKey("pin_salt")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
        val AUTO_LOCK_SECONDS = intPreferencesKey("auto_lock_seconds")
        val LAST_BACKGROUND_MILLIS = longPreferencesKey("last_background_millis")
    }

    val preferencesFlow: Flow<AppPreferencesState> = context.khataPrefsDataStore.data.map { prefs ->
        val themeRaw = prefs[Keys.THEME_MODE] ?: ThemeMode.SYSTEM.name
        val theme = ThemeMode.entries.firstOrNull { it.name == themeRaw } ?: ThemeMode.SYSTEM
        val pinHash = prefs[Keys.PIN_HASH].orEmpty()
        val pinLen = (prefs[Keys.PIN_LENGTH] ?: 4).let { if (it == 6) 6 else 4 }
        val timeoutSec = prefs[Keys.AUTO_LOCK_SECONDS] ?: 0
        AppPreferencesState(
            themeMode = theme,
            isAppLockEnabled = prefs[Keys.APP_LOCK_ENABLED] ?: false,
            pinLength = pinLen,
            hasPinSet = pinHash.isNotBlank(),
            isBiometricEnabled = prefs[Keys.BIOMETRIC_ENABLED] ?: false,
            autoLockTimeout = AutoLockTimeout.fromSeconds(timeoutSec),
        )
    }

    suspend fun getSnapshot(): AppPreferencesState = preferencesFlow.first()

    suspend fun setThemeMode(mode: ThemeMode) {
        context.khataPrefsDataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = mode.name
        }
    }

    suspend fun cycleThemeMode(): ThemeMode {
        var next = ThemeMode.SYSTEM
        context.khataPrefsDataStore.edit { prefs ->
            val currentRaw = prefs[Keys.THEME_MODE] ?: ThemeMode.SYSTEM.name
            val current = ThemeMode.entries.firstOrNull { it.name == currentRaw } ?: ThemeMode.SYSTEM
            next = when (current) {
                ThemeMode.SYSTEM -> ThemeMode.LIGHT
                ThemeMode.LIGHT -> ThemeMode.DARK
                ThemeMode.DARK -> ThemeMode.SYSTEM
            }
            prefs[Keys.THEME_MODE] = next.name
        }
        return next
    }

    suspend fun setupOrUpdatePin(pin: String, pinLength: Int, enableLock: Boolean = true) {
        val validLength = if (pinLength == 6) 6 else 4
        require(pin.length == validLength && pin.all { it.isDigit() }) {
            "PIN must be $validLength digits"
        }
        val salt = PinCrypto.generateSaltHex()
        val hash = PinCrypto.hashPin(pin, salt)
        context.khataPrefsDataStore.edit { prefs ->
            prefs[Keys.PIN_LENGTH] = validLength
            prefs[Keys.PIN_SALT] = salt
            prefs[Keys.PIN_HASH] = hash
            prefs[Keys.APP_LOCK_ENABLED] = enableLock
            prefs[Keys.LAST_BACKGROUND_MILLIS] = 0L
        }
    }

    suspend fun verifyPin(pin: String): Boolean {
        val prefs = context.khataPrefsDataStore.data.first()
        val salt = prefs[Keys.PIN_SALT].orEmpty()
        val storedHash = prefs[Keys.PIN_HASH].orEmpty()
        if (salt.isBlank() || storedHash.isBlank()) return false
        val computed = PinCrypto.hashPin(pin, salt)
        return PinCrypto.constantTimeEquals(computed, storedHash)
    }

    suspend fun setAppLockEnabled(enabled: Boolean) {
        context.khataPrefsDataStore.edit { prefs ->
            prefs[Keys.APP_LOCK_ENABLED] = enabled
            if (!enabled) {
                prefs[Keys.LAST_BACKGROUND_MILLIS] = 0L
            }
        }
    }

    suspend fun clearPinAndDisableLock() {
        context.khataPrefsDataStore.edit { prefs ->
            prefs[Keys.APP_LOCK_ENABLED] = false
            prefs.remove(Keys.PIN_SALT)
            prefs.remove(Keys.PIN_HASH)
            prefs[Keys.BIOMETRIC_ENABLED] = false
            prefs[Keys.LAST_BACKGROUND_MILLIS] = 0L
        }
    }

    suspend fun setBiometricEnabled(enabled: Boolean) {
        context.khataPrefsDataStore.edit { prefs ->
            prefs[Keys.BIOMETRIC_ENABLED] = enabled
        }
    }

    suspend fun setAutoLockTimeout(timeout: AutoLockTimeout) {
        context.khataPrefsDataStore.edit { prefs ->
            prefs[Keys.AUTO_LOCK_SECONDS] = timeout.seconds
        }
    }

    suspend fun recordBackgroundTimestamp(millis: Long) {
        context.khataPrefsDataStore.edit { prefs ->
            prefs[Keys.LAST_BACKGROUND_MILLIS] = millis
        }
    }

    suspend fun shouldLockOnResume(nowMillis: Long): Boolean {
        val prefs = context.khataPrefsDataStore.data.first()
        val enabled = prefs[Keys.APP_LOCK_ENABLED] ?: false
        val hasPin = !prefs[Keys.PIN_HASH].isNullOrBlank()
        val lastBg = prefs[Keys.LAST_BACKGROUND_MILLIS] ?: 0L
        val timeout = AutoLockTimeout.fromSeconds(prefs[Keys.AUTO_LOCK_SECONDS] ?: 0)
        return PinCrypto.shouldLockOnResume(enabled, hasPin, lastBg, nowMillis, timeout)
    }
}
