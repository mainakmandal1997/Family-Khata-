package com.example

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.Celebration
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.BrightnessAuto
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.Celebration
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.attemptAutoSignIn
import com.example.auth.authStateFlow
import com.example.auth.signOut
import com.example.data.KhataRepository
import com.example.logic.AppStrings
import com.example.logic.StringsProvider
import com.example.security.AppPreferencesState
import com.example.security.AppPreferencesStore
import com.example.security.AutoLockTimeout
import com.example.security.ThemeMode
import com.example.ui.GroupWorkspaceData
import com.example.ui.KhataViewModel
import com.example.ui.UiState
import com.example.ui.components.KhataText
import com.example.ui.screens.AppLockScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.CreateGroupOnboardingScreen
import com.example.ui.screens.FamilyEventsScreen
import com.example.ui.screens.MonthlyKhataScreen
import com.example.ui.screens.ReportsAndSettingsScreen
import com.example.ui.theme.FamilyKhataTheme
import com.example.ui.theme.LocalKhataSemanticColors
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

private enum class KhataTab(
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
) {
    KHATA(Icons.Rounded.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet, "nav_tab_khata"),
    EVENTS(Icons.Rounded.Celebration, Icons.Outlined.Celebration, "nav_tab_events"),
    CATEGORIES(Icons.Rounded.Category, Icons.Outlined.Category, "nav_tab_categories"),
    REPORTS(Icons.Rounded.Assessment, Icons.Outlined.Assessment, "nav_tab_reports"),
}

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val prefsStore = remember(applicationContext) { AppPreferencesStore(applicationContext) }
            val appPrefsState by prefsStore.preferencesFlow.collectAsStateWithLifecycle(initialValue = null)
            val appPrefs = appPrefsState ?: AppPreferencesState()
            val systemDark = isSystemInDarkTheme()
            val useDarkTheme = when (appPrefs.themeMode) {
                ThemeMode.SYSTEM -> systemDark
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }

            LaunchedEffect(useDarkTheme) {
                enableEdgeToEdge(
                    statusBarStyle = if (useDarkTheme) {
                        SystemBarStyle.dark(AndroidColor.TRANSPARENT)
                    } else {
                        SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
                    },
                    navigationBarStyle = if (useDarkTheme) {
                        SystemBarStyle.dark(AndroidColor.TRANSPARENT)
                    } else {
                        SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
                    },
                )
            }

            FamilyKhataTheme(darkTheme = useDarkTheme) {
                if (appPrefsState == null) {
                    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                        Box(contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    }
                } else {
                    FamilyKhataRoot(
                        prefsStore = prefsStore,
                        appPrefs = appPrefs,
                    )
                }
            }
        }
    }
}

@Composable
private fun FamilyKhataRoot(
    prefsStore: AppPreferencesStore,
    appPrefs: AppPreferencesState,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val authUser by Firebase.auth.authStateFlow()
        .collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)
    var isCheckingAutoSignIn by remember { mutableStateOf(Firebase.auth.currentUser == null) }
    var isAppUnlocked by rememberSaveable {
        mutableStateOf(!(appPrefs.isAppLockEnabled && appPrefs.hasPinSet))
    }

    // Enforce background auto-lock timeout across app lifecycle
    DisposableEffect(lifecycleOwner, prefsStore) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> {
                    scope.launch {
                        prefsStore.recordBackgroundTimestamp(System.currentTimeMillis())
                    }
                }
                Lifecycle.Event.ON_START -> {
                    scope.launch {
                        if (prefsStore.shouldLockOnResume(System.currentTimeMillis())) {
                            isAppUnlocked = false
                        }
                    }
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(Unit) {
        if (Firebase.auth.currentUser == null) {
            attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = { isCheckingAutoSignIn = false },
                onUnauthenticated = { isCheckingAutoSignIn = false },
                scope = scope,
            )
        } else {
            isCheckingAutoSignIn = false
        }
    }

    val currentUser = authUser
    when {
        isCheckingAutoSignIn -> {
            Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Box(contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        CircularProgressIndicator()
                        Text(
                            text = "Family Khata",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
        currentUser == null -> {
            AuthScreen(onAuthSuccess = { isCheckingAutoSignIn = false })
        }
        appPrefs.isAppLockEnabled && appPrefs.hasPinSet && !isAppUnlocked -> {
            AppLockScreen(
                pinLength = appPrefs.pinLength,
                biometricEnabled = appPrefs.isBiometricEnabled,
                isBengali = false,
                onVerifyPin = { entered -> prefsStore.verifyPin(entered) },
                onUnlocked = { isAppUnlocked = true },
                onResetPinSignOut = {
                    scope.launch {
                        prefsStore.clearPinAndDisableLock()
                        isAppUnlocked = true
                        signOut(credentialManager = credentialManager, scope = scope)
                    }
                },
            )
        }
        else -> {
            key(currentUser.uid) {
                AuthenticatedKhataApp(
                    user = currentUser,
                    appPrefs = appPrefs,
                    onCycleThemeMode = { scope.launch { prefsStore.cycleThemeMode() } },
                    onSetThemeMode = { mode -> scope.launch { prefsStore.setThemeMode(mode) } },
                    onSavePin = { pin, len ->
                        scope.launch {
                            prefsStore.setupOrUpdatePin(pin, len, enableLock = true)
                            isAppUnlocked = true
                        }
                    },
                    onToggleAppLock = { enabled ->
                        scope.launch {
                            prefsStore.setAppLockEnabled(enabled)
                            if (!enabled) isAppUnlocked = true
                        }
                    },
                    onToggleBiometric = { enabled ->
                        scope.launch { prefsStore.setBiometricEnabled(enabled) }
                    },
                    onSetAutoLockTimeout = { timeout ->
                        scope.launch { prefsStore.setAutoLockTimeout(timeout) }
                    },
                    onClearPin = {
                        scope.launch {
                            prefsStore.clearPinAndDisableLock()
                            isAppUnlocked = true
                        }
                    },
                    onSignOut = {
                        isAppUnlocked = true
                        signOut(credentialManager = credentialManager, scope = scope)
                    },
                )
            }
        }
    }
}

@Composable
private fun AuthenticatedKhataApp(
    user: FirebaseUser,
    appPrefs: AppPreferencesState,
    onCycleThemeMode: () -> Unit,
    onSetThemeMode: (ThemeMode) -> Unit,
    onSavePin: (pin: String, pinLength: Int) -> Unit,
    onToggleAppLock: (Boolean) -> Unit,
    onToggleBiometric: (Boolean) -> Unit,
    onSetAutoLockTimeout: (AutoLockTimeout) -> Unit,
    onClearPin: () -> Unit,
    onSignOut: () -> Unit,
) {
    val context = LocalContext.current
    val semanticColors = LocalKhataSemanticColors.current
    val viewModel: KhataViewModel = viewModel(
        key = user.uid,
        factory = viewModelFactory {
            initializer {
                val appContext = context.applicationContext
                val dbId = appContext.getString(R.string.firestore_database_id)
                val repository = KhataRepository(FirebaseFirestore.getInstance(dbId))
                KhataViewModel(
                    repository = repository,
                    currentUserId = user.uid,
                    userDisplayName = user.displayName.orEmpty().ifBlank { "Family Member" },
                    userEmail = user.email.orEmpty(),
                )
            }
        },
    )

    val workspaceState by viewModel.workspaceState.collectAsStateWithLifecycle()
    val userProfileState by viewModel.userProfileState.collectAsStateWithLifecycle()
    val dashboardScope by viewModel.dashboardScope.collectAsStateWithLifecycle()
    val selectedPeriod by viewModel.selectedPeriod.collectAsStateWithLifecycle()
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val customDateRange by viewModel.customDateRange.collectAsStateWithLifecycle()
    val dashboardEventId by viewModel.dashboardEventId.collectAsStateWithLifecycle()
    val filters by viewModel.filters.collectAsStateWithLifecycle()
    val selectedEventId by viewModel.selectedEventId.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(viewModel) {
        viewModel.snackbarEvents.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val profile = (userProfileState as? UiState.Success)?.data
    val isBengali = profile?.preferredLanguage == "bn"
    val strings = remember(isBengali) { StringsProvider.get(isBengali) }

    when (val state = workspaceState) {
        is UiState.Loading -> {
            Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Box(contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        CircularProgressIndicator()
                        KhataText(
                            text = "Syncing Family Khata...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
        is UiState.Error -> {
            Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.widthIn(max = 420.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ErrorOutline,
                            contentDescription = "Sync error",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(48.dp),
                        )
                        Text(
                            text = "Unable to load Family Khata",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = state.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Button(onClick = onSignOut) {
                            Text("Sign Out")
                        }
                    }
                }
            }
        }
        is UiState.Success -> {
            val data: GroupWorkspaceData = state.data
            if (data.activeGroup == null) {
                Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { padding ->
                    Box(modifier = Modifier.fillMaxSize().padding(padding)) {
                        CreateGroupOnboardingScreen(
                            userDisplayName = user.displayName.orEmpty().ifBlank { "Family Admin" },
                            userEmail = user.email.orEmpty(),
                            pendingInvites = data.pendingInvites,
                            isBusy = isBusy,
                            onAcceptInvite = { invite -> viewModel.acceptInvite(invite) },
                            onCreateGroup = { name, currency, cycleDay, phone ->
                                viewModel.createFamilyGroup(name, currency, cycleDay, phone)
                            },
                            onSignOutClick = onSignOut,
                        )
                    }
                }
            } else {
                var selectedTab by rememberSaveable { mutableStateOf(KhataTab.KHATA) }
                val activeGroup = data.activeGroup

                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val useNavigationRail = maxWidth >= 600.dp

                    Scaffold(
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        topBar = {
                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                tonalElevation = 2.dp,
                            ) {
                                Column {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .statusBarsPadding()
                                            .padding(horizontal = 16.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            ) {
                                                KhataText(
                                                    text = activeGroup.name,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                                Icon(
                                                    imageVector = Icons.Rounded.CloudDone,
                                                    contentDescription = "Live Cloud Sync active",
                                                    tint = semanticColors.income,
                                                    modifier = Modifier.size(16.dp),
                                                )
                                            }
                                            KhataText(
                                                text = "${strings.appSubtitle} • ${activeGroup.currencySymbol}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                        }

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        ) {
                                            IconButton(
                                                onClick = onCycleThemeMode,
                                                modifier = Modifier.size(48.dp).testTag("header_theme_toggle"),
                                            ) {
                                                val themeIcon = when (appPrefs.themeMode) {
                                                    ThemeMode.SYSTEM -> Icons.Rounded.BrightnessAuto
                                                    ThemeMode.LIGHT -> Icons.Rounded.LightMode
                                                    ThemeMode.DARK -> Icons.Rounded.DarkMode
                                                }
                                                Icon(
                                                    imageVector = themeIcon,
                                                    contentDescription = "Switch theme (${appPrefs.themeMode.labelEn})",
                                                    tint = MaterialTheme.colorScheme.primary,
                                                )
                                            }

                                            Surface(
                                                onClick = { viewModel.toggleLanguage(isBengali) },
                                                shape = RoundedCornerShape(50),
                                                color = MaterialTheme.colorScheme.primaryContainer,
                                                modifier = Modifier
                                                    .height(48.dp)
                                                    .testTag("header_language_toggle"),
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 12.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Rounded.Translate,
                                                        contentDescription = "Switch language",
                                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                                        modifier = Modifier.size(18.dp),
                                                    )
                                                    KhataText(
                                                        text = if (isBengali) "EN" else "বাংলা",
                                                        style = MaterialTheme.typography.labelLarge,
                                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                        fontWeight = FontWeight.Bold,
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    if (isBusy) {
                                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(2.dp))
                                    } else {
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                    }
                                }
                            }
                        },
                        bottomBar = {
                            if (!useNavigationRail) {
                                NavigationBar(
                                    windowInsets = WindowInsets.navigationBars,
                                    containerColor = MaterialTheme.colorScheme.surface,
                                ) {
                                    KhataTab.entries.forEach { tab ->
                                        val label = tabLabel(tab, strings)
                                        val isSelected = selectedTab == tab
                                        NavigationBarItem(
                                            selected = isSelected,
                                            onClick = { selectedTab = tab },
                                            icon = {
                                                Icon(
                                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                                    contentDescription = label,
                                                )
                                            },
                                            label = {
                                                KhataText(
                                                    text = label,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                            },
                                            modifier = Modifier.testTag(tab.testTag),
                                        )
                                    }
                                }
                            }
                        },
                    ) { innerPadding ->
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding),
                        ) {
                            if (useNavigationRail) {
                                NavigationRail(
                                    modifier = Modifier.fillMaxHeight(),
                                    containerColor = MaterialTheme.colorScheme.surface,
                                ) {
                                    Spacer(Modifier.height(8.dp))
                                    KhataTab.entries.forEach { tab ->
                                        val label = tabLabel(tab, strings)
                                        val isSelected = selectedTab == tab
                                        NavigationRailItem(
                                            selected = isSelected,
                                            onClick = { selectedTab = tab },
                                            icon = {
                                                Icon(
                                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                                    contentDescription = label,
                                                )
                                            },
                                            label = {
                                                KhataText(
                                                    text = label,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                            },
                                            modifier = Modifier.testTag(tab.testTag),
                                        )
                                    }
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.TopCenter,
                            ) {
                                Box(
                                    modifier = Modifier
                                        .widthIn(max = 920.dp)
                                        .fillMaxSize(),
                                ) {
                                    when (selectedTab) {
                                        KhataTab.KHATA -> {
                                            MonthlyKhataScreen(
                                                data = data,
                                                dashboardScope = dashboardScope,
                                                period = selectedPeriod,
                                                yearPeriod = selectedYear,
                                                customDateRange = customDateRange,
                                                dashboardEventId = dashboardEventId,
                                                filters = filters,
                                                strings = strings,
                                                onSelectDashboardScope = { viewModel.setDashboardScope(it) },
                                                onPreviousMonth = { viewModel.previousMonth() },
                                                onNextMonth = { viewModel.nextMonth() },
                                                onPreviousYear = { viewModel.previousYear() },
                                                onNextYear = { viewModel.nextYear() },
                                                onCustomDateRangeChange = { start, end ->
                                                    viewModel.updateCustomDateRange(start, end)
                                                },
                                                onSelectDashboardEvent = { viewModel.selectDashboardEvent(it) },
                                                onOpenEventDetail = { eventId ->
                                                    viewModel.selectEvent(eventId)
                                                    selectedTab = KhataTab.EVENTS
                                                },
                                                onSearchChange = { viewModel.updateSearchQuery(it) },
                                                onToggleTypeFilter = { viewModel.toggleTypeFilter(it) },
                                                onMemberFilter = { viewModel.setMemberFilter(it) },
                                                onCategoryFilter = { viewModel.setCategoryFilter(it) },
                                                onPaymentModeFilter = { viewModel.setPaymentModeFilter(it) },
                                                onClearFilters = { viewModel.clearFilters() },
                                                onAcceptInvite = { viewModel.acceptInvite(it) },
                                                onSaveTransaction = { txId, type, amount, category, paidBy, splitMode, splitMemberIds, paymentMode, dateMillis, notes ->
                                                    viewModel.saveMonthlyTransaction(
                                                        group = activeGroup,
                                                        txId = txId,
                                                        type = type,
                                                        amount = amount,
                                                        category = category,
                                                        paidBy = paidBy,
                                                        splitMode = splitMode,
                                                        splitMemberIds = splitMemberIds,
                                                        paymentMode = paymentMode,
                                                        dateMillis = dateMillis,
                                                        notes = notes,
                                                    )
                                                },
                                                onDeleteTransaction = { txId ->
                                                    viewModel.deleteMonthlyTransaction(activeGroup.id, txId)
                                                },
                                            )
                                        }
                                        KhataTab.EVENTS -> {
                                            FamilyEventsScreen(
                                                data = data,
                                                selectedEventId = selectedEventId,
                                                strings = strings,
                                                onSelectEvent = { viewModel.selectEvent(it) },
                                                onSaveEvent = { eventId, title, eventType, budget, startDateMillis, endDateMillis, venue, notes, accentColorHex, status, initialMembers ->
                                                    viewModel.saveEvent(
                                                        group = activeGroup,
                                                        eventId = eventId,
                                                        title = title,
                                                        eventType = eventType,
                                                        budget = budget,
                                                        startDateMillis = startDateMillis,
                                                        endDateMillis = endDateMillis,
                                                        venue = venue,
                                                        notes = notes,
                                                        accentColorHex = accentColorHex,
                                                        status = status,
                                                        initialFamilyParticipants = initialMembers,
                                                    ) { newEventId ->
                                                        if (eventId == null) {
                                                            viewModel.selectEvent(newEventId)
                                                        }
                                                    }
                                                },
                                                onDeleteEvent = { eventId ->
                                                    viewModel.deleteEvent(activeGroup.id, eventId)
                                                },
                                                onAddParticipant = { eventId, name, contact, kind, familyMemberId, avatarColorHex ->
                                                    viewModel.addEventParticipant(
                                                        group = activeGroup,
                                                        eventId = eventId,
                                                        name = name,
                                                        contact = contact,
                                                        kind = kind,
                                                        familyMemberId = familyMemberId,
                                                        avatarColorHex = avatarColorHex,
                                                    )
                                                },
                                                onDeleteParticipant = { participantId ->
                                                    viewModel.deleteEventParticipant(activeGroup.id, participantId)
                                                },
                                                onSaveEventEntry = { eventId, entryId, entryType, amount, category, participant, splitMode, splitParticipantIds, paymentMode, dateMillis, notes ->
                                                    viewModel.saveEventEntry(
                                                        group = activeGroup,
                                                        eventId = eventId,
                                                        entryId = entryId,
                                                        entryType = entryType,
                                                        amount = amount,
                                                        category = category,
                                                        participant = participant,
                                                        splitMode = splitMode,
                                                        splitParticipantIds = splitParticipantIds,
                                                        paymentMode = paymentMode,
                                                        dateMillis = dateMillis,
                                                        notes = notes,
                                                    )
                                                },
                                                onDeleteEventEntry = { entryId ->
                                                    viewModel.deleteEventEntry(activeGroup.id, entryId)
                                                },
                                                onNotify = { viewModel.notifyMessage(it) },
                                            )
                                        }
                                        KhataTab.CATEGORIES -> {
                                            CategoriesScreen(
                                                data = data,
                                                strings = strings,
                                                onSaveCategory = { categoryId, name, nameBn, scope, type, iconKey, colorHex ->
                                                    viewModel.saveCategory(
                                                        group = activeGroup,
                                                        categoryId = categoryId,
                                                        name = name,
                                                        nameBn = nameBn,
                                                        scope = scope,
                                                        type = type,
                                                        iconKey = iconKey,
                                                        colorHex = colorHex,
                                                    )
                                                },
                                                onDeleteCategory = { catId ->
                                                    viewModel.deleteCategory(activeGroup.id, catId)
                                                },
                                            )
                                        }
                                        KhataTab.REPORTS -> {
                                            ReportsAndSettingsScreen(
                                                data = data,
                                                profile = profile,
                                                period = selectedPeriod,
                                                selectedYear = selectedYear.year,
                                                customDateRange = customDateRange,
                                                appPrefs = appPrefs,
                                                currentUserId = user.uid,
                                                userEmail = user.email.orEmpty().ifBlank { user.displayName.orEmpty() },
                                                strings = strings,
                                                onSetThemeMode = onSetThemeMode,
                                                onSavePin = onSavePin,
                                                onToggleAppLock = onToggleAppLock,
                                                onToggleBiometric = onToggleBiometric,
                                                onSetAutoLockTimeout = onSetAutoLockTimeout,
                                                onClearPin = onClearPin,
                                                onSwitchGroup = { viewModel.switchActiveGroup(it) },
                                                onCreateGroup = { name, currency, cycleDay, phone ->
                                                    viewModel.createFamilyGroup(name, currency, cycleDay, phone)
                                                },
                                                onUpdateGroupSettings = { groupId, name, currency, cycleDay ->
                                                    viewModel.updateGroupSettings(groupId, name, currency, cycleDay)
                                                },
                                                onInviteMember = { name, email, phone, role, colorHex ->
                                                    viewModel.inviteMember(activeGroup, name, email, phone, role, colorHex)
                                                },
                                                onToggleMemberRole = { member ->
                                                    viewModel.toggleMemberRole(activeGroup, member)
                                                },
                                                onRemoveMember = { member ->
                                                    viewModel.removeMember(activeGroup, member)
                                                },
                                                onToggleLanguage = { viewModel.toggleLanguage(isBengali) },
                                                onBuildBackupJson = { viewModel.buildBackupJson(data) },
                                                onBackupSaved = { viewModel.markBackupCompleted() },
                                                onRestoreBackupJson = { json ->
                                                    viewModel.restoreFromJson(activeGroup, json)
                                                },
                                                onNotify = { viewModel.notifyMessage(it) },
                                                onSignOutClick = onSignOut,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun tabLabel(tab: KhataTab, strings: AppStrings): String = when (tab) {
    KhataTab.KHATA -> strings.navKhata
    KhataTab.EVENTS -> strings.navEvents
    KhataTab.CATEGORIES -> strings.navCategories
    KhataTab.REPORTS -> strings.navReports
}
