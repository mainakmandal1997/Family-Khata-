package com.example.export

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.example.logic.CategoryBreakdownItem
import com.example.logic.EventSummary
import com.example.logic.MonthlySummary
import com.example.logic.formatCurrency
import com.example.logic.formatDateShort
import com.example.logic.formatDateTime
import com.example.model.EventEntry
import com.example.model.EventEntryType
import com.example.model.FamilyGroup
import com.example.model.MonthlyTransaction
import com.example.model.TransactionType
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale

object ReportGenerator {

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 36f
    private const val CONTENT_WIDTH = PAGE_WIDTH - (MARGIN * 2f)

    const val XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    fun generateMonthlyPdfToFile(
        context: Context,
        group: FamilyGroup,
        periodTitle: String,
        cycleRangeLabel: String,
        summary: MonthlySummary,
        transactions: List<MonthlyTransaction>,
    ): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val safeName = group.name.replace(Regex("[^a-zA-Z0-9_]"), "_").take(30)
        val outFile = File(dir, "Khata_${safeName}_${periodTitle.replace(Regex("[^a-zA-Z0-9_]"), "_")}.pdf")
        val doc = buildMonthlyPdfDocument(group, periodTitle, cycleRangeLabel, summary, transactions)
        FileOutputStream(outFile).use { fos -> doc.writeTo(fos) }
        doc.close()
        return outFile
    }

    fun generateMonthlyXlsxToFile(
        context: Context,
        group: FamilyGroup,
        periodTitle: String,
        cycleRangeLabel: String,
        summary: MonthlySummary,
        transactions: List<MonthlyTransaction>,
    ): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val safeName = group.name.replace(Regex("[^a-zA-Z0-9_]"), "_").take(30)
        val outFile = File(dir, "Khata_${safeName}_${periodTitle.replace(Regex("[^a-zA-Z0-9_]"), "_")}.xlsx")
        XlsxWorkbookWriter.writePeriodWorkbook(outFile, group, periodTitle, cycleRangeLabel, summary, transactions)
        return outFile
    }

    fun generateEventPdfToFile(
        context: Context,
        group: FamilyGroup,
        summary: EventSummary,
        entries: List<EventEntry>,
    ): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val safeTitle = summary.event.title.replace(Regex("[^a-zA-Z0-9_]"), "_").take(30)
        val outFile = File(dir, "Event_${safeTitle}.pdf")
        val doc = buildEventPdfDocument(group, summary, entries)
        FileOutputStream(outFile).use { fos -> doc.writeTo(fos) }
        doc.close()
        return outFile
    }

    fun generateEventXlsxToFile(
        context: Context,
        group: FamilyGroup,
        summary: EventSummary,
        entries: List<EventEntry>,
    ): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val safeTitle = summary.event.title.replace(Regex("[^a-zA-Z0-9_]"), "_").take(30)
        val outFile = File(dir, "Event_${safeTitle}.xlsx")
        XlsxWorkbookWriter.writeEventWorkbook(outFile, group, summary, entries)
        return outFile
    }

    fun writeMonthlyCsv(
        group: FamilyGroup,
        periodTitle: String,
        cycleRangeLabel: String,
        transactions: List<MonthlyTransaction>,
    ): String {
        val sb = StringBuilder()
        sb.append("\uFEFF") // UTF-8 BOM for Excel & Google Sheets Bengali support
        sb.appendLine("Family Khata Report,${csvCell(group.name)},Period,${csvCell("$periodTitle ($cycleRangeLabel)")}")
        sb.appendLine("Date,Type,Category,Paid/Received By,Split Mode,Payment Mode,Amount (${group.currencySymbol}),Notes")
        transactions.sortedBy { it.dateMillis }.forEach { tx ->
            sb.appendLine(
                listOf(
                    csvCell(formatDateShort(tx.dateMillis)),
                    csvCell(tx.type),
                    csvCell(tx.categoryName),
                    csvCell(tx.paidByName),
                    csvCell(tx.splitMode),
                    csvCell(tx.paymentMode),
                    String.format(Locale.US, "%.2f", tx.amount),
                    csvCell(tx.notes),
                ).joinToString(",")
            )
        }
        return sb.toString()
    }

    fun writeEventCsv(
        group: FamilyGroup,
        summary: EventSummary,
        entries: List<EventEntry>,
    ): String {
        val sb = StringBuilder()
        sb.append("\uFEFF")
        sb.appendLine("Family Event Report,${csvCell(summary.event.title)},Group,${csvCell(group.name)}")
        sb.appendLine("Date,Entry Type,Category,Participant,Split Mode,Payment Mode,Amount (${group.currencySymbol}),Notes")
        entries.sortedBy { it.dateMillis }.forEach { ee ->
            sb.appendLine(
                listOf(
                    csvCell(formatDateShort(ee.dateMillis)),
                    csvCell(ee.entryType),
                    csvCell(ee.categoryName),
                    csvCell(ee.participantName),
                    csvCell(ee.splitMode),
                    csvCell(ee.paymentMode),
                    String.format(Locale.US, "%.2f", ee.amount),
                    csvCell(ee.notes),
                ).joinToString(",")
            )
        }
        return sb.toString()
    }

    fun writeTempTextFile(context: Context, fileName: String, content: String): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, fileName)
        file.writeText(content, Charsets.UTF_8)
        return file
    }

    fun shareFile(context: Context, file: File, mimeType: String, chooserTitle: String) {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, chooserTitle))
    }

    fun printPdfFile(context: Context, file: File, jobName: String) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback,
                extras: Bundle?,
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder(file.name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback,
            ) {
                try {
                    FileInputStream(file).use { input ->
                        FileOutputStream(destination.fileDescriptor).use { output ->
                            input.copyTo(output)
                        }
                    }
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback.onWriteFailed(e.message)
                }
            }
        }
        printManager.print(jobName, adapter, PrintAttributes.Builder().build())
    }

    private fun csvCell(raw: String): String {
        val escaped = raw.replace("\"", "\"\"")
        return "\"$escaped\""
    }

    // --- PDF RENDERING ENGINE ---

    private class PdfCursor(private val pdf: PdfDocument) {
        var pageNumber = 1
        var page: PdfDocument.Page = pdf.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
        val canvas: Canvas get() = page.canvas
        var y: Float = MARGIN

        fun ensureSpace(neededHeight: Float, headerTitle: String) {
            if (y + neededHeight > PAGE_HEIGHT - MARGIN) {
                drawFooter()
                pdf.finishPage(page)
                pageNumber++
                page = pdf.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
                y = MARGIN
                drawContinuationHeader(headerTitle)
            }
        }

        private fun drawContinuationHeader(title: String) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#64748B")
                textSize = 9f
            }
            canvas.drawText("$title — Page $pageNumber", MARGIN, y + 10f, p)
            y += 22f
        }

        fun drawFooter() {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#94A3B8")
                textSize = 8.5f
            }
            canvas.drawText(
                "Generated by Family Khata • Page $pageNumber",
                MARGIN,
                PAGE_HEIGHT - 16f,
                p
            )
        }

        fun finish() {
            drawFooter()
            pdf.finishPage(page)
        }
    }

    private fun buildMonthlyPdfDocument(
        group: FamilyGroup,
        periodTitle: String,
        cycleRangeLabel: String,
        summary: MonthlySummary,
        transactions: List<MonthlyTransaction>,
    ): PdfDocument {
        val pdf = PdfDocument()
        val cursor = PdfCursor(pdf)
        val currency = group.currencySymbol

        drawHeaderBanner(
            cursor = cursor,
            title = group.name,
            subtitle = "Monthly Khata Report • $periodTitle ($cycleRangeLabel)",
            generatedText = "Generated: ${formatDateTime(System.currentTimeMillis())}",
        )

        drawThreeSummaryBoxes(
            cursor = cursor,
            label1 = "Total Income / Pool",
            value1 = formatCurrency(summary.totalIncome, currency),
            color1 = "#15803D",
            label2 = "Total Expenditure",
            value2 = formatCurrency(summary.totalExpense, currency),
            color2 = "#DC2626",
            label3 = "Net Remaining",
            value3 = formatCurrency(summary.netBalance, currency),
            color3 = if (summary.netBalance >= 0) "#0F766E" else "#DC2626",
        )

        drawCategoryBreakdownSection(
            cursor = cursor,
            title = "Category-Wise Expense Breakdown",
            items = summary.expenseCategories,
            currency = currency,
            headerTitle = "${group.name} ($periodTitle)",
        )

        // Member-Wise Summary
        if (summary.memberBreakdowns.isNotEmpty()) {
            cursor.ensureSpace(70f, "${group.name} ($periodTitle)")
            drawSectionTitle(cursor, "Member-Wise Summary")
            drawTableHeader(cursor, listOf("Member", "Income Added", "Paid Out", "Fair Share", "Net Balance"), listOf(0.30f, 0.175f, 0.175f, 0.175f, 0.175f))
            summary.memberBreakdowns.forEachIndexed { idx, m ->
                cursor.ensureSpace(22f, "${group.name} ($periodTitle)")
                drawTableRow(
                    cursor = cursor,
                    striped = idx % 2 == 1,
                    cells = listOf(
                        m.memberName.take(22),
                        formatCurrency(m.incomeContributed, currency),
                        formatCurrency(m.expensePaid, currency),
                        formatCurrency(m.fairShare, currency),
                        formatCurrency(m.netSettlement, currency),
                    ),
                    weights = listOf(0.30f, 0.175f, 0.175f, 0.175f, 0.175f),
                )
            }
            cursor.y += 14f
        }

        // Chronological Transaction Ledger
        cursor.ensureSpace(70f, "${group.name} ($periodTitle)")
        drawSectionTitle(cursor, "Chronological Transaction Ledger (${transactions.size})")
        drawTableHeader(cursor, listOf("Date", "Category & Notes", "Member", "Mode", "Amount"), listOf(0.16f, 0.34f, 0.20f, 0.12f, 0.18f))
        transactions.sortedBy { it.dateMillis }.forEachIndexed { idx, tx ->
            cursor.ensureSpace(22f, "${group.name} ($periodTitle)")
            val prefix = if (tx.parsedType() == TransactionType.INCOME) "+" else "-"
            val desc = if (tx.notes.isNotBlank()) "${tx.categoryName} (${tx.notes})" else tx.categoryName
            drawTableRow(
                cursor = cursor,
                striped = idx % 2 == 1,
                cells = listOf(
                    formatDateShort(tx.dateMillis),
                    desc.take(30),
                    tx.paidByName.take(16),
                    tx.paymentMode,
                    "$prefix${formatCurrency(tx.amount, currency)}",
                ),
                weights = listOf(0.16f, 0.34f, 0.20f, 0.12f, 0.18f),
                lastColColor = if (tx.parsedType() == TransactionType.INCOME) "#15803D" else "#DC2626"
            )
        }

        cursor.finish()
        return pdf
    }

    private fun buildEventPdfDocument(
        group: FamilyGroup,
        summary: EventSummary,
        entries: List<EventEntry>,
    ): PdfDocument {
        val pdf = PdfDocument()
        val cursor = PdfCursor(pdf)
        val currency = group.currencySymbol
        val ev = summary.event

        drawHeaderBanner(
            cursor = cursor,
            title = ev.title,
            subtitle = "${group.name} • Event Report (${ev.eventType.replace("_", " ")}) • ${formatDateShort(ev.startDateMillis)}",
            generatedText = "Generated: ${formatDateTime(System.currentTimeMillis())}",
        )

        drawThreeSummaryBoxes(
            cursor = cursor,
            label1 = "Budget / Gifts Pool",
            value1 = "${formatCurrency(ev.budget, currency)} / ${formatCurrency(summary.totalContributions, currency)}",
            color1 = "#0F766E",
            label2 = "Total Event Spent",
            value2 = formatCurrency(summary.totalExpenses, currency),
            color2 = "#DC2626",
            label3 = "Pool Balance",
            value3 = formatCurrency(summary.netEventPoolBalance, currency),
            color3 = if (summary.netEventPoolBalance >= 0) "#15803D" else "#DC2626",
        )

        drawCategoryBreakdownSection(
            cursor = cursor,
            title = "Event Category Breakdown",
            items = summary.expenseCategories,
            currency = currency,
            headerTitle = ev.title,
        )

        if (summary.participantSettlements.isNotEmpty()) {
            cursor.ensureSpace(70f, ev.title)
            drawSectionTitle(cursor, "Participant & Guest Settlement Summary")
            drawTableHeader(cursor, listOf("Participant", "Gifts/Pool", "Paid", "Fair Share", "Net Settlement"), listOf(0.30f, 0.175f, 0.175f, 0.175f, 0.175f))
            summary.participantSettlements.forEachIndexed { idx, p ->
                cursor.ensureSpace(22f, ev.title)
                val tag = if (p.isGuest) "${p.name} (Guest)" else p.name
                drawTableRow(
                    cursor = cursor,
                    striped = idx % 2 == 1,
                    cells = listOf(
                        tag.take(22),
                        formatCurrency(p.contributedGifts, currency),
                        formatCurrency(p.expensePaid, currency),
                        formatCurrency(p.fairShare, currency),
                        formatCurrency(p.netSettlement, currency),
                    ),
                    weights = listOf(0.30f, 0.175f, 0.175f, 0.175f, 0.175f),
                )
            }
            cursor.y += 14f
        }

        cursor.ensureSpace(70f, ev.title)
        drawSectionTitle(cursor, "Event Chronological Ledger (${entries.size})")
        drawTableHeader(cursor, listOf("Date", "Category & Notes", "Participant", "Mode", "Amount"), listOf(0.16f, 0.34f, 0.20f, 0.12f, 0.18f))
        entries.sortedBy { it.dateMillis }.forEachIndexed { idx, ee ->
            cursor.ensureSpace(22f, ev.title)
            val isGift = ee.parsedEntryType() == EventEntryType.CONTRIBUTION_GIFT
            val prefix = if (isGift) "+" else "-"
            val desc = if (ee.notes.isNotBlank()) "${ee.categoryName} (${ee.notes})" else ee.categoryName
            drawTableRow(
                cursor = cursor,
                striped = idx % 2 == 1,
                cells = listOf(
                    formatDateShort(ee.dateMillis),
                    desc.take(30),
                    ee.participantName.take(16),
                    ee.paymentMode,
                    "$prefix${formatCurrency(ee.amount, currency)}",
                ),
                weights = listOf(0.16f, 0.34f, 0.20f, 0.12f, 0.18f),
                lastColColor = if (isGift) "#15803D" else "#DC2626"
            )
        }

        cursor.finish()
        return pdf
    }

    private fun drawHeaderBanner(
        cursor: PdfCursor,
        title: String,
        subtitle: String,
        generatedText: String,
    ) {
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0F766E") }
        val rect = RectF(MARGIN, cursor.y, PAGE_WIDTH - MARGIN, cursor.y + 68f)
        cursor.canvas.drawRoundRect(rect, 10f, 10f, bgPaint)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D9F3EE")
            textSize = 10.5f
        }
        val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#A7F3D0")
            textSize = 9f
        }

        cursor.canvas.drawText(title, MARGIN + 14f, cursor.y + 25f, titlePaint)
        cursor.canvas.drawText(subtitle, MARGIN + 14f, cursor.y + 42f, subPaint)
        cursor.canvas.drawText(generatedText, MARGIN + 14f, cursor.y + 57f, datePaint)
        cursor.y += 82f
    }

    private fun drawThreeSummaryBoxes(
        cursor: PdfCursor,
        label1: String, value1: String, color1: String,
        label2: String, value2: String, color2: String,
        label3: String, value3: String, color3: String,
    ) {
        val gap = 10f
        val boxW = (CONTENT_WIDTH - gap * 2f) / 3f
        val boxH = 52f
        val entries = listOf(
            Triple(label1, value1, color1),
            Triple(label2, value2, color2),
            Triple(label3, value3, color3),
        )
        entries.forEachIndexed { idx, (label, value, hex) ->
            val left = MARGIN + idx * (boxW + gap)
            val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F8FAFC") }
            val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#E2E8F0")
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            val rect = RectF(left, cursor.y, left + boxW, cursor.y + boxH)
            cursor.canvas.drawRoundRect(rect, 8f, 8f, bg)
            cursor.canvas.drawRoundRect(rect, 8f, 8f, border)

            val lblPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#64748B")
                textSize = 9f
            }
            val valPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor(hex)
                textSize = 12.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            cursor.canvas.drawText(label, left + 10f, cursor.y + 18f, lblPaint)
            cursor.canvas.drawText(value, left + 10f, cursor.y + 38f, valPaint)
        }
        cursor.y += boxH + 16f
    }

    private fun drawSectionTitle(cursor: PdfCursor, title: String) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 12.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        cursor.canvas.drawText(title, MARGIN, cursor.y + 12f, p)
        cursor.y += 20f
    }

    private fun drawCategoryBreakdownSection(
        cursor: PdfCursor,
        title: String,
        items: List<CategoryBreakdownItem>,
        currency: String,
        headerTitle: String,
    ) {
        if (items.isEmpty()) return
        cursor.ensureSpace(64f, headerTitle)
        drawSectionTitle(cursor, title)
        drawTableHeader(cursor, listOf("Category", "Visual Share", "Txns", "Amount", "% Share"), listOf(0.28f, 0.30f, 0.10f, 0.18f, 0.14f))

        items.forEachIndexed { idx, cat ->
            cursor.ensureSpace(22f, headerTitle)
            val rowTop = cursor.y
            if (idx % 2 == 1) {
                val stripe = Paint().apply { color = Color.parseColor("#F8FAFC") }
                cursor.canvas.drawRect(MARGIN, rowTop, PAGE_WIDTH - MARGIN, rowTop + 20f, stripe)
            }

            // Color indicator dot
            val dotColor = try { Color.parseColor(cat.colorHex) } catch (_: Exception) { Color.parseColor("#0F766E") }
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = dotColor }
            cursor.canvas.drawCircle(MARGIN + 8f, rowTop + 10f, 4f, dotPaint)

            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#1E293B")
                textSize = 9.5f
            }
            cursor.canvas.drawText(cat.categoryName.take(20), MARGIN + 18f, rowTop + 13.5f, textPaint)

            // Progress bar inside visual share column
            val barLeft = MARGIN + CONTENT_WIDTH * 0.28f + 4f
            val barMaxW = CONTENT_WIDTH * 0.30f - 14f
            val barBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E2E8F0") }
            cursor.canvas.drawRoundRect(RectF(barLeft, rowTop + 6f, barLeft + barMaxW, rowTop + 14f), 3f, 3f, barBg)
            val fillW = (barMaxW * (cat.percentage / 100.0).toFloat()).coerceIn(3f, barMaxW)
            cursor.canvas.drawRoundRect(RectF(barLeft, rowTop + 6f, barLeft + fillW, rowTop + 14f), 3f, 3f, dotPaint)

            val xTx = MARGIN + CONTENT_WIDTH * 0.58f + 4f
            val xAmt = MARGIN + CONTENT_WIDTH * 0.68f + 4f
            val xPct = MARGIN + CONTENT_WIDTH * 0.86f + 4f
            cursor.canvas.drawText(cat.transactionCount.toString(), xTx, rowTop + 13.5f, textPaint)
            cursor.canvas.drawText(formatCurrency(cat.totalAmount, currency), xAmt, rowTop + 13.5f, textPaint)
            cursor.canvas.drawText(String.format(Locale.US, "%.1f%%", cat.percentage), xPct, rowTop + 13.5f, textPaint)
            cursor.y += 20f
        }
        cursor.y += 14f
    }

    private fun drawTableHeader(
        cursor: PdfCursor,
        headers: List<String>,
        weights: List<Float>,
    ) {
        val bg = Paint().apply { color = Color.parseColor("#E2E8F0") }
        cursor.canvas.drawRect(MARGIN, cursor.y, PAGE_WIDTH - MARGIN, cursor.y + 20f, bg)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#334155")
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        var x = MARGIN + 6f
        headers.forEachIndexed { idx, h ->
            cursor.canvas.drawText(h, x, cursor.y + 13.5f, p)
            x += CONTENT_WIDTH * weights[idx]
        }
        cursor.y += 20f
    }

    private fun drawTableRow(
        cursor: PdfCursor,
        striped: Boolean,
        cells: List<String>,
        weights: List<Float>,
        lastColColor: String? = null,
    ) {
        if (striped) {
            val bg = Paint().apply { color = Color.parseColor("#F8FAFC") }
            cursor.canvas.drawRect(MARGIN, cursor.y, PAGE_WIDTH - MARGIN, cursor.y + 19f, bg)
        }
        var x = MARGIN + 6f
        cells.forEachIndexed { idx, value ->
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (idx == cells.lastIndex && lastColColor != null) {
                    Color.parseColor(lastColColor)
                } else {
                    Color.parseColor("#1E293B")
                }
                textSize = 9f
                if (idx == cells.lastIndex && lastColColor != null) {
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                }
            }
            cursor.canvas.drawText(value, x, cursor.y + 13f, p)
            x += CONTENT_WIDTH * weights[idx]
        }
        cursor.y += 19f
    }
}
