package com.example.export

import com.example.logic.EventSummary
import com.example.logic.MonthlySummary
import com.example.logic.formatDateShort
import com.example.logic.formatDateTime
import com.example.model.EventEntry
import com.example.model.EventEntryType
import com.example.model.FamilyGroup
import com.example.model.MonthlyTransaction
import com.example.model.TransactionType
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object XlsxWorkbookWriter {

    private sealed interface CellValue {
        data class Text(val value: String, val style: Int = 0) : CellValue
        data class Number(val value: Double, val style: Int = 4) : CellValue
        data class Formula(val expr: String, val cachedValue: Double, val style: Int = 4) : CellValue
    }

    private data class SheetSpec(
        val name: String,
        val colWidths: List<Double>,
        val rows: List<List<CellValue>>,
    )

    fun writePeriodWorkbook(
        outFile: File,
        group: FamilyGroup,
        periodTitle: String,
        rangeLabel: String,
        summary: MonthlySummary,
        transactions: List<MonthlyTransaction>,
    ) {
        val currencyLabel = group.currencySymbol
        val generated = formatDateTime(System.currentTimeMillis())

        // Sheet 1: Summary & Category Breakdown
        val s1Rows = mutableListOf<List<CellValue>>()
        s1Rows.add(listOf(CellValue.Text("${group.name} — Khata Summary", style = 1), CellValue.Text("", style = 1), CellValue.Text("", style = 1), CellValue.Text("", style = 1)))
        s1Rows.add(listOf(CellValue.Text("Period: $periodTitle ($rangeLabel)", style = 3), CellValue.Text("Currency: $currencyLabel"), CellValue.Text("Generated: $generated")))
        s1Rows.add(emptyList())
        s1Rows.add(listOf(CellValue.Text("Executive Summary", style = 2), CellValue.Text("Amount ($currencyLabel)", style = 2)))
        s1Rows.add(listOf(CellValue.Text("Total Income / Pool", style = 3), CellValue.Number(summary.totalIncome, style = 4))) // Row 5
        s1Rows.add(listOf(CellValue.Text("Total Expenditure", style = 3), CellValue.Number(summary.totalExpense, style = 4))) // Row 6
        s1Rows.add(listOf(CellValue.Text("Net Remaining Balance", style = 3), CellValue.Formula("B5-B6", summary.netBalance, style = 5))) // Row 7
        s1Rows.add(emptyList())
        s1Rows.add(listOf(CellValue.Text("Category-Wise Expense Breakdown", style = 3)))
        s1Rows.add(
            listOf(
                CellValue.Text("Category", style = 2),
                CellValue.Text("Transactions", style = 2),
                CellValue.Text("Amount ($currencyLabel)", style = 2),
                CellValue.Text("% Share", style = 2),
            )
        ) // Row 10

        val catStartRow = 11
        val catCount = summary.expenseCategories.size
        val catTotalRow = catStartRow + catCount
        if (catCount == 0) {
            s1Rows.add(listOf(CellValue.Text("No expense entries in this period"), CellValue.Number(0.0, style = 0), CellValue.Number(0.0, style = 4), CellValue.Number(0.0, style = 6)))
        } else {
            summary.expenseCategories.forEachIndexed { idx, cat ->
                val r = catStartRow + idx
                val pctFraction = if (summary.totalExpense > 0.0) cat.totalAmount / summary.totalExpense else 0.0
                s1Rows.add(
                    listOf(
                        CellValue.Text(cat.categoryName),
                        CellValue.Number(cat.transactionCount.toDouble(), style = 0),
                        CellValue.Number(cat.totalAmount, style = 4),
                        CellValue.Formula("IF(\$C\$$catTotalRow>0,C$r/\$C\$$catTotalRow,0)", pctFraction, style = 6),
                    )
                )
            }
            s1Rows.add(
                listOf(
                    CellValue.Text("Total Expenditure", style = 3),
                    CellValue.Formula("SUM(B$catStartRow:B${catTotalRow - 1})", transactions.count { it.parsedType() == TransactionType.EXPENSE }.toDouble(), style = 3),
                    CellValue.Formula("SUM(C$catStartRow:C${catTotalRow - 1})", summary.totalExpense, style = 5),
                    CellValue.Formula("SUM(D$catStartRow:D${catTotalRow - 1})", if (summary.totalExpense > 0) 1.0 else 0.0, style = 6),
                )
            )
        }

        // Sheet 2: Member Summary
        val s2Rows = mutableListOf<List<CellValue>>()
        s2Rows.add(listOf(CellValue.Text("${group.name} — Member Summary ($periodTitle)", style = 1)))
        s2Rows.add(emptyList())
        s2Rows.add(
            listOf(
                CellValue.Text("Member Name", style = 2),
                CellValue.Text("Income Contributed", style = 2),
                CellValue.Text("Expense Paid", style = 2),
                CellValue.Text("Fair Share", style = 2),
                CellValue.Text("Net Settlement", style = 2),
            )
        )
        val memStartRow = 4
        summary.memberBreakdowns.forEachIndexed { idx, m ->
            val r = memStartRow + idx
            s2Rows.add(
                listOf(
                    CellValue.Text(m.memberName, style = 3),
                    CellValue.Number(m.incomeContributed, style = 4),
                    CellValue.Number(m.expensePaid, style = 4),
                    CellValue.Number(m.fairShare, style = 4),
                    CellValue.Formula("C$r-D$r", m.netSettlement, style = 5),
                )
            )
        }
        if (summary.memberBreakdowns.isNotEmpty()) {
            val endRow = memStartRow + summary.memberBreakdowns.size - 1
            s2Rows.add(
                listOf(
                    CellValue.Text("Total", style = 3),
                    CellValue.Formula("SUM(B$memStartRow:B$endRow)", summary.memberBreakdowns.sumOf { it.incomeContributed }, style = 5),
                    CellValue.Formula("SUM(C$memStartRow:C$endRow)", summary.memberBreakdowns.sumOf { it.expensePaid }, style = 5),
                    CellValue.Formula("SUM(D$memStartRow:D$endRow)", summary.memberBreakdowns.sumOf { it.fairShare }, style = 5),
                    CellValue.Formula("SUM(E$memStartRow:E$endRow)", summary.memberBreakdowns.sumOf { it.netSettlement }, style = 5),
                )
            )
        }

        // Sheet 3: Itemized Transactions
        val s3Rows = mutableListOf<List<CellValue>>()
        s3Rows.add(listOf(CellValue.Text("${group.name} — Itemized Ledger ($periodTitle)", style = 1)))
        s3Rows.add(emptyList())
        s3Rows.add(
            listOf(
                CellValue.Text("Date", style = 2),
                CellValue.Text("Type", style = 2),
                CellValue.Text("Category", style = 2),
                CellValue.Text("Paid / Received By", style = 2),
                CellValue.Text("Split Mode", style = 2),
                CellValue.Text("Payment Mode", style = 2),
                CellValue.Text("Income ($currencyLabel)", style = 2),
                CellValue.Text("Expense ($currencyLabel)", style = 2),
                CellValue.Text("Notes", style = 2),
            )
        )
        val sortedTxs = transactions.sortedBy { it.dateMillis }
        sortedTxs.forEach { tx ->
            val isInc = tx.parsedType() == TransactionType.INCOME
            s3Rows.add(
                listOf(
                    CellValue.Text(formatDateShort(tx.dateMillis)),
                    CellValue.Text(tx.type),
                    CellValue.Text(tx.categoryName),
                    CellValue.Text(tx.paidByName),
                    CellValue.Text(tx.splitMode),
                    CellValue.Text(tx.paymentMode),
                    CellValue.Number(if (isInc) tx.amount else 0.0, style = 4),
                    CellValue.Number(if (!isInc) tx.amount else 0.0, style = 4),
                    CellValue.Text(tx.notes),
                )
            )
        }
        if (sortedTxs.isNotEmpty()) {
            val startR = 4
            val endR = startR + sortedTxs.size - 1
            s3Rows.add(
                listOf(
                    CellValue.Text("Totals", style = 3),
                    CellValue.Text(""),
                    CellValue.Text(""),
                    CellValue.Text(""),
                    CellValue.Text(""),
                    CellValue.Text(""),
                    CellValue.Formula("SUM(G$startR:G$endR)", summary.totalIncome, style = 5),
                    CellValue.Formula("SUM(H$startR:H$endR)", summary.totalExpense, style = 5),
                    CellValue.Text(""),
                )
            )
        }

        writeWorkbookZip(
            outFile = outFile,
            sheets = listOf(
                SheetSpec("Summary & Categories", listOf(30.0, 16.0, 20.0, 14.0), s1Rows),
                SheetSpec("Member Summary", listOf(26.0, 20.0, 18.0, 18.0, 18.0), s2Rows),
                SheetSpec("Transactions", listOf(15.0, 12.0, 22.0, 20.0, 18.0, 14.0, 16.0, 16.0, 32.0), s3Rows),
            ),
        )
    }

    fun writeEventWorkbook(
        outFile: File,
        group: FamilyGroup,
        summary: EventSummary,
        entries: List<EventEntry>,
    ) {
        val ev = summary.event
        val currencyLabel = group.currencySymbol
        val generated = formatDateTime(System.currentTimeMillis())

        // Sheet 1: Event Summary & Categories
        val s1Rows = mutableListOf<List<CellValue>>()
        s1Rows.add(listOf(CellValue.Text("${ev.title} — Event Report", style = 1), CellValue.Text("", style = 1), CellValue.Text("", style = 1), CellValue.Text("", style = 1)))
        s1Rows.add(listOf(CellValue.Text("Group: ${group.name}", style = 3), CellValue.Text("Event Type: ${ev.eventType}"), CellValue.Text("Generated: $generated")))
        s1Rows.add(emptyList())
        s1Rows.add(listOf(CellValue.Text("Event Financial Overview", style = 2), CellValue.Text("Amount ($currencyLabel)", style = 2)))
        s1Rows.add(listOf(CellValue.Text("Event Budget", style = 3), CellValue.Number(ev.budget, style = 4))) // Row 5
        s1Rows.add(listOf(CellValue.Text("Contributions / Gifts Pool", style = 3), CellValue.Number(summary.totalContributions, style = 4))) // Row 6
        s1Rows.add(listOf(CellValue.Text("Total Event Expenditure", style = 3), CellValue.Number(summary.totalExpenses, style = 4))) // Row 7
        s1Rows.add(listOf(CellValue.Text("Remaining Budget", style = 3), CellValue.Formula("B5-B7", summary.remainingBudget, style = 5))) // Row 8
        s1Rows.add(listOf(CellValue.Text("Net Pool Balance", style = 3), CellValue.Formula("B6-B7", summary.netEventPoolBalance, style = 5))) // Row 9
        s1Rows.add(emptyList())
        s1Rows.add(listOf(CellValue.Text("Event Category-Wise Breakdown", style = 3)))
        s1Rows.add(
            listOf(
                CellValue.Text("Category", style = 2),
                CellValue.Text("Entries", style = 2),
                CellValue.Text("Amount ($currencyLabel)", style = 2),
                CellValue.Text("% Share", style = 2),
            )
        ) // Row 12

        val catStart = 13
        val catCount = summary.expenseCategories.size
        val catTotal = catStart + catCount
        if (catCount == 0) {
            s1Rows.add(listOf(CellValue.Text("No event expenses yet"), CellValue.Number(0.0, style = 0), CellValue.Number(0.0, style = 4), CellValue.Number(0.0, style = 6)))
        } else {
            summary.expenseCategories.forEachIndexed { idx, cat ->
                val r = catStart + idx
                val pct = if (summary.totalExpenses > 0.0) cat.totalAmount / summary.totalExpenses else 0.0
                s1Rows.add(
                    listOf(
                        CellValue.Text(cat.categoryName),
                        CellValue.Number(cat.transactionCount.toDouble(), style = 0),
                        CellValue.Number(cat.totalAmount, style = 4),
                        CellValue.Formula("IF(\$C\$$catTotal>0,C$r/\$C\$$catTotal,0)", pct, style = 6),
                    )
                )
            }
            s1Rows.add(
                listOf(
                    CellValue.Text("Total Event Expense", style = 3),
                    CellValue.Formula("SUM(B$catStart:B${catTotal - 1})", entries.count { it.parsedEntryType() == EventEntryType.EXPENSE }.toDouble(), style = 3),
                    CellValue.Formula("SUM(C$catStart:C${catTotal - 1})", summary.totalExpenses, style = 5),
                    CellValue.Formula("SUM(D$catStart:D${catTotal - 1})", if (summary.totalExpenses > 0) 1.0 else 0.0, style = 6),
                )
            )
        }

        // Sheet 2: Participant Settlements
        val s2Rows = mutableListOf<List<CellValue>>()
        s2Rows.add(listOf(CellValue.Text("${ev.title} — Participant & Guest Settlement", style = 1)))
        s2Rows.add(emptyList())
        s2Rows.add(
            listOf(
                CellValue.Text("Participant", style = 2),
                CellValue.Text("Type", style = 2),
                CellValue.Text("Gifts / Pool", style = 2),
                CellValue.Text("Expense Paid", style = 2),
                CellValue.Text("Fair Share", style = 2),
                CellValue.Text("Net Settlement", style = 2),
            )
        )
        val pStart = 4
        summary.participantSettlements.forEachIndexed { idx, p ->
            val r = pStart + idx
            s2Rows.add(
                listOf(
                    CellValue.Text(p.name, style = 3),
                    CellValue.Text(if (p.isGuest) "Guest/Friend" else "Family Member"),
                    CellValue.Number(p.contributedGifts, style = 4),
                    CellValue.Number(p.expensePaid, style = 4),
                    CellValue.Number(p.fairShare, style = 4),
                    CellValue.Formula("C$r+D$r-E$r", p.netSettlement, style = 5),
                )
            )
        }
        if (summary.participantSettlements.isNotEmpty()) {
            val endR = pStart + summary.participantSettlements.size - 1
            s2Rows.add(
                listOf(
                    CellValue.Text("Totals", style = 3),
                    CellValue.Text(""),
                    CellValue.Formula("SUM(C$pStart:C$endR)", summary.participantSettlements.sumOf { it.contributedGifts }, style = 5),
                    CellValue.Formula("SUM(D$pStart:D$endR)", summary.participantSettlements.sumOf { it.expensePaid }, style = 5),
                    CellValue.Formula("SUM(E$pStart:E$endR)", summary.participantSettlements.sumOf { it.fairShare }, style = 5),
                    CellValue.Formula("SUM(F$pStart:F$endR)", summary.participantSettlements.sumOf { it.netSettlement }, style = 5),
                )
            )
        }

        // Sheet 3: Event Entries
        val s3Rows = mutableListOf<List<CellValue>>()
        s3Rows.add(listOf(CellValue.Text("${ev.title} — Event Ledger", style = 1)))
        s3Rows.add(emptyList())
        s3Rows.add(
            listOf(
                CellValue.Text("Date", style = 2),
                CellValue.Text("Entry Type", style = 2),
                CellValue.Text("Category", style = 2),
                CellValue.Text("Participant", style = 2),
                CellValue.Text("Split Mode", style = 2),
                CellValue.Text("Payment Mode", style = 2),
                CellValue.Text("Gift / Pool ($currencyLabel)", style = 2),
                CellValue.Text("Expense ($currencyLabel)", style = 2),
                CellValue.Text("Notes", style = 2),
            )
        )
        val sortedEntries = entries.sortedBy { it.dateMillis }
        sortedEntries.forEach { ee ->
            val isGift = ee.parsedEntryType() == EventEntryType.CONTRIBUTION_GIFT
            s3Rows.add(
                listOf(
                    CellValue.Text(formatDateShort(ee.dateMillis)),
                    CellValue.Text(ee.entryType),
                    CellValue.Text(ee.categoryName),
                    CellValue.Text(ee.participantName),
                    CellValue.Text(ee.splitMode),
                    CellValue.Text(ee.paymentMode),
                    CellValue.Number(if (isGift) ee.amount else 0.0, style = 4),
                    CellValue.Number(if (!isGift) ee.amount else 0.0, style = 4),
                    CellValue.Text(ee.notes),
                )
            )
        }
        if (sortedEntries.isNotEmpty()) {
            val startR = 4
            val endR = startR + sortedEntries.size - 1
            s3Rows.add(
                listOf(
                    CellValue.Text("Totals", style = 3),
                    CellValue.Text(""),
                    CellValue.Text(""),
                    CellValue.Text(""),
                    CellValue.Text(""),
                    CellValue.Text(""),
                    CellValue.Formula("SUM(G$startR:G$endR)", summary.totalContributions, style = 5),
                    CellValue.Formula("SUM(H$startR:H$endR)", summary.totalExpenses, style = 5),
                    CellValue.Text(""),
                )
            )
        }

        writeWorkbookZip(
            outFile = outFile,
            sheets = listOf(
                SheetSpec("Event Summary", listOf(30.0, 16.0, 20.0, 14.0), s1Rows),
                SheetSpec("Participants", listOf(24.0, 16.0, 16.0, 16.0, 16.0, 18.0), s2Rows),
                SheetSpec("Event Ledger", listOf(15.0, 18.0, 22.0, 20.0, 18.0, 14.0, 16.0, 16.0, 32.0), s3Rows),
            ),
        )
    }

    private fun writeWorkbookZip(outFile: File, sheets: List<SheetSpec>) {
        outFile.parentFile?.mkdirs()
        ZipOutputStream(FileOutputStream(outFile)).use { zos ->
            writeZipEntry(zos, "[Content_Types].xml", buildContentTypesXml(sheets.size))
            writeZipEntry(zos, "_rels/.rels", ROOT_RELS_XML)
            writeZipEntry(zos, "xl/workbook.xml", buildWorkbookXml(sheets))
            writeZipEntry(zos, "xl/_rels/workbook.xml.rels", buildWorkbookRelsXml(sheets.size))
            writeZipEntry(zos, "xl/styles.xml", STYLES_XML)
            sheets.forEachIndexed { idx, spec ->
                writeZipEntry(zos, "xl/worksheets/sheet${idx + 1}.xml", buildSheetXml(spec))
            }
        }
    }

    private fun writeZipEntry(zos: ZipOutputStream, name: String, content: String) {
        zos.putNextEntry(ZipEntry(name))
        zos.write(content.toByteArray(Charsets.UTF_8))
        zos.closeEntry()
    }

    private fun buildContentTypesXml(sheetCount: Int): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
        sb.append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
        sb.append("""<Default Extension="xml" ContentType="application/xml"/>""")
        sb.append("""<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""")
        sb.append("""<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>""")
        for (i in 1..sheetCount) {
            sb.append("""<Override PartName="/xl/worksheets/sheet$i.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""")
        }
        sb.append("</Types>")
        return sb.toString()
    }

    private fun buildWorkbookXml(sheets: List<SheetSpec>): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">""")
        sb.append("<sheets>")
        sheets.forEachIndexed { idx, spec ->
            val safeName = escapeXml(spec.name.take(31))
            sb.append("""<sheet name="$safeName" sheetId="${idx + 1}" r:id="rId${idx + 1}"/>""")
        }
        sb.append("</sheets></workbook>")
        return sb.toString()
    }

    private fun buildWorkbookRelsXml(sheetCount: Int): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
        for (i in 1..sheetCount) {
            sb.append("""<Relationship Id="rId$i" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet$i.xml"/>""")
        }
        sb.append("""<Relationship Id="rId${sheetCount + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>""")
        sb.append("</Relationships>")
        return sb.toString()
    }

    private fun buildSheetXml(spec: SheetSpec): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")
        if (spec.colWidths.isNotEmpty()) {
            sb.append("<cols>")
            spec.colWidths.forEachIndexed { idx, w ->
                val c = idx + 1
                sb.append("""<col min="$c" max="$c" width="$w" customWidth="1"/>""")
            }
            sb.append("</cols>")
        }
        sb.append("<sheetData>")
        spec.rows.forEachIndexed { rowIdx, cells ->
            val rowNum = rowIdx + 1
            sb.append("""<row r="$rowNum">""")
            cells.forEachIndexed { colIdx, cell ->
                val ref = "${colLetter(colIdx + 1)}$rowNum"
                when (cell) {
                    is CellValue.Text -> {
                        val txt = escapeXml(cell.value)
                        sb.append("""<c r="$ref" s="${cell.style}" t="inlineStr"><is><t>$txt</t></is></c>""")
                    }
                    is CellValue.Number -> {
                        val numStr = String.format(Locale.US, "%.2f", cell.value)
                        sb.append("""<c r="$ref" s="${cell.style}" t="n"><v>$numStr</v></c>""")
                    }
                    is CellValue.Formula -> {
                        val expr = escapeXml(cell.expr)
                        val cachedStr = String.format(Locale.US, "%.4f", cell.cachedValue)
                        sb.append("""<c r="$ref" s="${cell.style}"><f>$expr</f><v>$cachedStr</v></c>""")
                    }
                }
            }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")
        return sb.toString()
    }

    private fun colLetter(index1Based: Int): String {
        var n = index1Based
        val sb = StringBuilder()
        while (n > 0) {
            val rem = (n - 1) % 26
            sb.append(('A'.code + rem).toChar())
            n = (n - 1) / 26
        }
        return sb.reverse().toString()
    }

    private fun escapeXml(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            val code = ch.code
            val validXmlChar = code == 0x9 || code == 0xA || code == 0xD || code >= 0x20
            if (!validXmlChar) continue
            when (ch) {
                '&' -> sb.append("&amp;")
                '<' -> sb.append("&lt;")
                '>' -> sb.append("&gt;")
                '"' -> sb.append("&quot;")
                '\'' -> sb.append("&apos;")
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private const val ROOT_RELS_XML =
        """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""

    private const val STYLES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <numFmts count="2">
    <numFmt numFmtId="164" formatCode="#,##0.00"/>
    <numFmt numFmtId="165" formatCode="0.0%"/>
  </numFmts>
  <fonts count="3">
    <font><sz val="11"/><name val="Calibri"/></font>
    <font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
    <font><b/><sz val="11"/><color rgb="FF0F172A"/><name val="Calibri"/></font>
  </fonts>
  <fills count="4">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF0F766E"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF115E59"/></patternFill></fill>
  </fills>
  <borders count="1">
    <border><left/><right/><top/><bottom/><diagonal/></border>
  </borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="7">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
    <xf numFmtId="0" fontId="1" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
    <xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>
    <xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
    <xf numFmtId="164" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyNumberFormat="1"/>
    <xf numFmtId="165" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyNumberFormat="1"/>
  </cellXfs>
</styleSheet>"""
}
