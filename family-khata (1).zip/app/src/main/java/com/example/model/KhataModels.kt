package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class MemberRole { ADMIN, MEMBER }
enum class CategoryScope { MONTHLY, EVENT, BOTH }
enum class CategoryType { INCOME, EXPENSE, BOTH }
enum class TransactionType { INCOME, EXPENSE }
enum class SplitMode { FULL_FAMILY, SELECTED_MEMBERS, INDIVIDUAL }
enum class PaymentMode { CASH, UPI, BANK, CARD }
enum class EventType { BIRTHDAY, WEDDING, ANNIVERSARY, PUJA_FESTIVAL, FAMILY_TRIP, PICNIC, HOUSEWARMING, OTHER }
enum class EventStatus { ACTIVE, SETTLED }
enum class ParticipantKind { FAMILY_MEMBER, GUEST_FRIEND }
enum class EventEntryType { CONTRIBUTION_GIFT, EXPENSE }
enum class EventSplitMode { ALL_PARTICIPANTS, SELECTED_PARTICIPANTS, INDIVIDUAL }

inline fun <reified T : Enum<T>> safeEnum(raw: String?, default: T): T {
    if (raw.isNullOrBlank()) return default
    return enumValues<T>().firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: default
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val preferredLanguage: String = "en",
    val activeGroupId: String = "",
    val lastBackupAtMillis: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class FamilyGroup(
    @DocumentId val id: String = "",
    val name: String = "",
    val currencySymbol: String = "₹",
    val cycleStartDay: Long = 1L,
    val ownerId: String = "",
    val memberUids: List<String> = emptyList(),
    val adminUids: List<String> = emptyList(),
    val invitedEmails: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class FamilyMember(
    @DocumentId val id: String = "",
    val groupId: String = "",
    val memberUids: List<String> = emptyList(),
    val invitedEmails: List<String> = emptyList(),
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val role: String = MemberRole.MEMBER.name,
    val linkedUid: String = "",
    val avatarColorHex: String = "#0F766E",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun parsedRole(): MemberRole = safeEnum(role, MemberRole.MEMBER)
}

@Keep
@IgnoreExtraProperties
data class KhataCategory(
    @DocumentId val id: String = "",
    val groupId: String = "",
    val memberUids: List<String> = emptyList(),
    val invitedEmails: List<String> = emptyList(),
    val name: String = "",
    val nameBn: String = "",
    val scope: String = CategoryScope.MONTHLY.name,
    val type: String = CategoryType.EXPENSE.name,
    val iconKey: String = "groceries",
    val colorHex: String = "#0F766E",
    val builtIn: Boolean = false,
    val createdBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun parsedScope(): CategoryScope = safeEnum(scope, CategoryScope.MONTHLY)
    fun parsedType(): CategoryType = safeEnum(type, CategoryType.EXPENSE)
    fun displayName(isBengali: Boolean): String = if (isBengali && nameBn.isNotBlank()) nameBn else name
}

@Keep
@IgnoreExtraProperties
data class MonthlyTransaction(
    @DocumentId val id: String = "",
    val groupId: String = "",
    val memberUids: List<String> = emptyList(),
    val invitedEmails: List<String> = emptyList(),
    val type: String = TransactionType.EXPENSE.name,
    val amount: Double = 0.0,
    val categoryId: String = "",
    val categoryName: String = "",
    val categoryColorHex: String = "#0F766E",
    val categoryIconKey: String = "groceries",
    val paidByMemberId: String = "",
    val paidByName: String = "",
    val splitMode: String = SplitMode.FULL_FAMILY.name,
    val splitMemberIds: List<String> = emptyList(),
    val paymentMode: String = PaymentMode.UPI.name,
    val dateMillis: Long = 0L,
    val notes: String = "",
    val createdBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun parsedType(): TransactionType = safeEnum(type, TransactionType.EXPENSE)
    fun parsedSplitMode(): SplitMode = safeEnum(splitMode, SplitMode.FULL_FAMILY)
    fun parsedPaymentMode(): PaymentMode = safeEnum(paymentMode, PaymentMode.UPI)
}

@Keep
@IgnoreExtraProperties
data class FamilyEvent(
    @DocumentId val id: String = "",
    val groupId: String = "",
    val memberUids: List<String> = emptyList(),
    val invitedEmails: List<String> = emptyList(),
    val title: String = "",
    val eventType: String = EventType.OTHER.name,
    val budget: Double = 0.0,
    val startDateMillis: Long = 0L,
    val endDateMillis: Long = 0L,
    val venue: String = "",
    val notes: String = "",
    val accentColorHex: String = "#D97706",
    val status: String = EventStatus.ACTIVE.name,
    val createdBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun parsedEventType(): EventType = safeEnum(eventType, EventType.OTHER)
    fun parsedStatus(): EventStatus = safeEnum(status, EventStatus.ACTIVE)
}

@Keep
@IgnoreExtraProperties
data class EventParticipant(
    @DocumentId val id: String = "",
    val groupId: String = "",
    val eventId: String = "",
    val memberUids: List<String> = emptyList(),
    val invitedEmails: List<String> = emptyList(),
    val name: String = "",
    val contact: String = "",
    val participantKind: String = ParticipantKind.FAMILY_MEMBER.name,
    val familyMemberId: String = "",
    val avatarColorHex: String = "#E05D38",
    val createdBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun parsedKind(): ParticipantKind = safeEnum(participantKind, ParticipantKind.FAMILY_MEMBER)
}

@Keep
@IgnoreExtraProperties
data class EventEntry(
    @DocumentId val id: String = "",
    val groupId: String = "",
    val eventId: String = "",
    val memberUids: List<String> = emptyList(),
    val invitedEmails: List<String> = emptyList(),
    val entryType: String = EventEntryType.EXPENSE.name,
    val amount: Double = 0.0,
    val categoryId: String = "",
    val categoryName: String = "",
    val categoryColorHex: String = "#D97706",
    val categoryIconKey: String = "party",
    val participantId: String = "",
    val participantName: String = "",
    val splitMode: String = EventSplitMode.ALL_PARTICIPANTS.name,
    val splitParticipantIds: List<String> = emptyList(),
    val paymentMode: String = PaymentMode.UPI.name,
    val dateMillis: Long = 0L,
    val notes: String = "",
    val createdBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun parsedEntryType(): EventEntryType = safeEnum(entryType, EventEntryType.EXPENSE)
    fun parsedSplitMode(): EventSplitMode = safeEnum(splitMode, EventSplitMode.ALL_PARTICIPANTS)
    fun parsedPaymentMode(): PaymentMode = safeEnum(paymentMode, PaymentMode.UPI)
}
