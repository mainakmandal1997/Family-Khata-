package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.AttachMoney
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cake
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.Celebration
import androidx.compose.material.icons.rounded.Checkroom
import androidx.compose.material.icons.rounded.ChildCare
import androidx.compose.material.icons.rounded.DirectionsBus
import androidx.compose.material.icons.rounded.Eco
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.Flight
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalDining
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.MedicalServices
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Park
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Pets
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.Savings
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.SetMeal
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.TempleHindu
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.ui.graphics.vector.ImageVector

data class CategoryIconOption(
    val key: String,
    val label: String,
    val labelBn: String,
    val icon: ImageVector,
)

object CategoryIconCatalog {
    val options: List<CategoryIconOption> = listOf(
        CategoryIconOption("groceries", "Groceries", "মুদিখানা", Icons.Rounded.ShoppingCart),
        CategoryIconOption("fish_meat", "Fish & Meat", "মাছ-মাংস", Icons.Rounded.SetMeal),
        CategoryIconOption("vegetables", "Vegetables", "শাকসবজি", Icons.Rounded.Eco),
        CategoryIconOption("electricity", "Bills & Power", "বিদ্যুৎ ও বিল", Icons.Rounded.Bolt),
        CategoryIconOption("water", "Water & Gas", "জল ও গ্যাস", Icons.Rounded.WaterDrop),
        CategoryIconOption("medical", "Medical", "চিকিৎসা", Icons.Rounded.MedicalServices),
        CategoryIconOption("education", "Education", "শিক্ষা", Icons.Rounded.School),
        CategoryIconOption("travel", "Travel", "ভ্রমণ", Icons.Rounded.Flight),
        CategoryIconOption("transport", "Transport", "যাতায়াত", Icons.Rounded.DirectionsBus),
        CategoryIconOption("rent", "Home & Rent", "বাড়ি ভাড়া", Icons.Rounded.Home),
        CategoryIconOption("catering", "Catering", "খাওয়া-দাওয়া", Icons.Rounded.LocalDining),
        CategoryIconOption("restaurant", "Dining Out", "রেস্তোরাঁ", Icons.Rounded.Restaurant),
        CategoryIconOption("decoration", "Decoration", "সাজসজ্জা", Icons.Rounded.Celebration),
        CategoryIconOption("gifts", "Gifts", "উপহার", Icons.Rounded.CardGiftcard),
        CategoryIconOption("venue", "Venue", "ভেন্যু", Icons.Rounded.TempleHindu),
        CategoryIconOption("music", "Music", "গান-বাজনা", Icons.Rounded.MusicNote),
        CategoryIconOption("shopping", "Shopping", "কেনাকাটা", Icons.Rounded.ShoppingBag),
        CategoryIconOption("clothing", "Clothes", "পোশাক", Icons.Rounded.Checkroom),
        CategoryIconOption("party", "Party & Cake", "পার্টি ও কেক", Icons.Rounded.Cake),
        CategoryIconOption("picnic", "Picnic", "পিকনিক", Icons.Rounded.Park),
        CategoryIconOption("photography", "Photo & Video", "ফটো ও ভিডিও", Icons.Rounded.CameraAlt),
        CategoryIconOption("internet", "Wi-Fi & Phone", "ইন্টারনেট ও ফোন", Icons.Rounded.Wifi),
        CategoryIconOption("fuel", "Fuel", "জ্বালানি", Icons.Rounded.LocalGasStation),
        CategoryIconOption("kids", "Kids & Baby", "শিশু", Icons.Rounded.ChildCare),
        CategoryIconOption("pets", "Pets", "পোষা প্রাণী", Icons.Rounded.Pets),
        CategoryIconOption("fitness", "Fitness", "স্বাস্থ্য ও জিম", Icons.Rounded.FitnessCenter),
        CategoryIconOption("salary", "Salary & Income", "বেতন ও আয়", Icons.Rounded.Payments),
        CategoryIconOption("bank", "Family Deposit", "জমা / ফান্ড", Icons.Rounded.AccountBalance),
        CategoryIconOption("savings", "Savings", "সঞ্চয়", Icons.Rounded.Savings),
        CategoryIconOption("love", "Blessing / Salami", "আশীর্বাদ / উপহার", Icons.Rounded.Favorite),
        CategoryIconOption("money", "Bonus / Cash", "বোনাস / নগদ", Icons.Rounded.AttachMoney),
        CategoryIconOption("custom_star", "Custom", "অন্যান্য", Icons.Rounded.Star),
    )

    fun resolveIcon(key: String): ImageVector {
        return options.firstOrNull { it.key == key }?.icon ?: Icons.Rounded.Star
    }

    val colorPalette: List<String> = listOf(
        "#0F766E", // Deep Emerald
        "#10B981", // Mint Green
        "#059669", // Jade
        "#0284C7", // Ocean Blue
        "#2563EB", // Cobalt
        "#6366F1", // Indigo
        "#7C3AED", // Violet
        "#DB2777", // Rose Pink
        "#E11D48", // Crimson
        "#E05D38", // Terracotta
        "#EA580C", // Sunset Orange
        "#D97706", // Saffron Gold
        "#CA8A04", // Marigold
        "#65A30D", // Olive Lime
        "#475569", // Cool Slate
        "#0D9488", // Turquoise
    )

    val avatarColors: List<String> = listOf(
        "#0F766E", "#D97706", "#E05D38", "#2563EB", "#7C3AED", "#DB2777", "#059669", "#0284C7"
    )
}

data class BuiltInCategorySeed(
    val id: String,
    val name: String,
    val nameBn: String,
    val scope: CategoryScope,
    val type: CategoryType,
    val iconKey: String,
    val colorHex: String,
)

object BuiltInDefaults {
    val categories: List<BuiltInCategorySeed> = listOf(
        BuiltInCategorySeed("cat_groceries", "Groceries", "মুদিখানা", CategoryScope.MONTHLY, CategoryType.EXPENSE, "groceries", "#10B981"),
        BuiltInCategorySeed("cat_fish_meat", "Fish & Meat", "মাছ-মাংস", CategoryScope.MONTHLY, CategoryType.EXPENSE, "fish_meat", "#E05D38"),
        BuiltInCategorySeed("cat_vegetables", "Vegetables & Fruits", "শাকসবজি ও ফল", CategoryScope.MONTHLY, CategoryType.EXPENSE, "vegetables", "#65A30D"),
        BuiltInCategorySeed("cat_electricity", "Electricity & Bills", "বিদ্যুৎ ও বিল", CategoryScope.MONTHLY, CategoryType.EXPENSE, "electricity", "#D97706"),
        BuiltInCategorySeed("cat_medical", "Medical & Pharmacy", "চিকিৎসা ও ওষুধ", CategoryScope.MONTHLY, CategoryType.EXPENSE, "medical", "#E11D48"),
        BuiltInCategorySeed("cat_education", "Education & Tuition", "শিক্ষা ও টিউশন", CategoryScope.MONTHLY, CategoryType.EXPENSE, "education", "#2563EB"),
        BuiltInCategorySeed("cat_rent", "Rent & Maintenance", "বাড়ি ভাড়া ও রক্ষণাবেক্ষণ", CategoryScope.MONTHLY, CategoryType.EXPENSE, "rent", "#0F766E"),
        BuiltInCategorySeed("cat_travel", "Travel & Transport", "যাতায়াত ও ভ্রমণ", CategoryScope.BOTH, CategoryType.EXPENSE, "transport", "#0284C7"),
        BuiltInCategorySeed("cat_shopping", "Shopping & Clothes", "কেনাকাটা ও পোশাক", CategoryScope.BOTH, CategoryType.EXPENSE, "shopping", "#DB2777"),
        BuiltInCategorySeed("cat_internet", "Wi-Fi & Mobile", "ইন্টারনেট ও মোবাইল", CategoryScope.MONTHLY, CategoryType.EXPENSE, "internet", "#6366F1"),
        BuiltInCategorySeed("cat_salary", "Family Contribution", "পারিবারিক জমা / আয়", CategoryScope.MONTHLY, CategoryType.INCOME, "salary", "#059669"),
        BuiltInCategorySeed("cat_bonus", "Bonus & Other Income", "বোনাস ও অন্যান্য আয়", CategoryScope.MONTHLY, CategoryType.INCOME, "money", "#0D9488"),
        BuiltInCategorySeed("cat_catering", "Catering & Food", "খাওয়া-দাওয়া ও ক্যাটারিং", CategoryScope.EVENT, CategoryType.EXPENSE, "catering", "#EA580C"),
        BuiltInCategorySeed("cat_decoration", "Decoration & Lights", "সাজসজ্জা ও আলো", CategoryScope.EVENT, CategoryType.EXPENSE, "decoration", "#CA8A04"),
        BuiltInCategorySeed("cat_venue", "Venue & Pandal", "ভেন্যু ও প্যান্ডেল", CategoryScope.EVENT, CategoryType.EXPENSE, "venue", "#7C3AED"),
        BuiltInCategorySeed("cat_gifts", "Gifts & Salami", "উপহার ও সালামি", CategoryScope.EVENT, CategoryType.BOTH, "gifts", "#E11D48"),
        BuiltInCategorySeed("cat_music", "Music & Entertainment", "গান-বাজনা ও বিনোদন", CategoryScope.EVENT, CategoryType.EXPENSE, "music", "#2563EB"),
        BuiltInCategorySeed("cat_event_fund", "Event Pool / Gift Received", "অনুষ্ঠান চাঁদা / উপহার প্রাপ্তি", CategoryScope.EVENT, CategoryType.INCOME, "bank", "#10B981"),
    )

    fun eventTypeLabel(type: EventType, isBengali: Boolean): String = when (type) {
        EventType.BIRTHDAY -> if (isBengali) "জন্মদিন (Birthday)" else "Birthday"
        EventType.WEDDING -> if (isBengali) "বিবাহ (Wedding)" else "Wedding"
        EventType.ANNIVERSARY -> if (isBengali) "বিবাহবার্ষিকী (Anniversary)" else "Anniversary"
        EventType.PUJA_FESTIVAL -> if (isBengali) "পূজা ও উৎসব (Puja/Festival)" else "Puja / Festival"
        EventType.FAMILY_TRIP -> if (isBengali) "পারিবারিক ভ্রমণ (Trip)" else "Family Trip / Tour"
        EventType.PICNIC -> if (isBengali) "পিকনিক (Picnic)" else "Picnic"
        EventType.HOUSEWARMING -> if (isBengali) "গৃহপ্রবেশ (Housewarming)" else "Housewarming"
        EventType.OTHER -> if (isBengali) "অন্যান্য অনুষ্ঠান (Other)" else "Other Occasion"
    }

    fun eventTypeColor(type: EventType): String = when (type) {
        EventType.BIRTHDAY -> "#DB2777"
        EventType.WEDDING -> "#E11D48"
        EventType.ANNIVERSARY -> "#7C3AED"
        EventType.PUJA_FESTIVAL -> "#D97706"
        EventType.FAMILY_TRIP -> "#0284C7"
        EventType.PICNIC -> "#10B981"
        EventType.HOUSEWARMING -> "#0F766E"
        EventType.OTHER -> "#475569"
    }
}
