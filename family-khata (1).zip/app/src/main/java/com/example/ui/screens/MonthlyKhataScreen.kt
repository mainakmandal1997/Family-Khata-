package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.logic.AppStrings
import com.example.logic.DashboardTimeScope
import com.example.logic.KhataAnalytics
import com.example.logic.MonthPeriod
import com.example.logic.YearPeriod
import com.example.logic.formatCurrency
import com.example.logic.formatDateShort
import com.example.model.BuiltInDefaults
import com.example.model.CategoryScope
import com.example.model.CategoryType
import com.example.model.EventEntryType
import com.example.model.FamilyGroup
import com.example.model.FamilyMember
import com.example.model.KhataCategory
import com.example.model.MonthlyTransaction
import com.example.model.PaymentMode
import com.example.model.SplitMode
import com.example.model.TransactionType
import com.example.ui.GroupWorkspaceData
import com.example.ui.MonthlyFilterState
import com.example.ui.components.AmountText
import com.example.ui.components.CategoryBadge
import com.example.ui.components.CategoryBreakdownRankedList
import com.example.ui.components.CategoryDonutChart
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.KhataText
import com.example.ui.components.MemberAvatar
import com.example.ui.components.PendingInvitesBanner
import com.example.ui.theme.LocalKhataSemanticColors
import com.example.ui.theme.parseHexColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonthlyKhataScreen(
    data: GroupWorkspaceData,
    dashboardScope: DashboardTimeScope,
    period: MonthPeriod,
    yearPeriod: YearPeriod,
    customDateRange: Pair<Long, Long>,
    dashboardEventId: String?,
    filters: MonthlyFilterState,
    strings: AppStrings,
    onSelectDashboardScope: (DashboardTimeScope) -> Unit,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onPreviousYear: () -> Unit,
    onNextYear: () -> Unit,
    onCustomDateRangeChange: (Long, Long) -> Unit,
    onSelectDashboardEvent: (String?) -> Unit,
    onOpenEventDetail: (String) -> Unit,
    onSearchChange: (String) -> Unit,
    onToggleTypeFilter: (TransactionType?) -> Unit,
    onMemberFilter: (String?) -> Unit,
    onCategoryFilter: (String?) -> Unit,
    onPaymentModeFilter: (PaymentMode?) -> Unit,
    onClearFilters: () -> Unit,
    onAcceptInvite: (FamilyGroup) -> Unit,
    onSaveTransaction: (
        txId: String?,
        type: TransactionType,
        amount: Double,
        category: KhataCategory,
        paidBy: FamilyMember,
        splitMode: SplitMode,
        splitMemberIds: List<String>,
        paymentMode: PaymentMode,
        dateMillis: Long,
        notes: String,
    ) -> Unit,
    onDeleteTransaction: (String) -> Unit,
) {
    val group = data.activeGroup ?: return
    val semanticColors = LocalKhataSemanticColors.current

    val activeWindow = remember(dashboardScope, period, yearPeriod, customDateRange, group.cycleStartDay) {
        when (dashboardScope) {
            DashboardTimeScope.MONTHLY -> KhataAnalytics.computeCycleWindow(period, group.cycleStartDay.toInt())
            DashboardTimeScope.YEARLY -> KhataAnalytics.computeYearWindow(yearPeriod.year)
            DashboardTimeScope.CUSTOM_RANGE -> KhataAnalytics.computeCustomWindow(customDateRange.first, customDateRange.second)
            DashboardTimeScope.EVENT -> KhataAnalytics.computeCycleWindow(period, group.cycleStartDay.toInt())
        }
    }

    val scopedTransactions = remember(data.transactions, activeWindow) {
        KhataAnalytics.filterForCycle(data.transactions, activeWindow)
    }
    val summary = remember(scopedTransactions, data.members) {
        KhataAnalytics.computeMonthlySummary(scopedTransactions, data.members)
    }

    val selectedDashEvent = remember(data.events, dashboardEventId) {
        data.events.firstOrNull { it.id == dashboardEventId } ?: data.events.firstOrNull()
    }
    val dashEventParticipants = remember(data.eventParticipants, selectedDashEvent?.id) {
        val eid = selectedDashEvent?.id ?: return@remember emptyList()
        data.eventParticipants.filter { it.eventId == eid }
    }
    val dashEventEntries = remember(data.eventEntries, selectedDashEvent?.id) {
        val eid = selectedDashEvent?.id ?: return@remember emptyList()
        data.eventEntries.filter { it.eventId == eid }
    }
    val dashEventSummary = remember(selectedDashEvent, dashEventParticipants, dashEventEntries) {
        selectedDashEvent?.let { KhataAnalytics.computeEventSummary(it, dashEventParticipants, dashEventEntries) }
    }

    val filteredTransactions = remember(scopedTransactions, filters) {
        scopedTransactions.filter { tx ->
            val matchesSearch = filters.searchQuery.isBlank() ||
                tx.categoryName.contains(filters.searchQuery, ignoreCase = true) ||
                tx.paidByName.contains(filters.searchQuery, ignoreCase = true) ||
                tx.notes.contains(filters.searchQuery, ignoreCase = true)
            val matchesType = filters.typeFilter == null || tx.parsedType() == filters.typeFilter
            val matchesMember = filters.memberIdFilter == null ||
                tx.paidByMemberId == filters.memberIdFilter ||
                filters.memberIdFilter in tx.splitMemberIds
            val matchesCat = filters.categoryIdFilter == null || tx.categoryId == filters.categoryIdFilter
            val matchesPayMode = filters.paymentModeFilter == null || tx.parsedPaymentMode() == filters.paymentModeFilter
            matchesSearch && matchesType && matchesMember && matchesCat && matchesPayMode
        }
    }

    var showExpenseBreakdown by remember { mutableStateOf(true) }
    var pickingStartDate by remember { mutableStateOf(false) }
    var pickingEndDate by remember { mutableStateOf(false) }
    var showTxSheet by remember { mutableStateOf(false) }
    var editingTx by remember { mutableStateOf<MonthlyTransaction?>(null) }
    var pendingDeleteTx by remember { mutableStateOf<MonthlyTransaction?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingTx = null
                    showTxSheet = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_transaction_fab"),
            ) {
                Icon(Icons.Rounded.Add, contentDescription = strings.addTransaction)
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 92.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (data.pendingInvites.isNotEmpty()) {
                item {
                    PendingInvitesBanner(
                        invites = data.pendingInvites,
                        onAcceptInvite = onAcceptInvite,
                    )
                }
            }

            // Quick Dashboard Scope Tabs: Monthly, Yearly, Custom Range, Individual Events
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf(
                        DashboardTimeScope.MONTHLY to strings.scopeMonthly,
                        DashboardTimeScope.YEARLY to strings.scopeYearly,
                        DashboardTimeScope.CUSTOM_RANGE to strings.scopeCustomRange,
                        DashboardTimeScope.EVENT to strings.scopeEvents,
                    ).forEach { (scope, label) ->
                        FilterChip(
                            selected = dashboardScope == scope,
                            onClick = { onSelectDashboardScope(scope) },
                            label = { KhataText(label, fontWeight = if (dashboardScope == scope) FontWeight.Bold else FontWeight.Medium) },
                            modifier = Modifier.testTag("dashboard_scope_${scope.name.lowercase()}"),
                        )
                    }
                }
            }

            // Scope-specific Period / Date / Event Selector
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    when (dashboardScope) {
                        DashboardTimeScope.MONTHLY -> {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                IconButton(
                                    onClick = onPreviousMonth,
                                    modifier = Modifier.testTag("prev_month_button"),
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, contentDescription = "Previous month")
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = period.titleLabel(),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                    )
                                    Text(
                                        text = "Cycle: ${activeWindow.rangeLabel}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                IconButton(
                                    onClick = onNextMonth,
                                    modifier = Modifier.testTag("next_month_button"),
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = "Next month")
                                }
                            }
                        }
                        DashboardTimeScope.YEARLY -> {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                IconButton(
                                    onClick = onPreviousYear,
                                    modifier = Modifier.testTag("prev_year_button"),
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, contentDescription = "Previous year")
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "Year ${yearPeriod.titleLabel()}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                    )
                                    Text(
                                        text = activeWindow.rangeLabel,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                IconButton(
                                    onClick = onNextYear,
                                    modifier = Modifier.testTag("next_year_button"),
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = "Next year")
                                }
                            }
                        }
                        DashboardTimeScope.CUSTOM_RANGE -> {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Surface(
                                    onClick = { pickingStartDate = true },
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                                    modifier = Modifier.weight(1f).testTag("custom_start_date_btn"),
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("From", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(formatDateShort(customDateRange.first), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                                Surface(
                                    onClick = { pickingEndDate = true },
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                                    modifier = Modifier.weight(1f).testTag("custom_end_date_btn"),
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("To", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(formatDateShort(customDateRange.second), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                        DashboardTimeScope.EVENT -> {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                if (data.events.isEmpty()) {
                                    Text(
                                        text = "No events created yet. Create one in the Events tab to view its live overview here.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                } else {
                                    Text("Select Event Overview", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Row(
                                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        data.events.forEach { ev ->
                                            FilterChip(
                                                selected = selectedDashEvent?.id == ev.id,
                                                onClick = { onSelectDashboardEvent(ev.id) },
                                                label = { KhataText(ev.title) },
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (dashboardScope == DashboardTimeScope.EVENT) {
                val evSum = dashEventSummary
                if (evSum != null) {
                    item {
                        Card(
                            shape = RoundedCornerShape(24.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(Color(0xFF9A3412), Color(0xFFD97706), Color(0xFFB45309))
                                        )
                                    )
                                    .padding(18.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            KhataText(
                                                text = evSum.event.title,
                                                style = MaterialTheme.typography.titleLarge,
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                            )
                                            Text(
                                                text = "${BuiltInDefaults.eventTypeLabel(evSum.event.parsedEventType(), strings.isBengali)} • ${dashEventParticipants.size} people",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = Color.White.copy(alpha = 0.85f),
                                            )
                                        }
                                        TextButton(
                                            onClick = { onOpenEventDetail(evSum.event.id) },
                                        ) {
                                            Text("Open Event →", color = Color.White, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Surface(modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp), color = Color.White.copy(alpha = 0.16f)) {
                                            Column(Modifier.padding(10.dp)) {
                                                Text("Pool / Gifts", style = MaterialTheme.typography.labelSmall, color = Color(0xFFA7F3D0))
                                                AmountText(formatCurrency(evSum.totalContributions, group.currencySymbol), style = MaterialTheme.typography.titleSmall, color = Color.White)
                                            }
                                        }
                                        Surface(modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp), color = Color.White.copy(alpha = 0.16f)) {
                                            Column(Modifier.padding(10.dp)) {
                                                Text("Spent", style = MaterialTheme.typography.labelSmall, color = Color(0xFFFDE68A))
                                                AmountText(formatCurrency(evSum.totalExpenses, group.currencySymbol), style = MaterialTheme.typography.titleSmall, color = Color.White)
                                            }
                                        }
                                        Surface(modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp), color = Color.White.copy(alpha = 0.16f)) {
                                            Column(Modifier.padding(10.dp)) {
                                                Text("Pool Net", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.85f))
                                                AmountText(formatCurrency(evSum.netEventPoolBalance, group.currencySymbol), style = MaterialTheme.typography.titleSmall, color = Color.White)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                KhataText(
                                    text = strings.categoryBreakdown,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                )
                                CategoryDonutChart(
                                    items = evSum.expenseCategories,
                                    totalAmount = evSum.totalExpenses,
                                    currencySymbol = group.currencySymbol,
                                    centerLabel = strings.eventExpenses,
                                )
                                if (evSum.expenseCategories.isNotEmpty()) {
                                    CategoryBreakdownRankedList(
                                        items = evSum.expenseCategories,
                                        currencySymbol = group.currencySymbol,
                                    )
                                }
                            }
                        }
                    }

                    if (dashEventEntries.isNotEmpty()) {
                        item {
                            Text("Recent Event Entries (${dashEventEntries.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        items(dashEventEntries.take(8), key = { it.id }) { ee ->
                            val isGift = ee.parsedEntryType() == EventEntryType.CONTRIBUTION_GIFT
                            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    CategoryBadge(ee.categoryIconKey, ee.categoryColorHex, size = 40.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        KhataText(ee.categoryName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                        Text("${ee.participantName} • ${ee.paymentMode} • ${formatDateShort(ee.dateMillis)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    AmountText(
                                        text = "${if (isGift) "+" else "-"}${formatCurrency(ee.amount, group.currencySymbol)}",
                                        color = if (isGift) semanticColors.income else semanticColors.expense,
                                        style = MaterialTheme.typography.titleSmall,
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // Hero Executive Summary Card (Monthly / Yearly / Custom Range)
                item {
                    Card(
                        shape = RoundedCornerShape(24.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            Color(0xFF0F766E),
                                            Color(0xFF0D9488),
                                            Color(0xFF115E59),
                                        )
                                    )
                                )
                                .padding(18.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column {
                                        KhataText(
                                            text = strings.netBalance,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = Color.White.copy(alpha = 0.85f),
                                        )
                                        AmountText(
                                            text = formatCurrency(summary.netBalance, group.currencySymbol),
                                            style = MaterialTheme.typography.displaySmall,
                                            color = Color.White,
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = Color.White.copy(alpha = 0.16f),
                                    ) {
                                        Text(
                                            text = "${scopedTransactions.size} entries",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    Surface(
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(14.dp),
                                        color = Color.White.copy(alpha = 0.14f),
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            KhataText(
                                                text = strings.totalIncome,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color(0xFFA7F3D0),
                                            )
                                            Spacer(Modifier.height(2.dp))
                                            AmountText(
                                                text = formatCurrency(summary.totalIncome, group.currencySymbol),
                                                style = MaterialTheme.typography.titleMedium,
                                                color = Color.White,
                                            )
                                        }
                                    }
                                    Surface(
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(14.dp),
                                        color = Color.White.copy(alpha = 0.14f),
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            KhataText(
                                                text = strings.totalExpense,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color(0xFFFDE68A),
                                            )
                                            Spacer(Modifier.height(2.dp))
                                            AmountText(
                                                text = formatCurrency(summary.totalExpense, group.currencySymbol),
                                                style = MaterialTheme.typography.titleMedium,
                                                color = Color.White,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Front-Page Category-Wise Breakdown & Percentage (Donut + Ranked List)
                item {
                    val activeCategories = if (showExpenseBreakdown) summary.expenseCategories else summary.incomeCategories
                    val activeTotal = if (showExpenseBreakdown) summary.totalExpense else summary.totalIncome
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                KhataText(
                                    text = strings.categoryBreakdown,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f),
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    FilterChip(
                                        selected = showExpenseBreakdown,
                                        onClick = { showExpenseBreakdown = true },
                                        label = { KhataText(strings.expense, style = MaterialTheme.typography.labelSmall) },
                                    )
                                    FilterChip(
                                        selected = !showExpenseBreakdown,
                                        onClick = { showExpenseBreakdown = false },
                                        label = { KhataText(strings.income, style = MaterialTheme.typography.labelSmall) },
                                    )
                                }
                            }
                            CategoryDonutChart(
                                items = activeCategories,
                                totalAmount = activeTotal,
                                currencySymbol = group.currencySymbol,
                                centerLabel = if (showExpenseBreakdown) strings.totalExpense else strings.totalIncome,
                            )
                            if (activeCategories.isNotEmpty()) {
                                CategoryBreakdownRankedList(
                                    items = activeCategories,
                                    currencySymbol = group.currencySymbol,
                                    selectedCategoryId = filters.categoryIdFilter,
                                    onCategoryClick = { catId -> onCategoryFilter(catId) },
                                )
                            }
                        }
                    }
                }

                // Per-Member Contribution vs. Spend Breakdown
                if (summary.memberBreakdowns.isNotEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                KhataText(
                                    text = strings.memberBreakdown,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                )
                                val maxVal = summary.memberBreakdowns
                                    .maxOfOrNull { maxOf(it.incomeContributed, it.expensePaid, it.fairShare) }
                                    ?.coerceAtLeast(1.0) ?: 1.0

                                summary.memberBreakdowns.forEach { m ->
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            MemberAvatar(name = m.memberName, colorHex = m.avatarColorHex, size = 30.dp)
                                            Spacer(Modifier.width(8.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = m.memberName,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.SemiBold,
                                                )
                                                Text(
                                                    text = "Pool: ${formatCurrency(m.incomeContributed, group.currencySymbol)} • Share: ${formatCurrency(m.fairShare, group.currencySymbol)}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                )
                                            }
                                            Column(horizontalAlignment = Alignment.End) {
                                                AmountText(
                                                    text = "Paid ${formatCurrency(m.expensePaid, group.currencySymbol)}",
                                                    style = MaterialTheme.typography.labelLarge,
                                                )
                                                val net = m.netSettlement
                                                Text(
                                                    text = if (net >= 0) "+${formatCurrency(net, group.currencySymbol)} owed" else "${formatCurrency(net, group.currencySymbol)} due",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = if (net >= 0) semanticColors.income else semanticColors.expense,
                                                )
                                            }
                                        }
                                        LinearProgressIndicator(
                                            progress = { (m.expensePaid / maxVal).toFloat().coerceIn(0f, 1f) },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(6.dp)
                                                .clip(RoundedCornerShape(3.dp)),
                                            color = parseHexColor(m.avatarColorHex),
                                            trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Search & Multi-Filters (Type, Payment Mode, Member, Category)
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = filters.searchQuery,
                            onValueChange = onSearchChange,
                            placeholder = { KhataText(strings.searchPlaceholder) },
                            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                            trailingIcon = {
                                if (filters.searchQuery.isNotBlank()) {
                                    IconButton(onClick = { onSearchChange("") }) {
                                        Icon(Icons.Rounded.Close, contentDescription = "Clear search")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth().testTag("tx_search_input"),
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            FilterChip(
                                selected = filters.typeFilter == null && filters.memberIdFilter == null && filters.categoryIdFilter == null && filters.paymentModeFilter == null,
                                onClick = onClearFilters,
                                label = { KhataText(strings.all) },
                            )
                            FilterChip(
                                selected = filters.typeFilter == TransactionType.EXPENSE,
                                onClick = { onToggleTypeFilter(TransactionType.EXPENSE) },
                                label = { KhataText(strings.expense) },
                            )
                            FilterChip(
                                selected = filters.typeFilter == TransactionType.INCOME,
                                onClick = { onToggleTypeFilter(TransactionType.INCOME) },
                                label = { KhataText(strings.income) },
                            )
                            PaymentMode.entries.forEach { pm ->
                                FilterChip(
                                    selected = filters.paymentModeFilter == pm,
                                    onClick = { onPaymentModeFilter(pm) },
                                    label = { Text(pm.name) },
                                )
                            }
                            data.members.forEach { member ->
                                FilterChip(
                                    selected = filters.memberIdFilter == member.id,
                                    onClick = { onMemberFilter(member.id) },
                                    label = { Text(member.name.split(" ").first()) },
                                )
                            }
                            data.categories
                                .filter { it.parsedScope() != CategoryScope.EVENT }
                                .take(10)
                                .forEach { cat ->
                                    FilterChip(
                                        selected = filters.categoryIdFilter == cat.id,
                                        onClick = { onCategoryFilter(cat.id) },
                                        label = { KhataText(cat.displayName(strings.isBengali)) },
                                    )
                                }
                        }
                    }
                }

                // Section Title
                item {
                    KhataText(
                        text = "${strings.recentTransactions} (${filteredTransactions.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                }

                if (filteredTransactions.isEmpty()) {
                    item {
                        EmptyStateCard(
                            icon = Icons.AutoMirrored.Rounded.ReceiptLong,
                            title = "No matching entries",
                            subtitle = strings.noTransactionsYet,
                            actionLabel = strings.addTransaction,
                            onAction = {
                                editingTx = null
                                showTxSheet = true
                            }
                        )
                    }
                } else {
                    items(filteredTransactions, key = { it.id }) { tx ->
                        TransactionRowCard(
                            tx = tx,
                            currencySymbol = group.currencySymbol,
                            onEdit = {
                                editingTx = tx
                                showTxSheet = true
                            },
                            onDelete = { pendingDeleteTx = tx },
                        )
                    }
                }
            }
        }
    }

    if (pickingStartDate) {
        val state = rememberDatePickerState(initialSelectedDateMillis = customDateRange.first)
        DatePickerDialog(
            onDismissRequest = { pickingStartDate = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        state.selectedDateMillis?.let { onCustomDateRangeChange(it, customDateRange.second) }
                        pickingStartDate = false
                    }
                ) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { pickingStartDate = false }) { Text("Cancel") } }
        ) { DatePicker(state = state) }
    }

    if (pickingEndDate) {
        val state = rememberDatePickerState(initialSelectedDateMillis = customDateRange.second)
        DatePickerDialog(
            onDismissRequest = { pickingEndDate = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        state.selectedDateMillis?.let { onCustomDateRangeChange(customDateRange.first, it) }
                        pickingEndDate = false
                    }
                ) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { pickingEndDate = false }) { Text("Cancel") } }
        ) { DatePicker(state = state) }
    }

    if (showTxSheet) {
        TransactionFormSheet(
            existing = editingTx,
            members = data.members,
            categories = data.categories.filter { it.parsedScope() != CategoryScope.EVENT },
            isBengali = strings.isBengali,
            currencySymbol = group.currencySymbol,
            onDismiss = { showTxSheet = false },
            onSave = { type, amount, cat, paidBy, splitMode, splitIds, payMode, dateMillis, notes ->
                onSaveTransaction(
                    editingTx?.id,
                    type,
                    amount,
                    cat,
                    paidBy,
                    splitMode,
                    splitIds,
                    payMode,
                    dateMillis,
                    notes,
                )
                showTxSheet = false
            }
        )
    }

    pendingDeleteTx?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingDeleteTx = null },
            title = { Text("Delete Transaction?") },
            text = { Text("Remove ${target.categoryName} (${formatCurrency(target.amount, group.currencySymbol)})?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteTransaction(target.id)
                        pendingDeleteTx = null
                    }
                ) {
                    Text("Delete", color = semanticColors.expense)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteTx = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun TransactionRowCard(
    tx: MonthlyTransaction,
    currencySymbol: String,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    val isIncome = tx.parsedType() == TransactionType.INCOME
    val semanticColors = LocalKhataSemanticColors.current
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEdit() }
            .testTag("tx_card_${tx.id}"),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CategoryBadge(
                iconKey = tx.categoryIconKey,
                colorHex = tx.categoryColorHex,
                size = 44.dp,
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                KhataText(
                    text = tx.categoryName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = "${tx.paidByName} • ${tx.paymentMode} • ${formatDateShort(tx.dateMillis)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (tx.notes.isNotBlank()) {
                    KhataText(
                        text = tx.notes,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                AmountText(
                    text = "${if (isIncome) "+" else "-"}${formatCurrency(tx.amount, currencySymbol)}",
                    style = MaterialTheme.typography.titleSmall,
                    color = if (isIncome) semanticColors.income else semanticColors.expense,
                )
                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Rounded.Edit, contentDescription = "Edit", modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(
                            Icons.Rounded.DeleteOutline,
                            contentDescription = "Delete",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TransactionFormSheet(
    existing: MonthlyTransaction?,
    members: List<FamilyMember>,
    categories: List<KhataCategory>,
    isBengali: Boolean,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onSave: (
        type: TransactionType,
        amount: Double,
        category: KhataCategory,
        paidBy: FamilyMember,
        splitMode: SplitMode,
        splitMemberIds: List<String>,
        paymentMode: PaymentMode,
        dateMillis: Long,
        notes: String,
    ) -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var txType by remember { mutableStateOf(existing?.parsedType() ?: TransactionType.EXPENSE) }
    var amountText by remember { mutableStateOf(existing?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "") }
    val matchingCategories = remember(categories, txType) {
        categories.filter {
            it.parsedType() == CategoryType.BOTH ||
                (txType == TransactionType.EXPENSE && it.parsedType() == CategoryType.EXPENSE) ||
                (txType == TransactionType.INCOME && it.parsedType() == CategoryType.INCOME)
        }.ifEmpty { categories }
    }
    var selectedCategory by remember(existing, matchingCategories) {
        mutableStateOf(
            matchingCategories.firstOrNull { it.id == existing?.categoryId } ?: matchingCategories.firstOrNull()
        )
    }
    var selectedMember by remember(existing, members) {
        mutableStateOf(members.firstOrNull { it.id == existing?.paidByMemberId } ?: members.firstOrNull())
    }
    var splitMode by remember { mutableStateOf(existing?.parsedSplitMode() ?: SplitMode.FULL_FAMILY) }
    var selectedSplitIds by remember {
        mutableStateOf(existing?.splitMemberIds?.toSet() ?: members.map { it.id }.toSet())
    }
    var paymentMode by remember { mutableStateOf(existing?.parsedPaymentMode() ?: PaymentMode.UPI) }
    var dateMillis by remember { mutableLongStateOf(existing?.dateMillis ?: System.currentTimeMillis()) }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var showDatePicker by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = if (existing == null) "Add Monthly Khata Entry" else "Edit Entry",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )

            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = txType == TransactionType.EXPENSE,
                    onClick = { txType = TransactionType.EXPENSE },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                ) { Text("Expenditure") }
                SegmentedButton(
                    selected = txType == TransactionType.INCOME,
                    onClick = { txType = TransactionType.INCOME },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                ) { Text("Income / Pool") }
            }

            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                label = { Text("Amount ($currencySymbol)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("tx_amount_input"),
            )

            Text("Category", style = MaterialTheme.typography.labelLarge)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                matchingCategories.forEach { cat ->
                    val isSelected = selectedCategory?.id == cat.id
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = cat },
                        leadingIcon = { CategoryBadge(cat.iconKey, cat.colorHex, size = 24.dp, iconSize = 14.dp) },
                        label = { KhataText(cat.displayName(isBengali)) },
                    )
                }
            }

            Text(
                text = if (txType == TransactionType.EXPENSE) "Paid By" else "Received / Contributed By",
                style = MaterialTheme.typography.labelLarge
            )
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                members.forEach { m ->
                    FilterChip(
                        selected = selectedMember?.id == m.id,
                        onClick = { selectedMember = m },
                        label = { Text(m.name) },
                    )
                }
            }

            if (txType == TransactionType.EXPENSE) {
                Text("Split Option", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    SplitMode.entries.forEach { mode ->
                        val label = when (mode) {
                            SplitMode.FULL_FAMILY -> "Full Family"
                            SplitMode.SELECTED_MEMBERS -> "Selected Members"
                            SplitMode.INDIVIDUAL -> "Individual"
                        }
                        FilterChip(
                            selected = splitMode == mode,
                            onClick = { splitMode = mode },
                            label = { Text(label) },
                        )
                    }
                }
                if (splitMode == SplitMode.SELECTED_MEMBERS) {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        members.forEach { m ->
                            val checked = m.id in selectedSplitIds
                            FilterChip(
                                selected = checked,
                                onClick = {
                                    selectedSplitIds = if (checked && selectedSplitIds.size > 1) {
                                        selectedSplitIds - m.id
                                    } else {
                                        selectedSplitIds + m.id
                                    }
                                },
                                label = { Text(m.name) },
                            )
                        }
                    }
                }
            }

            Text("Payment Mode", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PaymentMode.entries.forEach { pm ->
                    FilterChip(
                        selected = paymentMode == pm,
                        onClick = { paymentMode = pm },
                        label = { Text(pm.name) },
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("Date: ${formatDateShort(dateMillis)}", style = MaterialTheme.typography.bodyMedium)
                TextButton(onClick = { showDatePicker = true }) {
                    Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Change Date")
                }
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes (e.g., Rohu fish, electricity bill)") },
                maxLines = 2,
                modifier = Modifier.fillMaxWidth(),
            )

            val parsedAmount = amountText.toDoubleOrNull()
            val canSave = parsedAmount != null && parsedAmount > 0.0 && selectedCategory != null && selectedMember != null
            Button(
                onClick = {
                    val cat = selectedCategory ?: return@Button
                    val member = selectedMember ?: return@Button
                    val amt = parsedAmount ?: return@Button
                    val finalSplits = when (splitMode) {
                        SplitMode.FULL_FAMILY -> members.map { it.id }
                        SplitMode.SELECTED_MEMBERS -> selectedSplitIds.toList()
                        SplitMode.INDIVIDUAL -> listOf(member.id)
                    }
                    onSave(txType, amt, cat, member, splitMode, finalSplits, paymentMode, dateMillis, notes)
                },
                enabled = canSave,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_tx_button"),
            ) {
                Text(if (existing == null) "Save Entry" else "Update Entry")
            }

            Spacer(Modifier.height(18.dp))
        }
    }

    if (showDatePicker) {
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = dateMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        pickerState.selectedDateMillis?.let { dateMillis = it }
                        showDatePicker = false
                    }
                ) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = pickerState)
        }
    }
}
