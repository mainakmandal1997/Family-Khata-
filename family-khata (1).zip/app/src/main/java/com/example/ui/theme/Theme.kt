package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = OnEmeraldContainer,
    secondary = SaffronSecondary,
    onSecondary = Color.White,
    secondaryContainer = SaffronContainer,
    onSecondaryContainer = OnSaffronContainer,
    tertiary = TerracottaTertiary,
    onTertiary = Color.White,
    tertiaryContainer = TerracottaContainer,
    onTertiaryContainer = OnTerracottaContainer,
    background = AlabasterBackground,
    onBackground = SlateInk,
    surface = WarmSurface,
    onSurface = SlateInk,
    surfaceVariant = WarmSurfaceVariant,
    onSurfaceVariant = SlateMuted,
    outline = WarmOutline,
    outlineVariant = WarmOutline,
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = DarkOnPrimary,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = Color(0xFFCFFAFE),
    secondary = DarkSecondary,
    onSecondary = Color(0xFF2B1A00),
    secondaryContainer = DarkSecondaryContainer,
    onSecondaryContainer = Color(0xFFFEF3C7),
    tertiary = DarkTertiary,
    onTertiary = Color(0xFF331400),
    tertiaryContainer = Color(0xFF5D250B),
    onTertiaryContainer = Color(0xFFFFE5DC),
    background = DarkBackground,
    onBackground = Color(0xFFF1F5F9),
    surface = DarkSurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = DarkOutline,
    outlineVariant = DarkOutline,
)

@Immutable
data class KhataSemanticColors(
    val income: Color = IncomeGreen,
    val expense: Color = ExpenseRed,
    val isDark: Boolean = false,
)

val LocalKhataSemanticColors = staticCompositionLocalOf { KhataSemanticColors() }

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun FamilyKhataTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val semanticColors = if (darkTheme) {
        KhataSemanticColors(income = IncomeGreenDark, expense = ExpenseRedDark, isDark = true)
    } else {
        KhataSemanticColors(income = IncomeGreen, expense = ExpenseRed, isDark = false)
    }

    CompositionLocalProvider(LocalKhataSemanticColors provides semanticColors) {
        MaterialTheme(
            colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme,
            typography = AppTypography,
            shapes = AppShapes,
            content = content,
        )
    }
}
