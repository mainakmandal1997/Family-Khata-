package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GroupAdd
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.logic.CategoryBreakdownItem
import com.example.logic.formatCurrency
import com.example.model.CategoryIconCatalog
import com.example.model.FamilyGroup
import com.example.ui.theme.BengaliFontFamily
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.containsBengaliScript
import com.example.ui.theme.parseHexColor
import java.util.Locale

@Composable
fun KhataText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    color: Color = Color.Unspecified,
    fontWeight: FontWeight? = null,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip,
) {
    val resolvedFamily = if (containsBengaliScript(text)) BengaliFontFamily else style.fontFamily
    Text(
        text = text,
        modifier = modifier,
        style = style.copy(fontFamily = resolvedFamily),
        color = color,
        fontWeight = fontWeight,
        maxLines = maxLines,
        overflow = overflow,
    )
}

@Composable
fun AmountText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = MaterialTheme.typography.titleMedium,
    color: Color = MaterialTheme.colorScheme.onSurface,
    fontWeight: FontWeight = FontWeight.Bold,
) {
    Text(
        text = text,
        modifier = modifier,
        style = style.copy(fontFamily = MonoFontFamily, fontWeight = fontWeight),
        color = color,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}

@Composable
fun CategoryBadge(
    iconKey: String,
    colorHex: String,
    size: Dp = 44.dp,
    iconSize: Dp = 22.dp,
    selected: Boolean = false,
) {
    val accent = parseHexColor(colorHex)
    val bg = accent.copy(alpha = 0.16f)
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.32f))
            .background(bg)
            .then(
                if (selected) {
                    Modifier.border(2.dp, accent, RoundedCornerShape(size * 0.32f))
                } else {
                    Modifier.border(1.dp, accent.copy(alpha = 0.25f), RoundedCornerShape(size * 0.32f))
                }
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = CategoryIconCatalog.resolveIcon(iconKey),
            contentDescription = iconKey,
            tint = accent,
            modifier = Modifier.size(iconSize),
        )
    }
}

@Composable
fun MemberAvatar(
    name: String,
    colorHex: String,
    size: Dp = 38.dp,
) {
    val accent = parseHexColor(colorHex)
    val initials = name.trim()
        .split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercaseChar().toString() }
        .ifBlank { "M" }

    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(accent.copy(alpha = 0.18f))
            .border(1.5.dp, accent.copy(alpha = 0.5f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = initials,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = accent,
        )
    }
}

@Composable
fun CategoryDonutChart(
    items: List<CategoryBreakdownItem>,
    totalAmount: Double,
    currencySymbol: String,
    centerLabel: String,
    modifier: Modifier = Modifier,
) {
    var targetSweep by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(items) { targetSweep = 1f }
    val sweepProgress by animateFloatAsState(
        targetValue = targetSweep,
        animationSpec = tween(durationMillis = 650),
        label = "donut_sweep"
    )

    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Box(
            modifier = Modifier.size(136.dp),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                val strokeWidth = 22.dp.toPx()
                val diameter = size.minDimension - strokeWidth
                val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
                val arcSize = Size(diameter, diameter)

                if (items.isEmpty() || totalAmount <= 0.0) {
                    drawArc(
                        color = Color(0xFFE2E8F0),
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth)
                    )
                } else {
                    var startAngle = -90f
                    items.forEach { cat ->
                        val rawSweep = ((cat.percentage / 100.0) * 360.0).toFloat()
                        val gap = if (items.size > 1) 3f else 0f
                        val actualSweep = ((rawSweep - gap) * sweepProgress).coerceAtLeast(1f)
                        drawArc(
                            color = parseHexColor(cat.colorHex),
                            startAngle = startAngle,
                            sweepAngle = actualSweep,
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                        )
                        startAngle += rawSweep * sweepProgress
                    }
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                KhataText(
                    text = centerLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                AmountText(
                    text = formatCurrency(totalAmount, currencySymbol),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
        }

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (items.isEmpty()) {
                KhataText(
                    text = "No category data yet",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                items.take(5).forEach { cat ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(parseHexColor(cat.colorHex))
                        )
                        Spacer(Modifier.width(8.dp))
                        KhataText(
                            text = cat.categoryName,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = String.format(Locale.US, "%.0f%%", cat.percentage),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PendingInvitesBanner(
    invites: List<FamilyGroup>,
    onAcceptInvite: (FamilyGroup) -> Unit,
) {
    if (invites.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        invites.forEach { group ->
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                ),
                shape = RoundedCornerShape(16.dp),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.GroupAdd,
                        contentDescription = "Family invite",
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        KhataText(
                            text = "Invited to ${group.name}",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            fontWeight = FontWeight.Bold,
                        )
                        KhataText(
                            text = "Tap Join for live shared Khata access",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f),
                        )
                    }
                    Button(
                        onClick = { onAcceptInvite(group) },
                        modifier = Modifier.testTag("accept_invite_${group.id}"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary,
                            contentColor = MaterialTheme.colorScheme.onSecondary,
                        ),
                    ) {
                        Text("Join")
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyStateCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(40.dp),
            )
            KhataText(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            KhataText(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (actionLabel != null && onAction != null) {
                Button(
                    onClick = onAction,
                    modifier = Modifier.padding(top = 4.dp),
                ) {
                    KhataText(text = actionLabel)
                }
            }
        }
    }
}

@Composable
fun CategoryBreakdownRankedList(
    items: List<CategoryBreakdownItem>,
    currencySymbol: String,
    selectedCategoryId: String? = null,
    onCategoryClick: ((String) -> Unit)? = null,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.forEach { cat ->
            val accent = parseHexColor(cat.colorHex)
            val isSelected = selectedCategoryId != null && selectedCategoryId == cat.categoryId
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = if (isSelected) accent.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.42f),
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (onCategoryClick != null) {
                            Modifier.clip(RoundedCornerShape(14.dp)).clickable { onCategoryClick(cat.categoryId) }
                        } else {
                            Modifier
                        }
                    ),
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        CategoryBadge(
                            iconKey = cat.iconKey,
                            colorHex = cat.colorHex,
                            size = 36.dp,
                            iconSize = 18.dp,
                            selected = isSelected,
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            KhataText(
                                text = cat.categoryName,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = "${cat.transactionCount} ${if (cat.transactionCount == 1) "entry" else "entries"}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            AmountText(
                                text = formatCurrency(cat.totalAmount, currencySymbol),
                                style = MaterialTheme.typography.labelLarge,
                            )
                            Text(
                                text = String.format(Locale.US, "%.1f%%", cat.percentage),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = accent,
                            )
                        }
                    }
                    LinearProgressIndicator(
                        progress = { (cat.percentage / 100.0).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = accent,
                        trackColor = MaterialTheme.colorScheme.surface,
                    )
                }
            }
        }
    }
}

