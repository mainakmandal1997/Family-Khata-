package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.logic.AppStrings
import com.example.model.CategoryIconCatalog
import com.example.model.CategoryScope
import com.example.model.CategoryType
import com.example.model.KhataCategory
import com.example.ui.GroupWorkspaceData
import com.example.ui.components.CategoryBadge
import com.example.ui.components.KhataText
import com.example.ui.theme.parseHexColor

@Composable
fun CategoriesScreen(
    data: GroupWorkspaceData,
    strings: AppStrings,
    onSaveCategory: (
        categoryId: String?,
        name: String,
        nameBn: String,
        scope: CategoryScope,
        type: CategoryType,
        iconKey: String,
        colorHex: String,
    ) -> Unit,
    onDeleteCategory: (String) -> Unit,
) {
    var scopeFilter by remember { mutableStateOf<CategoryScope?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var editingCat by remember { mutableStateOf<KhataCategory?>(null) }

    val filteredCategories = remember(data.categories, scopeFilter) {
        data.categories.filter { cat ->
            scopeFilter == null || cat.parsedScope() == scopeFilter || cat.parsedScope() == CategoryScope.BOTH
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingCat = null
                    showEditor = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_category_fab"),
            ) {
                Icon(Icons.Rounded.Add, contentDescription = strings.addCustomCategory)
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 92.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    KhataText(
                        text = strings.categoriesTitle,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = "Built-in & unlimited custom categories with colorful icons and bilingual labels.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = scopeFilter == null,
                            onClick = { scopeFilter = null },
                            label = { Text("All (${data.categories.size})") },
                        )
                        FilterChip(
                            selected = scopeFilter == CategoryScope.MONTHLY,
                            onClick = { scopeFilter = CategoryScope.MONTHLY },
                            label = { Text("Monthly") },
                        )
                        FilterChip(
                            selected = scopeFilter == CategoryScope.EVENT,
                            onClick = { scopeFilter = CategoryScope.EVENT },
                            label = { Text("Events") },
                        )
                    }
                }
            }

            items(filteredCategories, key = { it.id }) { cat ->
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().testTag("cat_card_${cat.id}"),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        CategoryBadge(
                            iconKey = cat.iconKey,
                            colorHex = cat.colorHex,
                            size = 46.dp,
                            iconSize = 24.dp,
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            KhataText(
                                text = cat.name,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                            )
                            if (cat.nameBn.isNotBlank()) {
                                KhataText(
                                    text = cat.nameBn,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(top = 4.dp),
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                ) {
                                    Text(
                                        text = cat.scope,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = parseHexColor(cat.colorHex).copy(alpha = 0.14f),
                                ) {
                                    Text(
                                        text = cat.type,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = parseHexColor(cat.colorHex),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    )
                                }
                            }
                        }

                        IconButton(
                            onClick = {
                                editingCat = cat
                                showEditor = true
                            }
                        ) {
                            Icon(Icons.Rounded.Edit, contentDescription = "Edit category")
                        }
                        if (!cat.builtIn) {
                            IconButton(onClick = { onDeleteCategory(cat.id) }) {
                                Icon(
                                    Icons.Rounded.DeleteOutline,
                                    contentDescription = "Delete custom category",
                                    tint = MaterialTheme.colorScheme.error,
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditor) {
        CategoryCreatorSheet(
            existing = editingCat,
            onDismiss = { showEditor = false },
            onSave = { name, nameBn, scope, type, iconKey, colorHex ->
                onSaveCategory(editingCat?.id, name, nameBn, scope, type, iconKey, colorHex)
                showEditor = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CategoryCreatorSheet(
    existing: KhataCategory?,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        nameBn: String,
        scope: CategoryScope,
        type: CategoryType,
        iconKey: String,
        colorHex: String,
    ) -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var nameBn by remember { mutableStateOf(existing?.nameBn ?: "") }
    var scope by remember { mutableStateOf(existing?.parsedScope() ?: CategoryScope.MONTHLY) }
    var type by remember { mutableStateOf(existing?.parsedType() ?: CategoryType.EXPENSE) }
    var selectedIconKey by remember { mutableStateOf(existing?.iconKey ?: CategoryIconCatalog.options.first().key) }
    var selectedColorHex by remember { mutableStateOf(existing?.colorHex ?: CategoryIconCatalog.colorPalette.first()) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                CategoryBadge(
                    iconKey = selectedIconKey,
                    colorHex = selectedColorHex,
                    size = 52.dp,
                    iconSize = 26.dp,
                    selected = true,
                )
                Column {
                    Text(
                        text = if (existing == null) "Create Custom Category" else "Customize Category",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    KhataText(
                        text = name.ifBlank { "Live Badge Preview" },
                        style = MaterialTheme.typography.bodyMedium,
                        color = parseHexColor(selectedColorHex),
                    )
                }
            }

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Category Name (English)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("category_name_input"),
            )

            OutlinedTextField(
                value = nameBn,
                onValueChange = { nameBn = it },
                label = { Text("Bengali Label (Optional, e.g. মিষ্টি ও পুজো)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Scope", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CategoryScope.entries.forEach { s ->
                    FilterChip(
                        selected = scope == s,
                        onClick = { scope = s },
                        label = { Text(s.name) },
                    )
                }
            }

            Text("Transaction Type", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CategoryType.entries.forEach { t ->
                    FilterChip(
                        selected = type == t,
                        onClick = { type = t },
                        label = { Text(t.name) },
                    )
                }
            }

            Text("Colorful Accent Color", style = MaterialTheme.typography.labelLarge)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                CategoryIconCatalog.colorPalette.forEach { hex ->
                    val c = parseHexColor(hex)
                    val isSelected = selectedColorHex.equals(hex, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(c)
                            .then(
                                if (isSelected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                else Modifier
                            )
                            .clickable { selectedColorHex = hex },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (isSelected) {
                            Icon(Icons.Rounded.Check, contentDescription = "Selected color", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            Text("Icon / Logo Picker", style = MaterialTheme.typography.labelLarge)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                CategoryIconCatalog.options.chunked(5).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        rowItems.forEach { opt ->
                            val isSelected = selectedIconKey == opt.key
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedIconKey = opt.key }
                                    .padding(vertical = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                CategoryBadge(
                                    iconKey = opt.key,
                                    colorHex = selectedColorHex,
                                    size = 44.dp,
                                    iconSize = 22.dp,
                                    selected = isSelected,
                                )
                                Text(
                                    text = opt.label.split(" ").first(),
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                )
                            }
                        }
                        repeat(5 - rowItems.size) {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(name, nameBn, scope, type, selectedIconKey, selectedColorHex)
                    }
                },
                enabled = name.isNotBlank(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_category_button"),
            ) {
                Text(if (existing == null) "Create Category" else "Save Changes")
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}
