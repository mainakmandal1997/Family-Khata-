package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.example.security.BiometricHelper
import com.example.ui.components.KhataText

@Composable
fun AppLockScreen(
    pinLength: Int,
    biometricEnabled: Boolean,
    isBengali: Boolean,
    onVerifyPin: suspend (String) -> Boolean,
    onUnlocked: () -> Unit,
    onResetPinSignOut: () -> Unit,
) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    val biometricSupported = remember(context) {
        BiometricHelper.isBiometricOrDeviceCredentialAvailable(context)
    }

    var enteredPin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showForgotDialog by remember { mutableStateOf(false) }

    // Trigger BiometricPrompt automatically once if enabled and supported
    LaunchedEffect(biometricEnabled, biometricSupported) {
        if (biometricEnabled && biometricSupported && activity != null) {
            BiometricHelper.authenticate(
                activity = activity,
                title = if (isBengali) "ফ্যামিলি খাতা আনলক করুন" else "Unlock Family Khata",
                subtitle = if (isBengali) "বায়োমেট্রিক বা ডিভাইস লক ব্যবহার করুন" else "Verify with Fingerprint, Face, or Device Lock",
                onSuccess = onUnlocked,
                onError = { msg -> errorMessage = msg },
            )
        }
    }

    // Auto-verify once full PIN length is entered
    LaunchedEffect(enteredPin) {
        if (enteredPin.length == pinLength) {
            val ok = onVerifyPin(enteredPin)
            if (ok) {
                errorMessage = null
                onUnlocked()
            } else {
                errorMessage = if (isBengali) "ভুল পিন! আবার চেষ্টা করুন।" else "Incorrect PIN. Try again."
                enteredPin = ""
            }
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Spacer(Modifier.height(12.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = "App locked",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp),
                    )
                }

                KhataText(
                    text = if (isBengali) "ফ্যামিলি খাতা লক করা আছে" else "Family Khata Locked",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                )
                KhataText(
                    text = if (isBengali) {
                        "$pinLength-সংখ্যার সিকিউরিটি পিন লিখুন"
                    } else {
                        "Enter your $pinLength-digit Security PIN"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                Spacer(Modifier.height(10.dp))

                // PIN Dots Indicator
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    repeat(pinLength) { idx ->
                        val filled = idx < enteredPin.length
                        val dotColor by animateColorAsState(
                            targetValue = when {
                                errorMessage != null -> MaterialTheme.colorScheme.error
                                filled -> MaterialTheme.colorScheme.primary
                                else -> MaterialTheme.colorScheme.surfaceVariant
                            },
                            label = "pin_dot",
                        )
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(dotColor)
                                .border(
                                    width = 1.5.dp,
                                    color = if (filled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                    shape = CircleShape,
                                )
                        )
                    }
                }

                if (!errorMessage.isNullOrBlank()) {
                    KhataText(
                        text = errorMessage ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                } else {
                    Spacer(Modifier.height(22.dp))
                }
            }

            // Responsive Numeric Keypad
            Column(
                modifier = Modifier.widthIn(max = 320.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                val rows = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                )
                rows.forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                    ) {
                        row.forEach { digit ->
                            PinDigitButton(
                                digit = digit,
                                onClick = {
                                    if (enteredPin.length < pinLength) {
                                        errorMessage = null
                                        enteredPin += digit
                                    }
                                },
                            )
                        }
                    }
                }

                // Bottom row: Biometric (optional), 0, Backspace
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        modifier = Modifier.size(68.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (biometricEnabled && activity != null) {
                            Surface(
                                onClick = {
                                    if (biometricSupported) {
                                        BiometricHelper.authenticate(
                                            activity = activity,
                                            title = if (isBengali) "ফ্যামিলি খাতা আনলক করুন" else "Unlock Family Khata",
                                            subtitle = if (isBengali) "বায়োমেট্রিক বা ডিভাইস লক ব্যবহার করুন" else "Verify with Fingerprint, Face, or Device Lock",
                                            onSuccess = onUnlocked,
                                            onError = { msg -> errorMessage = msg },
                                        )
                                    } else {
                                        errorMessage = if (isBengali) {
                                            "ডিভাইসে বায়োমেট্রিক সেট করা নেই। পিন ব্যবহার করুন।"
                                        } else {
                                            "No biometric enrolled on device. Please enter PIN."
                                        }
                                    }
                                },
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(56.dp).testTag("biometric_unlock_button"),
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Rounded.Fingerprint,
                                        contentDescription = "Unlock with biometrics",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(28.dp),
                                    )
                                }
                            }
                        }
                    }

                    PinDigitButton(
                        digit = "0",
                        onClick = {
                            if (enteredPin.length < pinLength) {
                                errorMessage = null
                                enteredPin += "0"
                            }
                        },
                    )

                    Surface(
                        onClick = {
                            if (enteredPin.isNotEmpty()) {
                                enteredPin = enteredPin.dropLast(1)
                            }
                        },
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(68.dp).testTag("pin_backspace_button"),
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Backspace,
                                contentDescription = "Backspace",
                                tint = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
            }

            TextButton(
                onClick = { showForgotDialog = true },
                modifier = Modifier.testTag("forgot_pin_button"),
            ) {
                KhataText(
                    text = if (isBengali) "পিন ভুলে গেছেন? রিসেট করুন" else "Forgot PIN? Reset via Google Sign-Out",
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }
    }

    if (showForgotDialog) {
        AlertDialog(
            onDismissRequest = { showForgotDialog = false },
            title = {
                KhataText(if (isBengali) "সিকিউরিটি পিন রিসেট?" else "Reset Security PIN?")
            },
            text = {
                KhataText(
                    if (isBengali) {
                        "নিরাপত্তার জন্য পিন রিসেট করলে আপনার গুগল অ্যাকাউন্ট থেকে সাইন-আউট হবে। পুনরায় সাইন-ইন করে আপনি নতুন পিন সেট করতে পারবেন।"
                    } else {
                        "For your privacy, resetting a forgotten PIN signs you out of Google so you can verify your account and set a new PIN."
                    }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showForgotDialog = false
                        onResetPinSignOut()
                    }
                ) {
                    Text(if (isBengali) "রিসেট ও সাইন-আউট" else "Reset & Sign Out", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showForgotDialog = false }) {
                    Text(if (isBengali) "বাতিল" else "Cancel")
                }
            },
        )
    }
}

@Composable
private fun PinDigitButton(
    digit: String,
    onClick: () -> Unit,
) {
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        modifier = Modifier
            .size(68.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .testTag("pin_digit_$digit"),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = digit,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}
