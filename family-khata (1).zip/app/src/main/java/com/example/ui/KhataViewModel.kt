package com.example.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.KhataRepository
import com.example.data.friendlyFirestoreMessage
import com.example.logic.DashboardTimeScope
import com.example.logic.KhataAnalytics
import com.example.logic.MonthPeriod
import com.example.logic.MonthlySummary
import com.example.logic.YearPeriod
import com.example.model.CategoryScope
import com.example.model.CategoryType
import com.example.model.EventEntry
import com.example.model.EventEntryType
import com.example.model.EventParticipant
import com.example.model.EventSplitMode
import com.example.model.EventStatus
import com.example.model.EventType
import com.example.model.FamilyEvent
import com.example.model.FamilyGroup
import com.example.model.FamilyMember
import com.example.model.KhataCategory
import com.example.model.MemberRole
import com.example.model.MonthlyTransaction
import com.example.model.ParticipantKind
import com.example.model.PaymentMode
import com.example.model.SplitMode
import com.example.model.TransactionType
import com.example.model.UserProfile
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

data class MonthlyFilterState(
    val searchQuery: String = "",
    val typeFilter: TransactionType? = null,
    val memberIdFilter: String? = null,
    val categoryIdFilter: String? = null,
    val paymentModeFilter: PaymentMode? = null,
)

data class GroupWorkspaceData(
    val activeGroup: FamilyGroup?,
    val allGroups: List<FamilyGroup>,
    val pendingInvites: List<FamilyGroup>,
    val members: List<FamilyMember>,
    val categories: List<KhataCategory>,
    val transactions: List<MonthlyTransaction>,
    val events: List<FamilyEvent>,
    val eventParticipants: List<EventParticipant>,
    val eventEntries: List<EventEntry>,
)

class KhataViewModel(
    private val repository: KhataRepository,
    val currentUserId: String,
    private val userDisplayName: String,
    private val userEmail: String,
) : ViewModel() {

    private val _dashboardScope = MutableStateFlow(DashboardTimeScope.MONTHLY)
    val dashboardScope: StateFlow<DashboardTimeScope> = _dashboardScope.asStateFlow()

    private val _selectedPeriod = MutableStateFlow(MonthPeriod.current())
    val selectedPeriod: StateFlow<MonthPeriod> = _selectedPeriod.asStateFlow()

    private val _selectedYear = MutableStateFlow(YearPeriod.current())
    val selectedYear: StateFlow<YearPeriod> = _selectedYear.asStateFlow()

    private val _customDateRange = MutableStateFlow(
        Pair(
            System.currentTimeMillis() - 30L * 24L * 60L * 60L * 1000L,
            System.currentTimeMillis(),
        )
    )
    val customDateRange: StateFlow<Pair<Long, Long>> = _customDateRange.asStateFlow()

    private val _dashboardEventId = MutableStateFlow<String?>(null)
    val dashboardEventId: StateFlow<String?> = _dashboardEventId.asStateFlow()

    private val _filters = MutableStateFlow(MonthlyFilterState())
    val filters: StateFlow<MonthlyFilterState> = _filters.asStateFlow()

    private val _selectedEventId = MutableStateFlow<String?>(null)
    val selectedEventId: StateFlow<String?> = _selectedEventId.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _snackbarEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val snackbarEvents = _snackbarEvents.asSharedFlow()

    init {
        viewModelScope.launch {
            repository.ensureUserProfile(
                displayName = userDisplayName,
                email = userEmail,
            )
        }
    }

    private fun <T> Flow<T>.toSafeUiState(tag: String): StateFlow<UiState<T>> {
        return this
            .map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Stream error in $tag", rootError)
                emit(UiState.Error(friendlyFirestoreMessage(rootError)))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )
    }

    val userProfileState: StateFlow<UiState<UserProfile?>> =
        repository.observeUserProfile(currentUserId)
            .toSafeUiState("userProfile")

    private val groupsAndInvitesFlow = combine(
        repository.observeMyGroups(currentUserId),
        repository.observePendingInvites(currentUserId),
        repository.observeUserProfile(currentUserId),
    ) { myGroups, invites, profile ->
        val active = myGroups.firstOrNull { it.id == profile?.activeGroupId }
            ?: myGroups.firstOrNull()
        Triple(active, myGroups to invites, profile)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val workspaceState: StateFlow<UiState<GroupWorkspaceData>> =
        groupsAndInvitesFlow.flatMapLatest { (activeGroup, groupPair, _) ->
            val (myGroups, invites) = groupPair
            if (activeGroup == null) {
                flowOf(
                    GroupWorkspaceData(
                        activeGroup = null,
                        allGroups = myGroups,
                        pendingInvites = invites,
                        members = emptyList(),
                        categories = emptyList(),
                        transactions = emptyList(),
                        events = emptyList(),
                        eventParticipants = emptyList(),
                        eventEntries = emptyList(),
                    )
                )
            } else {
                combine(
                    repository.observeMembers(activeGroup.id, currentUserId),
                    repository.observeCategories(activeGroup.id, currentUserId),
                    repository.observeTransactions(activeGroup.id, currentUserId),
                    repository.observeEvents(activeGroup.id, currentUserId),
                    repository.observeEventParticipants(activeGroup.id, currentUserId),
                    repository.observeEventEntries(activeGroup.id, currentUserId),
                ) { array ->
                    @Suppress("UNCHECKED_CAST")
                    GroupWorkspaceData(
                        activeGroup = activeGroup,
                        allGroups = myGroups,
                        pendingInvites = invites,
                        members = array[0] as List<FamilyMember>,
                        categories = array[1] as List<KhataCategory>,
                        transactions = array[2] as List<MonthlyTransaction>,
                        events = array[3] as List<FamilyEvent>,
                        eventParticipants = array[4] as List<EventParticipant>,
                        eventEntries = array[5] as List<EventEntry>,
                    )
                }
            }
        }.toSafeUiState("workspace")

    // --- UI STATE ACTIONS ---

    fun setDashboardScope(scope: DashboardTimeScope) {
        _dashboardScope.value = scope
    }

    fun previousMonth() {
        _selectedPeriod.value = _selectedPeriod.value.previous()
    }

    fun nextMonth() {
        _selectedPeriod.value = _selectedPeriod.value.next()
    }

    fun previousYear() {
        _selectedYear.value = _selectedYear.value.previous()
    }

    fun nextYear() {
        _selectedYear.value = _selectedYear.value.next()
    }

    fun updateCustomDateRange(startMillis: Long, endMillis: Long) {
        _customDateRange.value = minOf(startMillis, endMillis) to maxOf(startMillis, endMillis)
    }

    fun selectDashboardEvent(eventId: String?) {
        _dashboardEventId.value = eventId
    }

    fun updateSearchQuery(query: String) {
        _filters.value = _filters.value.copy(searchQuery = query)
    }

    fun toggleTypeFilter(type: TransactionType?) {
        _filters.value = _filters.value.copy(
            typeFilter = if (_filters.value.typeFilter == type) null else type
        )
    }

    fun setMemberFilter(memberId: String?) {
        _filters.value = _filters.value.copy(
            memberIdFilter = if (_filters.value.memberIdFilter == memberId) null else memberId
        )
    }

    fun setCategoryFilter(categoryId: String?) {
        _filters.value = _filters.value.copy(
            categoryIdFilter = if (_filters.value.categoryIdFilter == categoryId) null else categoryId
        )
    }

    fun setPaymentModeFilter(mode: PaymentMode?) {
        _filters.value = _filters.value.copy(
            paymentModeFilter = if (_filters.value.paymentModeFilter == mode) null else mode
        )
    }

    fun clearFilters() {
        _filters.value = MonthlyFilterState()
    }

    fun selectEvent(eventId: String?) {
        _selectedEventId.value = eventId
    }

    fun toggleLanguage(currentlyBengali: Boolean) {
        launchAction {
            repository.updateUserProfile(preferredLanguage = if (currentlyBengali) "en" else "bn")
        }
    }

    fun switchActiveGroup(groupId: String) {
        launchAction {
            _selectedEventId.value = null
            repository.updateUserProfile(activeGroupId = groupId)
        }
    }

    // --- MUTATIONS ---

    fun createFamilyGroup(
        name: String,
        currencySymbol: String,
        cycleStartDay: Int,
        ownerPhone: String,
        onComplete: () -> Unit = {},
    ) {
        launchAction(successMessage = "Family Khata group created") {
            val res = repository.createFamilyGroup(
                name = name,
                currencySymbol = currencySymbol,
                cycleStartDay = cycleStartDay,
                ownerDisplayName = userDisplayName.ifBlank { "Admin" },
                ownerEmail = userEmail,
                ownerPhone = ownerPhone,
            )
            if (res.isSuccess) onComplete()
            res.map { }
        }
    }

    fun updateGroupSettings(
        groupId: String,
        name: String,
        currencySymbol: String,
        cycleStartDay: Int,
        onComplete: () -> Unit = {},
    ) {
        launchAction(successMessage = "Group settings updated") {
            val res = repository.updateFamilyGroupSettings(groupId, name, currencySymbol, cycleStartDay)
            if (res.isSuccess) onComplete()
            res
        }
    }

    fun acceptInvite(group: FamilyGroup) {
        launchAction(successMessage = "Joined ${group.name}") {
            repository.acceptGroupInvite(group)
        }
    }

    fun inviteMember(
        group: FamilyGroup,
        name: String,
        email: String,
        phone: String,
        role: MemberRole,
        avatarColorHex: String,
        onComplete: () -> Unit = {},
    ) {
        launchAction(successMessage = "Member added to ${group.name}") {
            val res = repository.addOrInviteMember(group, name, email, phone, role, avatarColorHex)
            if (res.isSuccess) onComplete()
            res
        }
    }

    fun toggleMemberRole(group: FamilyGroup, member: FamilyMember) {
        val nextRole = if (member.parsedRole() == MemberRole.ADMIN) MemberRole.MEMBER else MemberRole.ADMIN
        launchAction(successMessage = "${member.name} is now ${nextRole.name}") {
            repository.updateMemberRole(group, member, nextRole)
        }
    }

    fun removeMember(group: FamilyGroup, member: FamilyMember) {
        launchAction(successMessage = "Removed ${member.name}") {
            repository.removeMember(group, member)
        }
    }

    fun saveCategory(
        group: FamilyGroup,
        categoryId: String?,
        name: String,
        nameBn: String,
        scope: CategoryScope,
        type: CategoryType,
        iconKey: String,
        colorHex: String,
        onComplete: () -> Unit = {},
    ) {
        launchAction(successMessage = "Category saved") {
            val res = repository.saveCustomCategory(group, categoryId, name, nameBn, scope, type, iconKey, colorHex)
            if (res.isSuccess) onComplete()
            res
        }
    }

    fun deleteCategory(groupId: String, categoryId: String) {
        launchAction(successMessage = "Category deleted") {
            repository.deleteCategory(groupId, categoryId)
        }
    }

    fun saveMonthlyTransaction(
        group: FamilyGroup,
        txId: String?,
        type: TransactionType,
        amount: Double,
        category: KhataCategory,
        paidBy: FamilyMember,
        splitMode: SplitMode,
        splitMemberIds: List<String>,
        paymentMode: PaymentMode,
        dateMillis: Long,
        notes: String,
        onComplete: () -> Unit = {},
    ) {
        launchAction(successMessage = if (txId == null) "Entry added" else "Entry updated") {
            val res = repository.saveTransaction(
                group = group,
                txId = txId,
                type = type,
                amount = amount,
                category = category,
                paidBy = paidBy,
                splitMode = splitMode,
                splitMemberIds = splitMemberIds,
                paymentMode = paymentMode,
                dateMillis = dateMillis,
                notes = notes,
            )
            if (res.isSuccess) onComplete()
            res
        }
    }

    fun deleteMonthlyTransaction(groupId: String, txId: String) {
        launchAction(successMessage = "Transaction deleted") {
            repository.deleteTransaction(groupId, txId)
        }
    }

    fun saveEvent(
        group: FamilyGroup,
        eventId: String?,
        title: String,
        eventType: EventType,
        budget: Double,
        startDateMillis: Long,
        endDateMillis: Long,
        venue: String,
        notes: String,
        accentColorHex: String,
        status: EventStatus,
        initialFamilyParticipants: List<FamilyMember>,
        onComplete: (String) -> Unit = {},
    ) {
        launchAction(successMessage = if (eventId == null) "Event created" else "Event updated") {
            val res = repository.saveEvent(
                group = group,
                eventId = eventId,
                title = title,
                eventType = eventType,
                budget = budget,
                startDateMillis = startDateMillis,
                endDateMillis = endDateMillis,
                venue = venue,
                notes = notes,
                accentColorHex = accentColorHex,
                status = status,
                initialFamilyParticipants = initialFamilyParticipants,
            )
            res.onSuccess { newId -> onComplete(newId) }
            res.map { }
        }
    }

    fun deleteEvent(groupId: String, eventId: String, onDeleted: () -> Unit = {}) {
        launchAction(successMessage = "Event deleted") {
            val res = repository.deleteEvent(groupId, eventId, currentUserId)
            if (res.isSuccess) {
                _selectedEventId.value = null
                onDeleted()
            }
            res
        }
    }

    fun addEventParticipant(
        group: FamilyGroup,
        eventId: String,
        name: String,
        contact: String,
        kind: ParticipantKind,
        familyMemberId: String,
        avatarColorHex: String,
        onComplete: () -> Unit = {},
    ) {
        launchAction(successMessage = "$name added to event") {
            val res = repository.addEventParticipant(
                group = group,
                eventId = eventId,
                name = name,
                contact = contact,
                kind = kind,
                familyMemberId = familyMemberId,
                avatarColorHex = avatarColorHex,
            )
            if (res.isSuccess) onComplete()
            res
        }
    }

    fun deleteEventParticipant(groupId: String, participantId: String) {
        launchAction(successMessage = "Participant removed") {
            repository.deleteEventParticipant(groupId, participantId)
        }
    }

    fun saveEventEntry(
        group: FamilyGroup,
        eventId: String,
        entryId: String?,
        entryType: EventEntryType,
        amount: Double,
        category: KhataCategory,
        participant: EventParticipant,
        splitMode: EventSplitMode,
        splitParticipantIds: List<String>,
        paymentMode: PaymentMode,
        dateMillis: Long,
        notes: String,
        onComplete: () -> Unit = {},
    ) {
        launchAction(successMessage = if (entryId == null) "Event entry added" else "Event entry updated") {
            val res = repository.saveEventEntry(
                group = group,
                eventId = eventId,
                entryId = entryId,
                entryType = entryType,
                amount = amount,
                category = category,
                participant = participant,
                splitMode = splitMode,
                splitParticipantIds = splitParticipantIds,
                paymentMode = paymentMode,
                dateMillis = dateMillis,
                notes = notes,
            )
            if (res.isSuccess) onComplete()
            res
        }
    }

    fun deleteEventEntry(groupId: String, entryId: String) {
        launchAction(successMessage = "Event entry deleted") {
            repository.deleteEventEntry(groupId, entryId)
        }
    }

    fun buildBackupJson(data: GroupWorkspaceData): String? {
        val group = data.activeGroup ?: return null
        return repository.buildBackupJson(
            group = group,
            members = data.members,
            categories = data.categories,
            transactions = data.transactions,
            events = data.events,
            participants = data.eventParticipants,
            entries = data.eventEntries,
        )
    }

    fun markBackupCompleted() {
        launchAction {
            repository.updateUserProfile(lastBackupAtMillis = System.currentTimeMillis())
        }
    }

    fun restoreFromJson(group: FamilyGroup, jsonString: String) {
        launchAction {
            val res = repository.restoreFromBackupJson(group, jsonString)
            res.onSuccess { count ->
                _snackbarEvents.tryEmit("Restored $count records into ${group.name}")
            }
            res.map { }
        }
    }

    fun computeMonthlySummary(
        group: FamilyGroup,
        transactions: List<MonthlyTransaction>,
        members: List<FamilyMember>,
        period: MonthPeriod,
    ): Pair<List<MonthlyTransaction>, MonthlySummary> {
        val window = KhataAnalytics.computeCycleWindow(period, group.cycleStartDay.toInt())
        val cycleTxs = KhataAnalytics.filterForCycle(transactions, window)
        val summary = KhataAnalytics.computeMonthlySummary(cycleTxs, members)
        return cycleTxs to summary
    }

    fun notifyMessage(msg: String) {
        _snackbarEvents.tryEmit(msg)
    }

    private fun launchAction(
        successMessage: String? = null,
        block: suspend () -> Result<Unit>,
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val res = block()
                res.onSuccess {
                    if (!successMessage.isNullOrBlank()) {
                        _snackbarEvents.tryEmit(successMessage)
                    }
                }.onFailure { err ->
                    _snackbarEvents.tryEmit(friendlyFirestoreMessage(err))
                }
            } finally {
                _isBusy.value = false
            }
        }
    }

    private companion object {
        const val TAG = "KhataVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
