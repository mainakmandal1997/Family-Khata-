package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm Ledger Brand Palette (Emerald Teal + Saffron Amber + Terracotta + Alabaster)
val EmeraldPrimary = Color(0xFF0F766E)
val EmeraldDark = Color(0xFF0B5A53)
val EmeraldContainer = Color(0xFFD9F3EE)
val OnEmeraldContainer = Color(0xFF063A35)

val SaffronSecondary = Color(0xFFD97706)
val SaffronContainer = Color(0xFFFEF3C7)
val OnSaffronContainer = Color(0xFF5A2E02)

val TerracottaTertiary = Color(0xFFE05D38)
val TerracottaContainer = Color(0xFFFFE5DC)
val OnTerracottaContainer = Color(0xFF5D1D0B)

val AlabasterBackground = Color(0xFFFAF8F5)
val WarmSurface = Color(0xFFFFFFFF)
val WarmSurfaceVariant = Color(0xFFF2EFE9)
val SlateInk = Color(0xFF18181B)
val SlateMuted = Color(0xFF52525B)
val WarmOutline = Color(0xFFE4DFD5)

// Dark Theme Palette
val DarkBackground = Color(0xFF0D1413)
val DarkSurface = Color(0xFF15201E)
val DarkSurfaceVariant = Color(0xFF1F2D2A)
val DarkPrimary = Color(0xFF4FD1C5)
val DarkOnPrimary = Color(0xFF04322E)
val DarkPrimaryContainer = Color(0xFF0D4F49)
val DarkSecondary = Color(0xFFFBBF24)
val DarkSecondaryContainer = Color(0xFF593B04)
val DarkTertiary = Color(0xFFFB923C)
val DarkOutline = Color(0xFF2D3E3A)

// Semantic Ledger Status Colors
val IncomeGreen = Color(0xFF15803D)
val IncomeGreenDark = Color(0xFF4ADE80)
val IncomeGreenBg = Color(0xFFDCFCE7)
val ExpenseRed = Color(0xFFDC2626)
val ExpenseRedDark = Color(0xFFF87171)
val ExpenseRedBg = Color(0xFFFEE2E2)
val InfoBlue = Color(0xFF0284C7)
val InfoBlueBg = Color(0xFFE0F2FE)

fun parseHexColor(hex: String, fallback: Color = EmeraldPrimary): Color {
    return try {
        val clean = hex.trim().removePrefix("#")
        val parsed = when (clean.length) {
            6 -> ("FF$clean").toLong(16)
            8 -> clean.toLong(16)
            else -> return fallback
        }
        Color(parsed)
    } catch (_: Exception) {
        fallback
    }
}
