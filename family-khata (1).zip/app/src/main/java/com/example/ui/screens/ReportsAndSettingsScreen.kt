package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Pin
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.export.ReportGenerator
import com.example.logic.AppStrings
import com.example.logic.DashboardTimeScope
import com.example.logic.KhataAnalytics
import com.example.logic.MonthPeriod
import com.example.logic.YearPeriod
import com.example.logic.formatDateShort
import com.example.logic.formatDateTime
import com.example.model.CategoryIconCatalog
import com.example.model.FamilyGroup
import com.example.model.FamilyMember
import com.example.model.MemberRole
import com.example.model.UserProfile
import com.example.security.AppPreferencesState
import com.example.security.AutoLockTimeout
import com.example.security.BiometricHelper
import com.example.security.ThemeMode
import com.example.ui.GroupWorkspaceData
import com.example.ui.components.KhataText
import com.example.ui.components.MemberAvatar
import com.example.ui.theme.LocalKhataSemanticColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsAndSettingsScreen(
    data: GroupWorkspaceData,
    profile: UserProfile?,
    period: MonthPeriod,
    selectedYear: Int,
    customDateRange: Pair<Long, Long>,
    appPrefs: AppPreferencesState,
    currentUserId: String,
    userEmail: String,
    strings: AppStrings,
    onSetThemeMode: (ThemeMode) -> Unit,
    onSavePin: (pin: String, pinLength: Int) -> Unit,
    onToggleAppLock: (Boolean) -> Unit,
    onToggleBiometric: (Boolean) -> Unit,
    onSetAutoLockTimeout: (AutoLockTimeout) -> Unit,
    onClearPin: () -> Unit,
    onSwitchGroup: (String) -> Unit,
    onCreateGroup: (name: String, currency: String, cycleDay: Int, phone: String) -> Unit,
    onUpdateGroupSettings: (groupId: String, name: String, currency: String, cycleDay: Int) -> Unit,
    onInviteMember: (name: String, email: String, phone: String, role: MemberRole, colorHex: String) -> Unit,
    onToggleMemberRole: (FamilyMember) -> Unit,
    onRemoveMember: (FamilyMember) -> Unit,
    onToggleLanguage: () -> Unit,
    onBuildBackupJson: () -> String?,
    onBackupSaved: () -> Unit,
    onRestoreBackupJson: (String) -> Unit,
    onNotify: (String) -> Unit,
    onSignOutClick: () -> Unit,
) {
    val context = LocalContext.current
    val group = data.activeGroup ?: return
    val semanticColors = LocalKhataSemanticColors.current
    val biometricSupported = remember(context) {
        BiometricHelper.isBiometricOrDeviceCredentialAvailable(context)
    }
    val isCurrentUserAdmin = remember(group, currentUserId) {
        currentUserId in group.adminUids
    }

    var exportScope by remember { mutableStateOf(DashboardTimeScope.MONTHLY) }
    var exportYear by remember(selectedYear) { mutableIntStateOf(selectedYear) }
    var exportStartMillis by remember(customDateRange) { mutableStateOf(customDateRange.first) }
    var exportEndMillis by remember(customDateRange) { mutableStateOf(customDateRange.second) }
    var pickingExportStart by remember { mutableStateOf(false) }
    var pickingExportEnd by remember { mutableStateOf(false) }

    val exportWindow = remember(exportScope, period, exportYear, exportStartMillis, exportEndMillis, group.cycleStartDay) {
        when (exportScope) {
            DashboardTimeScope.YEARLY -> KhataAnalytics.computeYearWindow(exportYear)
            DashboardTimeScope.CUSTOM_RANGE -> KhataAnalytics.computeCustomWindow(exportStartMillis, exportEndMillis)
            else -> KhataAnalytics.computeCycleWindow(period, group.cycleStartDay.toInt())
        }
    }
    val exportTitle = remember(exportScope, period, exportYear, exportWindow) {
        when (exportScope) {
            DashboardTimeScope.YEARLY -> YearPeriod(exportYear).titleLabel()
            DashboardTimeScope.CUSTOM_RANGE -> exportWindow.rangeLabel
            else -> period.titleLabel()
        }
    }
    val exportTransactions = remember(data.transactions, exportWindow) {
        KhataAnalytics.filterForCycle(data.transactions, exportWindow)
    }
    val exportSummary = remember(exportTransactions, data.members) {
        KhataAnalytics.computeMonthlySummary(exportTransactions, data.members)
    }

    var showInviteSheet by remember { mutableStateOf(false) }
    var showCreateGroupSheet by remember { mutableStateOf(false) }
    var showEditGroupSheet by remember { mutableStateOf(false) }
    var showPinSetupSheet by remember { mutableStateOf(false) }

    // SAF launchers for Google Drive / Device Save & Restore (zero storage permission required)
    val savePdfToDriveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            try {
                val tempPdf = ReportGenerator.generateMonthlyPdfToFile(
                    context = context,
                    group = group,
                    periodTitle = exportTitle,
                    cycleRangeLabel = exportWindow.rangeLabel,
                    summary = exportSummary,
                    transactions = exportTransactions,
                )
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    tempPdf.inputStream().use { input -> input.copyTo(out) }
                }
                onNotify("Saved PDF report successfully")
            } catch (e: Exception) {
                onNotify("Failed to save PDF: ${e.localizedMessage}")
            }
        }
    }

    val saveXlsxToDriveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(ReportGenerator.XLSX_MIME)
    ) { uri ->
        if (uri != null) {
            try {
                val tempXlsx = ReportGenerator.generateMonthlyXlsxToFile(
                    context = context,
                    group = group,
                    periodTitle = exportTitle,
                    cycleRangeLabel = exportWindow.rangeLabel,
                    summary = exportSummary,
                    transactions = exportTransactions,
                )
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    tempXlsx.inputStream().use { input -> input.copyTo(out) }
                }
                onNotify("Saved Excel (.xlsx) workbook successfully")
            } catch (e: Exception) {
                onNotify("Failed to save Excel: ${e.localizedMessage}")
            }
        }
    }

    val saveCsvToDriveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            try {
                val csv = ReportGenerator.writeMonthlyCsv(
                    group, exportTitle, exportWindow.rangeLabel, exportTransactions
                )
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(csv.toByteArray(Charsets.UTF_8))
                }
                onNotify("Saved CSV report successfully")
            } catch (e: Exception) {
                onNotify("Failed to save CSV: ${e.localizedMessage}")
            }
        }
    }

    val saveBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            try {
                val json = onBuildBackupJson() ?: return@rememberLauncherForActivityResult
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(json.toByteArray(Charsets.UTF_8))
                }
                onBackupSaved()
                onNotify("Backup saved to Google Drive / Files")
            } catch (e: Exception) {
                onNotify("Backup failed: ${e.localizedMessage}")
            }
        }
    }

    val restoreBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (!raw.isNullOrBlank()) {
                    onRestoreBackupJson(raw)
                }
            } catch (e: Exception) {
                onNotify("Restore failed: ${e.localizedMessage}")
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                KhataText(
                    text = strings.reportsAndSyncTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                OutlinedButton(
                    onClick = onToggleLanguage,
                    modifier = Modifier.testTag("language_toggle_button"),
                ) {
                    Icon(Icons.Rounded.Translate, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (strings.isBengali) "English" else "বাংলা")
                }
            }
        }

        // 1. Multi-Format Export Card (PDF, Excel .xlsx & CSV across Month / Year / Custom Date Range)
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    KhataText(
                        text = "${strings.exportPdf} — $exportTitle",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        listOf(
                            DashboardTimeScope.MONTHLY to strings.scopeMonthly,
                            DashboardTimeScope.YEARLY to strings.scopeYearly,
                            DashboardTimeScope.CUSTOM_RANGE to strings.scopeCustomRange,
                        ).forEach { (scopeOpt, label) ->
                            FilterChip(
                                selected = exportScope == scopeOpt,
                                onClick = { exportScope = scopeOpt },
                                label = { KhataText(label) },
                            )
                        }
                    }

                    if (exportScope == DashboardTimeScope.YEARLY) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            IconButton(onClick = { exportYear-- }) {
                                Icon(Icons.Rounded.ChevronLeft, contentDescription = "Previous year")
                            }
                            Text("Year $exportYear", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            IconButton(onClick = { exportYear++ }) {
                                Icon(Icons.Rounded.ChevronRight, contentDescription = "Next year")
                            }
                        }
                    } else if (exportScope == DashboardTimeScope.CUSTOM_RANGE) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            OutlinedButton(
                                onClick = { pickingExportStart = true },
                                modifier = Modifier.weight(1f),
                            ) {
                                Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("From: ${formatDateShort(exportStartMillis)}", style = MaterialTheme.typography.labelMedium)
                            }
                            OutlinedButton(
                                onClick = { pickingExportEnd = true },
                                modifier = Modifier.weight(1f),
                            ) {
                                Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("To: ${formatDateShort(exportEndMillis)}", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }

                    Text(
                        text = "${exportTransactions.size} entries (${exportWindow.rangeLabel}) • Executive Summary, Category %, Member Net & Ledger.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    val safeSlug = exportTitle.replace(Regex("[^a-zA-Z0-9_]"), "_")

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(
                            onClick = {
                                val file = ReportGenerator.generateMonthlyPdfToFile(
                                    context, group, exportTitle, exportWindow.rangeLabel, exportSummary, exportTransactions
                                )
                                ReportGenerator.shareFile(context, file, "application/pdf", "Share Khata PDF")
                                onNotify("PDF generated for $exportTitle")
                            },
                            modifier = Modifier.weight(1f).testTag("export_monthly_pdf_button"),
                        ) {
                            Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Share PDF")
                        }
                        OutlinedButton(
                            onClick = {
                                savePdfToDriveLauncher.launch("FamilyKhata_$safeSlug.pdf")
                            },
                            modifier = Modifier.weight(1f).testTag("save_monthly_pdf_drive_button"),
                        ) {
                            Icon(Icons.Rounded.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Save PDF")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(
                            onClick = {
                                val file = ReportGenerator.generateMonthlyXlsxToFile(
                                    context, group, exportTitle, exportWindow.rangeLabel, exportSummary, exportTransactions
                                )
                                ReportGenerator.shareFile(context, file, ReportGenerator.XLSX_MIME, "Share Excel (.xlsx)")
                                onNotify("Excel (.xlsx) generated for $exportTitle")
                            },
                            modifier = Modifier.weight(1f).testTag("export_monthly_xlsx_button"),
                        ) {
                            Icon(Icons.Rounded.TableChart, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Share .xlsx")
                        }
                        OutlinedButton(
                            onClick = {
                                saveXlsxToDriveLauncher.launch("FamilyKhata_$safeSlug.xlsx")
                            },
                            modifier = Modifier.weight(1f).testTag("save_monthly_xlsx_button"),
                        ) {
                            Icon(Icons.Rounded.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Save .xlsx")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedButton(
                            onClick = {
                                val file = ReportGenerator.generateMonthlyPdfToFile(
                                    context, group, exportTitle, exportWindow.rangeLabel, exportSummary, exportTransactions
                                )
                                ReportGenerator.printPdfFile(context, file, "Family Khata $exportTitle")
                            },
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(Icons.Rounded.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Print PDF")
                        }
                        OutlinedButton(
                            onClick = {
                                val csv = ReportGenerator.writeMonthlyCsv(
                                    group, exportTitle, exportWindow.rangeLabel, exportTransactions
                                )
                                val csvFile = ReportGenerator.writeTempTextFile(
                                    context, "Khata_$safeSlug.csv", csv
                                )
                                ReportGenerator.shareFile(context, csvFile, "text/csv", "Export CSV")
                                onNotify("CSV exported")
                            },
                            modifier = Modifier.weight(1f).testTag("export_monthly_csv_button"),
                        ) {
                            Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            KhataText(strings.exportCsv)
                        }
                        OutlinedButton(
                            onClick = { saveCsvToDriveLauncher.launch("FamilyKhata_$safeSlug.csv") },
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(Icons.Rounded.Description, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Save CSV")
                        }
                    }
                }
            }
        }

        // 2. Appearance (Light / Dark) & App Privacy Lock Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Rounded.DarkMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        KhataText(
                            text = strings.appearanceAndSecurity,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }

                    KhataText(strings.themeModeTitle, style = MaterialTheme.typography.labelLarge)
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        ThemeMode.entries.forEachIndexed { idx, mode ->
                            SegmentedButton(
                                selected = appPrefs.themeMode == mode,
                                onClick = { onSetThemeMode(mode) },
                                shape = SegmentedButtonDefaults.itemShape(index = idx, count = ThemeMode.entries.size),
                                modifier = Modifier.testTag("theme_mode_${mode.name.lowercase()}"),
                            ) {
                                Text(
                                    when (mode) {
                                        ThemeMode.SYSTEM -> "System"
                                        ThemeMode.LIGHT -> "Light"
                                        ThemeMode.DARK -> "Dark"
                                    }
                                )
                            }
                        }
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Icon(Icons.Rounded.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Column {
                                KhataText(strings.appPrivacyLock, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = if (appPrefs.hasPinSet) {
                                        "${appPrefs.pinLength}-digit Security PIN configured"
                                    } else {
                                        "Protect family ledger with a 4 or 6-digit PIN"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        Switch(
                            checked = appPrefs.isAppLockEnabled && appPrefs.hasPinSet,
                            onCheckedChange = { enable ->
                                if (enable && !appPrefs.hasPinSet) {
                                    showPinSetupSheet = true
                                } else {
                                    onToggleAppLock(enable)
                                }
                            },
                            modifier = Modifier.testTag("app_lock_switch"),
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(
                            onClick = { showPinSetupSheet = true },
                            modifier = Modifier.weight(1f).testTag("setup_change_pin_button"),
                        ) {
                            Icon(Icons.Rounded.Pin, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (appPrefs.hasPinSet) "Change PIN" else "Set Security PIN")
                        }
                        if (appPrefs.hasPinSet) {
                            OutlinedButton(
                                onClick = onClearPin,
                                modifier = Modifier.weight(1f).testTag("clear_pin_button"),
                            ) {
                                Text("Remove PIN")
                            }
                        }
                    }

                    if (appPrefs.hasPinSet) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Icon(Icons.Rounded.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                Column {
                                    Text("Biometric / Device Lock", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        text = if (biometricSupported) {
                                            "Allow Fingerprint, Face, or Device PIN to unlock"
                                        } else {
                                            "No device biometric enrolled (PIN still works)"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                            Switch(
                                checked = appPrefs.isBiometricEnabled,
                                onCheckedChange = onToggleBiometric,
                                enabled = biometricSupported,
                                modifier = Modifier.testTag("biometric_lock_switch"),
                            )
                        }

                        Text("Auto-Lock After Background", style = MaterialTheme.typography.labelLarge)
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            AutoLockTimeout.entries.forEach { timeout ->
                                FilterChip(
                                    selected = appPrefs.autoLockTimeout == timeout,
                                    onClick = { onSetAutoLockTimeout(timeout) },
                                    label = { KhataText(if (strings.isBengali) timeout.labelBn else timeout.labelEn) },
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Google Cloud Sync & Backup / Restore Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.CloudDone, contentDescription = null, tint = semanticColors.income)
                        Spacer(Modifier.width(8.dp))
                        KhataText(
                            text = strings.googleBackupSync,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                    Text(
                        text = "Live Cloud Sync active for $userEmail",
                        style = MaterialTheme.typography.bodySmall,
                        color = semanticColors.income,
                    )
                    val lastBackup = profile?.lastBackupAtMillis ?: 0L
                    Text(
                        text = if (lastBackup > 0L) "Last JSON Backup: ${formatDateTime(lastBackup)}" else "No manual Drive JSON backup taken yet",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(
                            onClick = {
                                saveBackupLauncher.launch("FamilyKhata_Backup_${System.currentTimeMillis()}.json")
                            },
                            modifier = Modifier.weight(1f).testTag("backup_drive_json_button"),
                        ) {
                            Icon(Icons.Rounded.Backup, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Drive Backup")
                        }
                        OutlinedButton(
                            onClick = {
                                restoreBackupLauncher.launch(arrayOf("application/json", "text/plain"))
                            },
                            modifier = Modifier.weight(1f).testTag("restore_json_button"),
                        ) {
                            Icon(Icons.Rounded.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Restore")
                        }
                    }

                    TextButton(
                        onClick = {
                            val json = onBuildBackupJson() ?: return@TextButton
                            val file = ReportGenerator.writeTempTextFile(context, "FamilyKhata_Backup.json", json)
                            ReportGenerator.shareFile(context, file, "application/json", "Share Khata JSON Backup")
                            onBackupSaved()
                        },
                        modifier = Modifier.align(Alignment.End),
                    ) {
                        Text("Share JSON File")
                    }
                }
            }
        }

        // 3. Family Khata Group & Members Management
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        KhataText(
                            text = strings.familyGroupSettings,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                        Row {
                            if (isCurrentUserAdmin) {
                                TextButton(onClick = { showEditGroupSheet = true }) { Text("Edit") }
                            }
                            TextButton(onClick = { showCreateGroupSheet = true }) {
                                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("New")
                            }
                        }
                    }

                    if (data.allGroups.size > 1) {
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            data.allGroups.forEach { g ->
                                FilterChip(
                                    selected = g.id == group.id,
                                    onClick = { onSwitchGroup(g.id) },
                                    label = { Text(g.name) },
                                )
                            }
                        }
                    }

                    Text(
                        text = "${group.name} • Currency: ${group.currencySymbol} • Cycle starts: ${group.cycleStartDay}th",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Members (${data.members.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        if (isCurrentUserAdmin) {
                            Button(
                                onClick = { showInviteSheet = true },
                                modifier = Modifier.testTag("invite_member_button"),
                            ) {
                                Icon(Icons.Rounded.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                KhataText(strings.inviteMember)
                            }
                        }
                    }

                    data.members.forEach { member ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            MemberAvatar(member.name, member.avatarColorHex, size = 38.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(member.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (member.parsedRole() == MemberRole.ADMIN) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                    ) {
                                        Text(
                                            text = member.role,
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        )
                                    }
                                }
                                val contact = listOf(member.email, member.phone).filter { it.isNotBlank() }.joinToString(" • ")
                                if (contact.isNotBlank()) {
                                    Text(contact, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            if (isCurrentUserAdmin && member.linkedUid != group.ownerId) {
                                IconButton(onClick = { onToggleMemberRole(member) }) {
                                    Icon(Icons.Rounded.AdminPanelSettings, contentDescription = "Toggle role")
                                }
                                IconButton(onClick = { onRemoveMember(member) }) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Remove member", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Sign Out
        item {
            OutlinedButton(
                onClick = onSignOutClick,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("sign_out_button"),
            ) {
                Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Sign Out ($userEmail)")
            }
        }
    }

    if (showInviteSheet) {
        InviteMemberSheet(
            memberCount = data.members.size,
            onDismiss = { showInviteSheet = false },
            onInvite = { name, email, phone, role, color ->
                onInviteMember(name, email, phone, role, color)
                showInviteSheet = false
            }
        )
    }

    if (showCreateGroupSheet) {
        GroupSettingsSheet(
            title = "Create New Family Group",
            initialName = "",
            initialCurrency = "₹",
            initialCycleDay = 1,
            onDismiss = { showCreateGroupSheet = false },
            onSave = { name, currency, cycleDay ->
                onCreateGroup(name, currency, cycleDay, "")
                showCreateGroupSheet = false
            }
        )
    }

    if (showEditGroupSheet) {
        GroupSettingsSheet(
            title = "Edit Group Settings",
            initialName = group.name,
            initialCurrency = group.currencySymbol,
            initialCycleDay = group.cycleStartDay.toInt(),
            onDismiss = { showEditGroupSheet = false },
            onSave = { name, currency, cycleDay ->
                onUpdateGroupSettings(group.id, name, currency, cycleDay)
                showEditGroupSheet = false
            }
        )
    }

    if (showPinSetupSheet) {
        PinSetupBottomSheet(
            initialLength = appPrefs.pinLength,
            onDismiss = { showPinSetupSheet = false },
            onSavePin = { pin, len ->
                onSavePin(pin, len)
                showPinSetupSheet = false
                onNotify("Security PIN saved & App Lock enabled")
            }
        )
    }

    if (pickingExportStart) {
        val state = rememberDatePickerState(initialSelectedDateMillis = exportStartMillis)
        DatePickerDialog(
            onDismissRequest = { pickingExportStart = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        state.selectedDateMillis?.let { exportStartMillis = it }
                        pickingExportStart = false
                    }
                ) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { pickingExportStart = false }) { Text("Cancel") } }
        ) { DatePicker(state = state) }
    }

    if (pickingExportEnd) {
        val state = rememberDatePickerState(initialSelectedDateMillis = exportEndMillis)
        DatePickerDialog(
            onDismissRequest = { pickingExportEnd = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        state.selectedDateMillis?.let { exportEndMillis = it }
                        pickingExportEnd = false
                    }
                ) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { pickingExportEnd = false }) { Text("Cancel") } }
        ) { DatePicker(state = state) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PinSetupBottomSheet(
    initialLength: Int,
    onDismiss: () -> Unit,
    onSavePin: (pin: String, pinLength: Int) -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var pinLength by remember { mutableIntStateOf(if (initialLength == 6) 6 else 4) }
    var pinInput by remember { mutableStateOf("") }
    var confirmInput by remember { mutableStateOf("") }

    val pinValid = pinInput.length == pinLength && pinInput.all { it.isDigit() }
    val matches = pinValid && pinInput == confirmInput

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = "Configure Security PIN",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = "Stored locally with cryptographic SHA-256 salted hashing on this device.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = pinLength == 4,
                    onClick = {
                        pinLength = 4
                        pinInput = pinInput.take(4)
                        confirmInput = confirmInput.take(4)
                    },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                ) { Text("4-Digit PIN") }
                SegmentedButton(
                    selected = pinLength == 6,
                    onClick = { pinLength = 6 },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                ) { Text("6-Digit PIN") }
            }

            OutlinedTextField(
                value = pinInput,
                onValueChange = { raw -> pinInput = raw.filter { it.isDigit() }.take(pinLength) },
                label = { Text("Enter $pinLength-digit PIN") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("setup_pin_input"),
            )

            OutlinedTextField(
                value = confirmInput,
                onValueChange = { raw -> confirmInput = raw.filter { it.isDigit() }.take(pinLength) },
                label = { Text("Confirm $pinLength-digit PIN") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true,
                isError = confirmInput.length == pinLength && !matches,
                supportingText = if (confirmInput.length == pinLength && !matches) {
                    { Text("PINs do not match") }
                } else null,
                modifier = Modifier.fillMaxWidth().testTag("confirm_pin_input"),
            )

            Button(
                onClick = { onSavePin(pinInput, pinLength) },
                enabled = matches,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("save_pin_button"),
            ) {
                Text("Save Security PIN")
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun InviteMemberSheet(
    memberCount: Int,
    onDismiss: () -> Unit,
    onInvite: (name: String, email: String, phone: String, role: MemberRole, colorHex: String) -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(MemberRole.MEMBER) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Invite / Add Family Member", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                text = "Adding an email grants live shared access as soon as they sign in with Google.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Member Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("invite_name_input"),
            )
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email Address (for live shared sync)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("invite_email_input"),
            )
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Mobile Number") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("invite_phone_input"),
            )

            Text("Role", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MemberRole.entries.forEach { r ->
                    FilterChip(
                        selected = role == r,
                        onClick = { role = r },
                        label = { Text(if (r == MemberRole.ADMIN) "Admin / Manager" else "Member") },
                    )
                }
            }

            Button(
                onClick = {
                    val color = CategoryIconCatalog.avatarColors[memberCount % CategoryIconCatalog.avatarColors.size]
                    onInvite(name, email, phone, role, color)
                },
                enabled = name.isNotBlank() && (email.isNotBlank() || phone.isNotBlank()),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("save_invite_button"),
            ) {
                Text("Add Family Member")
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GroupSettingsSheet(
    title: String,
    initialName: String,
    initialCurrency: String,
    initialCycleDay: Int,
    onDismiss: () -> Unit,
    onSave: (name: String, currency: String, cycleDay: Int) -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var name by remember { mutableStateOf(initialName) }
    var currency by remember { mutableStateOf(initialCurrency) }
    var cycleDay by remember { mutableIntStateOf(initialCycleDay) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Family Group Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Text("Currency Symbol", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("₹", "৳", "$", "€", "£").forEach { sym ->
                    FilterChip(selected = currency == sym, onClick = { currency = sym }, label = { Text(sym) })
                }
            }
            Text("Monthly Cycle Start Day: $cycleDay", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 5, 10, 15, 25).forEach { d ->
                    FilterChip(selected = cycleDay == d, onClick = { cycleDay = d }, label = { Text("${d}th") })
                }
            }
            Button(
                onClick = { onSave(name, currency, cycleDay) },
                enabled = name.isNotBlank(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp),
            ) {
                Text("Save")
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
