package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Celebration
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.GroupAdd
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.export.ReportGenerator
import com.example.logic.AppStrings
import com.example.logic.KhataAnalytics
import com.example.logic.formatCurrency
import com.example.logic.formatDateShort
import com.example.model.BuiltInDefaults
import com.example.model.CategoryIconCatalog
import com.example.model.CategoryScope
import com.example.model.EventEntry
import com.example.model.EventEntryType
import com.example.model.EventParticipant
import com.example.model.EventSplitMode
import com.example.model.EventStatus
import com.example.model.EventType
import com.example.model.FamilyEvent
import com.example.model.FamilyMember
import com.example.model.KhataCategory
import com.example.model.ParticipantKind
import com.example.model.PaymentMode
import com.example.ui.GroupWorkspaceData
import com.example.ui.components.AmountText
import com.example.ui.components.CategoryBadge
import com.example.ui.components.CategoryBreakdownRankedList
import com.example.ui.components.CategoryDonutChart
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.KhataText
import com.example.ui.components.MemberAvatar
import com.example.ui.theme.LocalKhataSemanticColors
import com.example.ui.theme.parseHexColor

@Composable
fun FamilyEventsScreen(
    data: GroupWorkspaceData,
    selectedEventId: String?,
    strings: AppStrings,
    onSelectEvent: (String?) -> Unit,
    onSaveEvent: (
        eventId: String?,
        title: String,
        eventType: EventType,
        budget: Double,
        startDateMillis: Long,
        endDateMillis: Long,
        venue: String,
        notes: String,
        accentColorHex: String,
        status: EventStatus,
        initialMembers: List<FamilyMember>,
    ) -> Unit,
    onDeleteEvent: (String) -> Unit,
    onAddParticipant: (
        eventId: String,
        name: String,
        contact: String,
        kind: ParticipantKind,
        familyMemberId: String,
        avatarColorHex: String,
    ) -> Unit,
    onDeleteParticipant: (String) -> Unit,
    onSaveEventEntry: (
        eventId: String,
        entryId: String?,
        entryType: EventEntryType,
        amount: Double,
        category: KhataCategory,
        participant: EventParticipant,
        splitMode: EventSplitMode,
        splitParticipantIds: List<String>,
        paymentMode: PaymentMode,
        dateMillis: Long,
        notes: String,
    ) -> Unit,
    onDeleteEventEntry: (String) -> Unit,
    onNotify: (String) -> Unit,
) {
    val selectedEvent = remember(data.events, selectedEventId) {
        data.events.firstOrNull { it.id == selectedEventId }
    }

    if (selectedEvent != null) {
        EventDetailScreen(
            data = data,
            event = selectedEvent,
            strings = strings,
            onBack = { onSelectEvent(null) },
            onDeleteEvent = { onDeleteEvent(selectedEvent.id) },
            onAddParticipant = onAddParticipant,
            onDeleteParticipant = onDeleteParticipant,
            onSaveEventEntry = onSaveEventEntry,
            onDeleteEventEntry = onDeleteEventEntry,
            onNotify = onNotify,
        )
        return
    }

    val group = data.activeGroup ?: return
    val semanticColors = LocalKhataSemanticColors.current
    var showEventForm by remember { mutableStateOf(false) }
    var editingEvent by remember { mutableStateOf<FamilyEvent?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingEvent = null
                    showEventForm = true
                },
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary,
                modifier = Modifier.testTag("create_event_fab"),
            ) {
                Icon(Icons.Rounded.Add, contentDescription = strings.createEvent)
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 92.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                ) {
                    Box(modifier = Modifier.fillMaxWidth().height(150.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.img_events_banner),
                            contentDescription = "Family celebrations banner",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.68f))
                                    )
                                )
                                .padding(16.dp),
                            contentAlignment = Alignment.BottomStart,
                        ) {
                            Column {
                                KhataText(
                                    text = strings.familyEventsTitle,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                )
                                Text(
                                    text = "Track Puja, Weddings, Birthdays & Trips separately with friends & guests",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.88f),
                                )
                            }
                        }
                    }
                }
            }

            if (data.events.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon = Icons.Rounded.Celebration,
                        title = "No Family Events Yet",
                        subtitle = "Create an event for Durga Puja, a Birthday, Wedding, or Family Trip to track budgets, gifts, and guest splits separately.",
                        actionLabel = strings.createEvent,
                        onAction = {
                            editingEvent = null
                            showEventForm = true
                        }
                    )
                }
            } else {
                items(data.events, key = { it.id }) { ev ->
                    val participants = remember(data.eventParticipants, ev.id) {
                        data.eventParticipants.filter { it.eventId == ev.id }
                    }
                    val entries = remember(data.eventEntries, ev.id) {
                        data.eventEntries.filter { it.eventId == ev.id }
                    }
                    val summary = remember(ev, participants, entries) {
                        KhataAnalytics.computeEventSummary(ev, participants, entries)
                    }
                    val accent = parseHexColor(ev.accentColorHex)

                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectEvent(ev.id) }
                            .testTag("event_card_${ev.id}"),
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(accent)
                                )
                                Spacer(Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    KhataText(
                                        text = ev.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                    )
                                    KhataText(
                                        text = "${BuiltInDefaults.eventTypeLabel(ev.parsedEventType(), strings.isBengali)} • ${formatDateShort(ev.startDateMillis)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        editingEvent = ev
                                        showEventForm = true
                                    }
                                ) {
                                    Icon(Icons.Rounded.Edit, contentDescription = "Edit event")
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Column {
                                    Text("Spent", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    AmountText(
                                        text = formatCurrency(summary.totalExpenses, group.currencySymbol),
                                        style = MaterialTheme.typography.titleSmall,
                                        color = semanticColors.expense,
                                    )
                                }
                                Column {
                                    Text("Gifts / Pool", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    AmountText(
                                        text = formatCurrency(summary.totalContributions, group.currencySymbol),
                                        style = MaterialTheme.typography.titleSmall,
                                        color = semanticColors.income,
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Budget", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    AmountText(
                                        text = formatCurrency(ev.budget, group.currencySymbol),
                                        style = MaterialTheme.typography.titleSmall,
                                    )
                                }
                            }

                            if (ev.budget > 0.0) {
                                val ratio = (summary.totalExpenses / ev.budget).toFloat().coerceIn(0f, 1f)
                                LinearProgressIndicator(
                                    progress = { ratio },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(7.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = if (summary.totalExpenses > ev.budget) semanticColors.expense else accent,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                )
                            }

                            Text(
                                text = "${participants.size} participants • ${entries.size} entries${if (ev.venue.isNotBlank()) " • ${ev.venue}" else ""}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }

    if (showEventForm) {
        EventFormSheet(
            existing = editingEvent,
            familyMembers = data.members,
            isBengali = strings.isBengali,
            currencySymbol = group.currencySymbol,
            onDismiss = { showEventForm = false },
            onSave = { title, type, budget, start, end, venue, notes, colorHex, status, selectedMembers ->
                onSaveEvent(
                    editingEvent?.id,
                    title,
                    type,
                    budget,
                    start,
                    end,
                    venue,
                    notes,
                    colorHex,
                    status,
                    selectedMembers,
                )
                showEventForm = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EventDetailScreen(
    data: GroupWorkspaceData,
    event: FamilyEvent,
    strings: AppStrings,
    onBack: () -> Unit,
    onDeleteEvent: () -> Unit,
    onAddParticipant: (
        eventId: String,
        name: String,
        contact: String,
        kind: ParticipantKind,
        familyMemberId: String,
        avatarColorHex: String,
    ) -> Unit,
    onDeleteParticipant: (String) -> Unit,
    onSaveEventEntry: (
        eventId: String,
        entryId: String?,
        entryType: EventEntryType,
        amount: Double,
        category: KhataCategory,
        participant: EventParticipant,
        splitMode: EventSplitMode,
        splitParticipantIds: List<String>,
        paymentMode: PaymentMode,
        dateMillis: Long,
        notes: String,
    ) -> Unit,
    onDeleteEventEntry: (String) -> Unit,
    onNotify: (String) -> Unit,
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val group = data.activeGroup ?: return
    val semanticColors = LocalKhataSemanticColors.current
    val participants = remember(data.eventParticipants, event.id) {
        data.eventParticipants.filter { it.eventId == event.id }
    }
    val entries = remember(data.eventEntries, event.id) {
        data.eventEntries.filter { it.eventId == event.id }
    }
    val summary = remember(event, participants, entries) {
        KhataAnalytics.computeEventSummary(event, participants, entries)
    }

    val saveEventXlsxLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(ReportGenerator.XLSX_MIME)
    ) { uri ->
        if (uri != null) {
            try {
                val temp = ReportGenerator.generateEventXlsxToFile(context, group, summary, entries)
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    temp.inputStream().use { it.copyTo(out) }
                }
                onNotify("Saved Event Excel (.xlsx)")
            } catch (e: Exception) {
                onNotify("Failed to save Excel: ${e.localizedMessage}")
            }
        }
    }

    val saveEventPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            try {
                val temp = ReportGenerator.generateEventPdfToFile(context, group, summary, entries)
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    temp.inputStream().use { it.copyTo(out) }
                }
                onNotify("Saved Event PDF")
            } catch (e: Exception) {
                onNotify("Failed to save PDF: ${e.localizedMessage}")
            }
        }
    }

    var activeSubTab by remember { mutableIntStateOf(0) }
    var showAddParticipantSheet by remember { mutableStateOf(false) }
    var showAddEntrySheet by remember { mutableStateOf(false) }
    var editingEntry by remember { mutableStateOf<EventEntry?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (participants.isEmpty()) {
                        showAddParticipantSheet = true
                    } else {
                        editingEntry = null
                        showAddEntrySheet = true
                    }
                },
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary,
                modifier = Modifier.testTag("add_event_entry_fab"),
            ) {
                Icon(
                    imageVector = if (participants.isEmpty()) Icons.Rounded.GroupAdd else Icons.Rounded.Add,
                    contentDescription = "Add event entry",
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 92.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("event_back_button")) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back to events")
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        KhataText(
                            text = event.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = "${formatDateShort(event.startDateMillis)}${if (event.venue.isNotBlank()) " • ${event.venue}" else ""}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(
                        onClick = {
                            val pdfFile = ReportGenerator.generateEventPdfToFile(context, group, summary, entries)
                            ReportGenerator.shareFile(context, pdfFile, "application/pdf", "Share Event PDF")
                            onNotify("Generated Event PDF")
                        }
                    ) {
                        Icon(Icons.Rounded.PictureAsPdf, contentDescription = "Share event PDF")
                    }
                    IconButton(
                        onClick = {
                            val xlsxFile = ReportGenerator.generateEventXlsxToFile(context, group, summary, entries)
                            ReportGenerator.shareFile(context, xlsxFile, ReportGenerator.XLSX_MIME, "Share Event Excel")
                            onNotify("Generated Event Excel (.xlsx)")
                        },
                        modifier = Modifier.testTag("export_event_xlsx_button"),
                    ) {
                        Icon(Icons.Rounded.TableChart, contentDescription = "Share event Excel")
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete event", tint = semanticColors.expense)
                    }
                }
            }

            // Event Summary Card + Quick Multi-Format Export Strip
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = parseHexColor(event.accentColorHex).copy(alpha = 0.12f)),
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                KhataText(strings.eventBudget, style = MaterialTheme.typography.labelSmall)
                                AmountText(formatCurrency(event.budget, group.currencySymbol), style = MaterialTheme.typography.titleMedium)
                            }
                            Column {
                                KhataText(strings.contributionsGifts, style = MaterialTheme.typography.labelSmall)
                                AmountText(formatCurrency(summary.totalContributions, group.currencySymbol), style = MaterialTheme.typography.titleMedium, color = semanticColors.income)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                KhataText(strings.eventExpenses, style = MaterialTheme.typography.labelSmall)
                                AmountText(formatCurrency(summary.totalExpenses, group.currencySymbol), style = MaterialTheme.typography.titleMedium, color = semanticColors.expense)
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                text = "Budget Remaining: ${formatCurrency(summary.remainingBudget, group.currencySymbol)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (summary.remainingBudget >= 0) semanticColors.income else semanticColors.expense,
                            )
                            Text(
                                text = "Pool Net: ${formatCurrency(summary.netEventPoolBalance, group.currencySymbol)}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            OutlinedButton(
                                onClick = {
                                    saveEventPdfLauncher.launch("Event_${event.title.replace(" ", "_")}.pdf")
                                }
                            ) {
                                Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Save PDF")
                            }
                            OutlinedButton(
                                onClick = {
                                    saveEventXlsxLauncher.launch("Event_${event.title.replace(" ", "_")}.xlsx")
                                }
                            ) {
                                Icon(Icons.Rounded.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Save .xlsx")
                            }
                            OutlinedButton(
                                onClick = {
                                    val csv = ReportGenerator.writeEventCsv(group, summary, entries)
                                    val csvFile = ReportGenerator.writeTempTextFile(context, "Event_${event.id}.csv", csv)
                                    ReportGenerator.shareFile(context, csvFile, "text/csv", "Share Event CSV")
                                    onNotify("Generated Event CSV")
                                }
                            ) {
                                Icon(Icons.Rounded.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("CSV")
                            }
                        }
                    }
                }
            }

            // Sub-tabs
            item {
                PrimaryTabRow(selectedTabIndex = activeSubTab) {
                    Tab(selected = activeSubTab == 0, onClick = { activeSubTab = 0 }, text = { Text("Ledger (${entries.size})") })
                    Tab(selected = activeSubTab == 1, onClick = { activeSubTab = 1 }, text = { Text("People (${participants.size})") })
                    Tab(selected = activeSubTab == 2, onClick = { activeSubTab = 2 }, text = { Text("Breakdown %") })
                }
            }

            when (activeSubTab) {
                0 -> {
                    if (entries.isEmpty()) {
                        item {
                            EmptyStateCard(
                                icon = Icons.Rounded.Celebration,
                                title = "No Event Entries Yet",
                                subtitle = if (participants.isEmpty()) {
                                    "Add family members or friends/guests first, then log gifts or event expenses."
                                } else {
                                    "Tap + to record an event gift/contribution or itemized expense."
                                },
                                actionLabel = if (participants.isEmpty()) "Add Participant" else "Add Entry",
                                onAction = {
                                    if (participants.isEmpty()) showAddParticipantSheet = true
                                    else {
                                        editingEntry = null
                                        showAddEntrySheet = true
                                    }
                                }
                            )
                        }
                    } else {
                        items(entries, key = { it.id }) { ee ->
                            val isGift = ee.parsedEntryType() == EventEntryType.CONTRIBUTION_GIFT
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth().clickable {
                                    editingEntry = ee
                                    showAddEntrySheet = true
                                },
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    CategoryBadge(ee.categoryIconKey, ee.categoryColorHex, size = 40.dp, iconSize = 20.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        KhataText(ee.categoryName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            text = "${ee.participantName} • ${ee.paymentMode} • ${formatDateShort(ee.dateMillis)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                        if (ee.notes.isNotBlank()) {
                                            KhataText(ee.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    AmountText(
                                        text = "${if (isGift) "+" else "-"}${formatCurrency(ee.amount, group.currencySymbol)}",
                                        color = if (isGift) semanticColors.income else semanticColors.expense,
                                    )
                                    IconButton(onClick = { onDeleteEventEntry(ee.id) }) {
                                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete entry", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    item {
                        OutlinedButton(
                            onClick = { showAddParticipantSheet = true },
                            modifier = Modifier.fillMaxWidth().testTag("add_event_participant_button"),
                        ) {
                            Icon(Icons.Rounded.PersonAdd, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            KhataText("Add Family Member or Friend/Guest")
                        }
                    }
                    items(summary.participantSettlements, key = { it.participantId }) { ps ->
                        val rawParticipant = participants.firstOrNull { it.id == ps.participantId }
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                MemberAvatar(ps.name, ps.avatarColorHex, size = 40.dp)
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(ps.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (ps.isGuest) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.primaryContainer,
                                        ) {
                                            Text(
                                                text = if (ps.isGuest) "Guest/Friend" else "Family",
                                                style = MaterialTheme.typography.labelSmall,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            )
                                        }
                                    }
                                    if (rawParticipant != null && rawParticipant.contact.isNotBlank()) {
                                        Text(rawParticipant.contact, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text(
                                        text = "Gifts: ${formatCurrency(ps.contributedGifts, group.currencySymbol)} • Paid: ${formatCurrency(ps.expensePaid, group.currencySymbol)} • Share: ${formatCurrency(ps.fairShare, group.currencySymbol)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    AmountText(
                                        text = formatCurrency(ps.netSettlement, group.currencySymbol),
                                        color = if (ps.netSettlement >= 0) semanticColors.income else semanticColors.expense,
                                        style = MaterialTheme.typography.titleSmall,
                                    )
                                    IconButton(onClick = { onDeleteParticipant(ps.participantId) }, modifier = Modifier.size(32.dp)) {
                                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "Remove participant", modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                KhataText(strings.categoryBreakdown, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                CategoryDonutChart(
                                    items = summary.expenseCategories,
                                    totalAmount = summary.totalExpenses,
                                    currencySymbol = group.currencySymbol,
                                    centerLabel = strings.eventExpenses,
                                )
                                if (summary.expenseCategories.isNotEmpty()) {
                                    CategoryBreakdownRankedList(
                                        items = summary.expenseCategories,
                                        currencySymbol = group.currencySymbol,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddParticipantSheet) {
        AddEventParticipantSheet(
            familyMembers = data.members,
            existingParticipants = participants,
            onDismiss = { showAddParticipantSheet = false },
            onAdd = { name, contact, kind, famId, colorHex ->
                onAddParticipant(event.id, name, contact, kind, famId, colorHex)
                showAddParticipantSheet = false
            }
        )
    }

    if (showAddEntrySheet) {
        EventEntryFormSheet(
            existing = editingEntry,
            participants = participants,
            categories = data.categories.filter { it.parsedScope() != CategoryScope.MONTHLY },
            isBengali = strings.isBengali,
            currencySymbol = group.currencySymbol,
            onDismiss = { showAddEntrySheet = false },
            onSave = { entryType, amount, cat, part, splitMode, splitIds, payMode, dateMillis, notes ->
                onSaveEventEntry(
                    event.id,
                    editingEntry?.id,
                    entryType,
                    amount,
                    cat,
                    part,
                    splitMode,
                    splitIds,
                    payMode,
                    dateMillis,
                    notes,
                )
                showAddEntrySheet = false
            }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Event?") },
            text = { Text("Delete '${event.title}' and all its entries and participants?") },
            confirmButton = {
                TextButton(onClick = { showDeleteConfirm = false; onDeleteEvent() }) {
                    Text("Delete", color = semanticColors.expense)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EventFormSheet(
    existing: FamilyEvent?,
    familyMembers: List<FamilyMember>,
    isBengali: Boolean,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onSave: (
        title: String,
        eventType: EventType,
        budget: Double,
        startDateMillis: Long,
        endDateMillis: Long,
        venue: String,
        notes: String,
        accentColorHex: String,
        status: EventStatus,
        initialMembers: List<FamilyMember>,
    ) -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var eventType by remember { mutableStateOf(existing?.parsedEventType() ?: EventType.PUJA_FESTIVAL) }
    var budgetText by remember { mutableStateOf(existing?.budget?.let { if (it == 0.0) "" else it.toLong().toString() } ?: "") }
    var venue by remember { mutableStateOf(existing?.venue ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var startMillis by remember { mutableLongStateOf(existing?.startDateMillis ?: System.currentTimeMillis()) }
    var status by remember { mutableStateOf(existing?.parsedStatus() ?: EventStatus.ACTIVE) }
    var selectedFamilyIds by remember { mutableStateOf(familyMembers.map { it.id }.toSet()) }
    var showDatePicker by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = if (existing == null) "New Family Event / Occasion" else "Edit Event",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Event Title (e.g. Durga Puja, Aarav's Birthday)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("event_title_input"),
            )

            Text("Occasion Type", style = MaterialTheme.typography.labelLarge)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                EventType.entries.forEach { et ->
                    FilterChip(
                        selected = eventType == et,
                        onClick = { eventType = et },
                        label = { KhataText(BuiltInDefaults.eventTypeLabel(et, isBengali)) },
                    )
                }
            }

            OutlinedTextField(
                value = budgetText,
                onValueChange = { budgetText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                label = { Text("Planned Budget ($currencySymbol)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            OutlinedTextField(
                value = venue,
                onValueChange = { venue = it },
                label = { Text("Venue / Destination (Optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Event Date: ${formatDateShort(startMillis)}")
                TextButton(onClick = { showDatePicker = true }) {
                    Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Pick Date")
                }
            }

            if (existing == null && familyMembers.isNotEmpty()) {
                Text("Include Family Members", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    familyMembers.forEach { m ->
                        val checked = m.id in selectedFamilyIds
                        FilterChip(
                            selected = checked,
                            onClick = {
                                selectedFamilyIds = if (checked) selectedFamilyIds - m.id else selectedFamilyIds + m.id
                            },
                            label = { Text(m.name) },
                        )
                    }
                }
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes") },
                maxLines = 2,
                modifier = Modifier.fillMaxWidth(),
            )

            Button(
                onClick = {
                    val budget = budgetText.toDoubleOrNull() ?: 0.0
                    val chosenMembers = familyMembers.filter { it.id in selectedFamilyIds }
                    onSave(
                        title,
                        eventType,
                        budget,
                        startMillis,
                        startMillis,
                        venue,
                        notes,
                        BuiltInDefaults.eventTypeColor(eventType),
                        status,
                        chosenMembers,
                    )
                },
                enabled = title.isNotBlank(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("save_event_button"),
            ) {
                Text(if (existing == null) "Create Event" else "Save Event")
            }

            Spacer(Modifier.height(16.dp))
        }
    }

    if (showDatePicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = startMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = { state.selectedDateMillis?.let { startMillis = it }; showDatePicker = false }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
            }
        ) { DatePicker(state = state) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddEventParticipantSheet(
    familyMembers: List<FamilyMember>,
    existingParticipants: List<EventParticipant>,
    onDismiss: () -> Unit,
    onAdd: (
        name: String,
        contact: String,
        kind: ParticipantKind,
        familyMemberId: String,
        avatarColorHex: String,
    ) -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var guestName by remember { mutableStateOf("") }
    var guestContact by remember { mutableStateOf("") }

    val availableFamily = remember(familyMembers, existingParticipants) {
        val existingFamIds = existingParticipants.mapNotNull { it.familyMemberId.takeIf { id -> id.isNotBlank() } }.toSet()
        familyMembers.filter { it.id !in existingFamIds }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Add Event Participants", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            if (availableFamily.isNotEmpty()) {
                Text("Quick-Add Existing Family Members", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    availableFamily.forEach { m ->
                        Button(
                            onClick = {
                                onAdd(
                                    m.name,
                                    m.email.ifBlank { m.phone },
                                    ParticipantKind.FAMILY_MEMBER,
                                    m.id,
                                    m.avatarColorHex,
                                )
                            }
                        ) {
                            Text("+ ${m.name}")
                        }
                    }
                }
            }

            Text("Add External Friend / Guest", style = MaterialTheme.typography.labelLarge)
            OutlinedTextField(
                value = guestName,
                onValueChange = { guestName = it },
                label = { Text("Guest / Friend Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("guest_name_input"),
            )
            OutlinedTextField(
                value = guestContact,
                onValueChange = { guestContact = it },
                label = { Text("Email or Phone (Optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Button(
                onClick = {
                    val color = CategoryIconCatalog.avatarColors[existingParticipants.size % CategoryIconCatalog.avatarColors.size]
                    onAdd(guestName, guestContact, ParticipantKind.GUEST_FRIEND, "", color)
                },
                enabled = guestName.isNotBlank(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("save_guest_button"),
            ) {
                Text("Add Guest / Friend")
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EventEntryFormSheet(
    existing: EventEntry?,
    participants: List<EventParticipant>,
    categories: List<KhataCategory>,
    isBengali: Boolean,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onSave: (
        entryType: EventEntryType,
        amount: Double,
        category: KhataCategory,
        participant: EventParticipant,
        splitMode: EventSplitMode,
        splitParticipantIds: List<String>,
        paymentMode: PaymentMode,
        dateMillis: Long,
        notes: String,
    ) -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var entryType by remember { mutableStateOf(existing?.parsedEntryType() ?: EventEntryType.EXPENSE) }
    var amountText by remember { mutableStateOf(existing?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "") }
    var selectedCategory by remember(existing, categories) {
        mutableStateOf(categories.firstOrNull { it.id == existing?.categoryId } ?: categories.firstOrNull())
    }
    var selectedParticipant by remember(existing, participants) {
        mutableStateOf(participants.firstOrNull { it.id == existing?.participantId } ?: participants.firstOrNull())
    }
    var splitMode by remember { mutableStateOf(existing?.parsedSplitMode() ?: EventSplitMode.ALL_PARTICIPANTS) }
    var selectedSplitIds by remember {
        mutableStateOf(existing?.splitParticipantIds?.toSet() ?: participants.map { it.id }.toSet())
    }
    var paymentMode by remember { mutableStateOf(existing?.parsedPaymentMode() ?: PaymentMode.UPI) }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    val dateMillis by remember { mutableLongStateOf(existing?.dateMillis ?: System.currentTimeMillis()) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = if (existing == null) "Add Event Entry" else "Edit Event Entry",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )

            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = entryType == EventEntryType.EXPENSE,
                    onClick = { entryType = EventEntryType.EXPENSE },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                ) { Text("Expense") }
                SegmentedButton(
                    selected = entryType == EventEntryType.CONTRIBUTION_GIFT,
                    onClick = { entryType = EventEntryType.CONTRIBUTION_GIFT },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                ) { Text("Gift / Pool") }
            }

            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                label = { Text("Amount ($currencySymbol)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("event_entry_amount_input"),
            )

            Text("Category", style = MaterialTheme.typography.labelLarge)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                categories.forEach { cat ->
                    FilterChip(
                        selected = selectedCategory?.id == cat.id,
                        onClick = { selectedCategory = cat },
                        leadingIcon = { CategoryBadge(cat.iconKey, cat.colorHex, size = 24.dp, iconSize = 14.dp) },
                        label = { KhataText(cat.displayName(isBengali)) },
                    )
                }
            }

            Text(if (entryType == EventEntryType.EXPENSE) "Paid By" else "Received From", style = MaterialTheme.typography.labelLarge)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                participants.forEach { p ->
                    FilterChip(
                        selected = selectedParticipant?.id == p.id,
                        onClick = { selectedParticipant = p },
                        label = { Text(p.name) },
                    )
                }
            }

            if (entryType == EventEntryType.EXPENSE) {
                Text("Split Among", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    EventSplitMode.entries.forEach { mode ->
                        val lbl = when (mode) {
                            EventSplitMode.ALL_PARTICIPANTS -> "All Participants"
                            EventSplitMode.SELECTED_PARTICIPANTS -> "Selected"
                            EventSplitMode.INDIVIDUAL -> "Individual"
                        }
                        FilterChip(selected = splitMode == mode, onClick = { splitMode = mode }, label = { Text(lbl) })
                    }
                }
                if (splitMode == EventSplitMode.SELECTED_PARTICIPANTS) {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        participants.forEach { p ->
                            val checked = p.id in selectedSplitIds
                            FilterChip(
                                selected = checked,
                                onClick = {
                                    selectedSplitIds = if (checked && selectedSplitIds.size > 1) selectedSplitIds - p.id else selectedSplitIds + p.id
                                },
                                label = { Text(p.name) },
                            )
                        }
                    }
                }
            }

            Text("Payment Mode", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PaymentMode.entries.forEach { pm ->
                    FilterChip(selected = paymentMode == pm, onClick = { paymentMode = pm }, label = { Text(pm.name) })
                }
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes") },
                maxLines = 2,
                modifier = Modifier.fillMaxWidth(),
            )

            val parsedAmount = amountText.toDoubleOrNull()
            val canSave = parsedAmount != null && parsedAmount > 0.0 && selectedCategory != null && selectedParticipant != null
            Button(
                onClick = {
                    val amt = parsedAmount ?: return@Button
                    val cat = selectedCategory ?: return@Button
                    val part = selectedParticipant ?: return@Button
                    val finalSplits = when (splitMode) {
                        EventSplitMode.ALL_PARTICIPANTS -> participants.map { it.id }
                        EventSplitMode.SELECTED_PARTICIPANTS -> selectedSplitIds.toList()
                        EventSplitMode.INDIVIDUAL -> listOf(part.id)
                    }
                    onSave(entryType, amt, cat, part, splitMode, finalSplits, paymentMode, dateMillis, notes)
                },
                enabled = canSave,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("save_event_entry_button"),
            ) {
                Text("Save Event Entry")
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}
