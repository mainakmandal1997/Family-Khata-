const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_1";
const BOB_UID = "bob_uid_2";
const CHARLIE_UID = "charlie_uid_3";
const ALICE_EMAIL = "alice@example.com";
const BOB_EMAIL = "bob@example.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function pastTime(msOffset = 5000) {
  return new Date(Date.now() - msOffset);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("UserProfile: owner can create/read/update; unauth & other user denied; ghost field rejected", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: ALICE_EMAIL, email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: BOB_EMAIL, email_verified: true }).firestore();

  const created = pastTime(10000);
  const validProfile = {
    userId: ALICE_UID,
    displayName: "Alice Mandal",
    email: ALICE_EMAIL,
    phoneNumber: "+919876543210",
    preferredLanguage: "en",
    activeGroupId: "",
    lastBackupAtMillis: 0,
    createdAt: created,
    updatedAt: created,
  };

  await assertFails(unauthDb.collection("users").doc(ALICE_UID).set(validProfile));
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).set(validProfile));
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).update({
    preferredLanguage: "bn",
    updatedAt: pastTime(1000),
  }));

  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).update({ displayName: "Hack" }));

  await assertFails(aliceDb.collection("users").doc(ALICE_UID).update({
    isAdmin: true,
    updatedAt: pastTime(500),
  }));
});

test("FamilyGroup: create, filtered queries, email invite join, spoofed email denied, unfiltered list denied", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: ALICE_EMAIL, email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: BOB_EMAIL, email_verified: true }).firestore();
  const spoofedBobDb = testEnv.authenticatedContext(BOB_UID, { email: BOB_EMAIL, email_verified: false }).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID, { email: "charlie@example.com", email_verified: true }).firestore();

  const created = pastTime(10000);
  const groupId = "grp_mandal_1";
  await assertSucceeds(
    aliceDb.collection("familyGroups").doc(groupId).set({
      name: "Mandal Family Khata",
      currencySymbol: "₹",
      cycleStartDay: 1,
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID],
      adminUids: [ALICE_UID],
      invitedEmails: [BOB_EMAIL],
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(aliceDb.collection("familyGroups").where("memberUids", "array-contains", ALICE_UID).get());
  await assertSucceeds(bobDb.collection("familyGroups").where("invitedEmails", "array-contains", BOB_EMAIL).get());
  await assertFails(aliceDb.collection("familyGroups").get());

  await assertFails(spoofedBobDb.collection("familyGroups").doc(groupId).get());
  await assertFails(
    spoofedBobDb.collection("familyGroups").doc(groupId).update({
      memberUids: [ALICE_UID, BOB_UID],
      updatedAt: pastTime(1000),
    })
  );

  await assertFails(charlieDb.collection("familyGroups").doc(groupId).get());

  await assertFails(
    bobDb.collection("familyGroups").doc(groupId).update({
      memberUids: [ALICE_UID, BOB_UID],
      adminUids: [ALICE_UID, BOB_UID],
      updatedAt: pastTime(1000),
    })
  );

  await assertSucceeds(
    bobDb.collection("familyGroups").doc(groupId).update({
      memberUids: [ALICE_UID, BOB_UID],
      updatedAt: pastTime(1000),
    })
  );

  await assertSucceeds(bobDb.collection("familyGroups").where("memberUids", "array-contains", BOB_UID).get());
});

test("Subcollections: parity, invite sync, isolation, and orphan protection", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: ALICE_EMAIL, email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: BOB_EMAIL, email_verified: true }).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID, { email: "charlie@example.com", email_verified: true }).firestore();
  const created = pastTime(10000);
  const groupId = "grp_1";

  await assertSucceeds(
    aliceDb.collection("familyGroups").doc(groupId).set({
      name: "Sen Family",
      currencySymbol: "₹",
      cycleStartDay: 1,
      ownerId: ALICE_UID,
      memberUids: [ALICE_UID],
      adminUids: [ALICE_UID],
      invitedEmails: [BOB_EMAIL],
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("familyGroups").doc(groupId).collection("members").doc("mem_1").set({
      groupId,
      memberUids: [ALICE_UID],
      invitedEmails: [BOB_EMAIL],
      name: "Alice Sen",
      email: ALICE_EMAIL,
      phone: "9876543210",
      role: "ADMIN",
      linkedUid: ALICE_UID,
      avatarColorHex: "#0F766E",
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("familyGroups").doc(groupId).collection("categories").doc("cat_groceries").set({
      groupId,
      memberUids: [ALICE_UID],
      invitedEmails: [BOB_EMAIL],
      name: "Groceries",
      nameBn: "মুদিখানা",
      scope: "MONTHLY",
      type: "EXPENSE",
      iconKey: "groceries",
      colorHex: "#10B981",
      builtIn: true,
      createdBy: ALICE_UID,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("familyGroups").doc(groupId).collection("transactions").doc("tx_1").set({
      groupId,
      memberUids: [ALICE_UID],
      invitedEmails: [BOB_EMAIL],
      type: "EXPENSE",
      amount: 1250.5,
      categoryId: "cat_groceries",
      categoryName: "Groceries",
      categoryColorHex: "#10B981",
      categoryIconKey: "groceries",
      paidByMemberId: "mem_1",
      paidByName: "Alice Sen",
      splitMode: "FULL_FAMILY",
      splitMemberIds: ["mem_1"],
      paymentMode: "UPI",
      dateMillis: Date.now() - 5000,
      notes: "Rice and dal",
      createdBy: ALICE_UID,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("familyGroups").doc(groupId).collection("transactions").doc("tx_1").update({
      amount: 1400,
      notes: "Rice, dal, and mustard oil",
      updatedAt: pastTime(1000),
    })
  );

  // Bob accepts invite & syncs historical tx_1 into his memberUids
  await assertSucceeds(
    bobDb.collection("familyGroups").doc(groupId).update({
      memberUids: [ALICE_UID, BOB_UID],
      updatedAt: pastTime(1000),
    })
  );
  await assertSucceeds(
    bobDb.collection("familyGroups").doc(groupId).collection("transactions").where("invitedEmails", "array-contains", BOB_EMAIL).get()
  );
  await assertSucceeds(
    bobDb.collection("familyGroups").doc(groupId).collection("transactions").doc("tx_1").update({
      memberUids: [ALICE_UID, BOB_UID],
      updatedAt: pastTime(500),
    })
  );
  await assertSucceeds(
    bobDb.collection("familyGroups").doc(groupId).collection("transactions").where("memberUids", "array-contains", BOB_UID).get()
  );

  // Events, participants, entries
  const eventId = "evt_puja_1";
  await assertSucceeds(
    aliceDb.collection("familyGroups").doc(groupId).collection("events").doc(eventId).set({
      groupId,
      memberUids: [ALICE_UID],
      invitedEmails: [BOB_EMAIL],
      title: "Durga Puja Celebration",
      eventType: "PUJA_FESTIVAL",
      budget: 50000,
      startDateMillis: Date.now() - 5000,
      endDateMillis: Date.now() + 86400000,
      venue: "Family Courtyard",
      notes: "Annual puja",
      accentColorHex: "#D97706",
      status: "ACTIVE",
      createdBy: ALICE_UID,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("familyGroups").doc(groupId).collection("eventParticipants").doc("ep_guest_1").set({
      groupId,
      eventId,
      memberUids: [ALICE_UID],
      invitedEmails: [BOB_EMAIL],
      name: "Rohan (Friend)",
      contact: "rohan@friend.com",
      participantKind: "GUEST_FRIEND",
      familyMemberId: "",
      avatarColorHex: "#E05D38",
      createdBy: ALICE_UID,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("familyGroups").doc(groupId).collection("eventEntries").doc("ee_1").set({
      groupId,
      eventId,
      memberUids: [ALICE_UID],
      invitedEmails: [BOB_EMAIL],
      entryType: "EXPENSE",
      amount: 4500,
      categoryId: "cat_decor",
      categoryName: "Decoration",
      categoryColorHex: "#E05D38",
      categoryIconKey: "decoration",
      participantId: "ep_guest_1",
      participantName: "Rohan (Friend)",
      splitMode: "ALL_PARTICIPANTS",
      splitParticipantIds: ["ep_guest_1"],
      paymentMode: "UPI",
      dateMillis: Date.now() - 2000,
      notes: "Flowers & lights",
      createdBy: ALICE_UID,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Outsider Charlie denied
  await assertFails(charlieDb.collection("familyGroups").doc(groupId).collection("transactions").get());
  await assertFails(charlieDb.collection("familyGroups").doc(groupId).collection("transactions").where("memberUids", "array-contains", ALICE_UID).get());
  await assertFails(charlieDb.collection("familyGroups").doc(groupId).collection("transactions").doc("tx_1").get());
  await assertFails(charlieDb.collection("familyGroups").doc(groupId).collection("events").doc(eventId).get());
  await assertFails(charlieDb.collection("familyGroups").doc(groupId).collection("eventEntries").doc("ee_1").delete());

  // Orphan eventEntry rejected
  await assertFails(
    aliceDb.collection("familyGroups").doc(groupId).collection("eventEntries").doc("ee_orphan").set({
      groupId,
      eventId: "non_existent_event",
      memberUids: [ALICE_UID],
      invitedEmails: [BOB_EMAIL],
      entryType: "EXPENSE",
      amount: 100,
      categoryId: "cat_1",
      categoryName: "Misc",
      categoryColorHex: "#000000",
      categoryIconKey: "party",
      participantId: "ep_1",
      participantName: "Alice",
      splitMode: "INDIVIDUAL",
      splitParticipantIds: ["ep_1"],
      paymentMode: "CASH",
      dateMillis: Date.now() - 1000,
      notes: "",
      createdBy: ALICE_UID,
      createdAt: created,
      updatedAt: created,
    })
  );
});
